#!/usr/bin/env python3
"""
Toy 025 — Renormalization scheme dependence (physical vs unphysical separation)

Pressure point:
- Intermediate quantities in QFT depend on renormalization scheme.
- Only specific combinations are scheme-independent (physical).
- “Bare vs renormalized” is not a clean physical split.

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Scalar φ^4 theory (1+1D proxy)
- One-loop mass correction with cutoff Λ
- Compare two renormalization schemes:
    (A) momentum cutoff
    (B) subtraction at scale μ
- Track scheme dependence of intermediate quantities vs invariants

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy025RenormalizationSchemeDependence:
    toy_id = "025"

    def __init__(
        self,
        *,
        coupling: float = 0.5,
        bare_mass: float = 1.0,
        cutoffs: List[float] = [5.0, 10.0, 20.0],
        subtraction_scale_mu: float = 2.0,
    ) -> None:
        self.lam = float(coupling)
        self.m0 = float(bare_mass)
        self.Ls = [float(L) for L in cutoffs]
        self.mu = float(subtraction_scale_mu)

    def one_loop_mass_cutoff(self, Lambda: float) -> float:
        """
        δm^2 ~ λ log(Λ / m)
        """
        return self.lam * math.log(Lambda / self.m0)

    def one_loop_mass_subtracted(self, Lambda: float) -> float:
        """
        Same loop, different scheme:
        subtract at μ.
        """
        return self.lam * math.log(self.mu / self.m0)

    def physical_mass_invariant(self, Lambda: float) -> float:
        """
        Scheme-invariant combination (proxy).
        """
        return self.m0 * self.m0 + self.one_loop_mass_cutoff(Lambda)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for L in self.Ls:
            dm_cut = self.one_loop_mass_cutoff(L)
            dm_sub = self.one_loop_mass_subtracted(L)
            m_phys = self.physical_mass_invariant(L)

            sample_points.append({
                "coordinates": {
                    "cutoff_Lambda": L,
                },
                "curvature_invariants": {
                    "renormalization_scale_mu": self.mu,
                },
                "local_observables": {
                    "delta_m2_cutoff_scheme": dm_cut,
                    "delta_m2_subtraction_scheme": dm_sub,
                    "physical_mass_squared_invariant": m_phys,
                },
                "causal_structure": {
                    "scheme_independent_intermediates": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "coupling_lambda": self.lam,
                "bare_mass": self.m0,
                "cutoffs": self.Ls,
                "subtraction_scale_mu": self.mu,
            },
            "notes": {
                "assumptions": [
                    "Scalar φ^4 interaction",
                    "One-loop mass renormalization",
                    "Log-divergent structure captured as proxy",
                ],
                "pressure_point": (
                    "Renormalization scheme choices affect intermediate quantities. "
                    "Only specific combinations correspond to physical observables."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "bare_quantity_physical": False,
                    "scheme_independent_intermediates": False,
                },
                "regime_classification": {
                    "fixed_mu": "stable_physics",
                    "varying_scheme": "intermediate_shift",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy025RenormalizationSchemeDependence().export_json()


if __name__ == "__main__":
    main()
