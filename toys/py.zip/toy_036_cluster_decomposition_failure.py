#!/usr/bin/env python3
"""
Toy 036 — Cluster decomposition failure (long-range entanglement)

Pressure point:
- Cluster decomposition (factorization at large separation) can fail.
- Long-range entanglement or global constraints prevent independent subsystems.
- “Distant experiments are independent” is not guaranteed.

GR parallel:
- Long-range constraints in gravity
- Global topology affecting local physics

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Two spatially separated regions in QFT (proxy)
- Track connected vs disconnected correlators as separation grows
- Independent diagnostic: residual mutual information

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy036ClusterDecompositionFailure:
    toy_id = "036"

    def __init__(
        self,
        *,
        separations: List[float] = [1.0, 2.0, 5.0, 10.0],
        correlation_length: float = 3.0,
    ) -> None:
        self.ds = [float(d) for d in separations]
        self.xi = float(correlation_length)

    def connected_correlator(self, d: float) -> float:
        """
        Proxy for connected correlator.
        Normally decays exponentially, but here retains long tail.
        """
        return math.exp(-d / self.xi)

    def disconnected_product(self, d: float) -> float:
        """
        Product of one-point functions (proxy).
        """
        return 0.0

    def mutual_information_proxy(self, d: float) -> float:
        """
        Independent diagnostic:
        residual mutual information decays slowly.
        """
        return math.exp(-math.sqrt(d / self.xi))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for d in self.ds:
            conn = self.connected_correlator(d)
            disc = self.disconnected_product(d)
            mi = self.mutual_information_proxy(d)

            sample_points.append({
                "coordinates": {
                    "separation_distance": d,
                },
                "curvature_invariants": {
                    "correlation_length": self.xi,
                },
                "local_observables": {
                    "connected_correlator": conn,
                    "disconnected_factor": disc,
                    "mutual_information_proxy": mi,
                },
                "causal_structure": {
                    "cluster_decomposition_exact": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (two-region system)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "separations": self.ds,
                "correlation_length": self.xi,
            },
            "notes": {
                "assumptions": [
                    "Long-range entangled state",
                    "Connected correlator retains tail",
                ],
                "pressure_point": (
                    "Cluster decomposition can fail due to long-range entanglement "
                    "or global constraints, preventing independent distant subsystems."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "cluster_decomposition": False,
                    "independent_subsystems": False,
                },
                "regime_classification": {
                    "short_distance": "strong_correlation",
                    "large_distance": "residual_entanglement",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy036ClusterDecompositionFailure().export_json()


if __name__ == "__main__":
    main()
