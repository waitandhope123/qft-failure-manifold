#!/usr/bin/env python3
"""
Toy 084 — Failure-ordering robustness under reparameterization (meta-comparator)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
- Undefined quantities are exported as null.
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 084
# ----------------------------

class Toy084FailureOrderingRobustness:
    toy_id = "084"

    def __init__(
        self,
        *,
        threshold_A: float = 0.3,
        threshold_B: float = 0.25,
        power_A: float = 2.0,
        power_B: float = 1.2,
    ) -> None:
        require(threshold_A > 0.0, "threshold_A must be > 0.")
        require(threshold_B > 0.0, "threshold_B must be > 0.")
        self.threshold_A = float(threshold_A)
        self.threshold_B = float(threshold_B)
        self.power_A = float(power_A)
        self.power_B = float(power_B)

    # Base diagnostics
    def metric_A(self, x: float) -> float:
        return x ** self.power_A

    def metric_B(self, x: float) -> float:
        return x ** self.power_B

    # Reparameterizations
    def reparam_linear(self, x: float) -> float:
        return x

    def reparam_log(self, x: float) -> float:
        return math.log1p(x)

    def reparam_sqrt(self, x: float) -> float:
        return math.sqrt(x)

    def build_payload(self, x_values: List[float]) -> Dict[str, Any]:
        require(len(x_values) >= 5, "Need multiple x samples.")
        require(all(x >= 0.0 for x in x_values), "x must be >= 0.")

        sample_points: List[Dict[str, Any]] = []

        orderings: Dict[str, Optional[str]] = {}

        reparams = {
            "linear": self.reparam_linear,
            "log1p": self.reparam_log,
            "sqrt": self.reparam_sqrt,
        }

        for name, f in reparams.items():
            first_A = None
            first_B = None

            for x in x_values:
                xp = f(x)
                A = self.metric_A(xp)
                B = self.metric_B(xp)

                if A >= self.threshold_A and first_A is None:
                    first_A = x
                if B >= self.threshold_B and first_B is None:
                    first_B = x

            ordering = None
            if first_A is not None and first_B is not None:
                if first_A < first_B:
                    ordering = "A_fails_first"
                elif first_B < first_A:
                    ordering = "B_fails_first"
                else:
                    ordering = "simultaneous"

            orderings[name] = ordering

        for x in x_values:
            vals = {}
            for name, f in reparams.items():
                xp = f(x)
                vals[name] = {
                    "A": finite_or_none(self.metric_A(xp)),
                    "B": finite_or_none(self.metric_B(xp)),
                }

            sample_points.append({
                "coordinates": {"x": x},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Meta comparator; no spacetime curvature.",
                },
                "local_observables": {
                    "metrics_by_reparam": vals,
                    "threshold_A": self.threshold_A,
                    "threshold_B": self.threshold_B,
                },
                "causal_structure": {
                    "note": "Failure ordering may change under benign reparameterizations.",
                },
            })

        stable = len(set(v for v in orderings.values() if v is not None)) == 1

        return {
            "toy_id": self.toy_id,
            "theory": "Meta: failure-ordering robustness under reparameterization",
            "spacetime": "Abstract one-parameter space",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "threshold_A": self.threshold_A,
                "threshold_B": self.threshold_B,
                "power_A": self.power_A,
                "power_B": self.power_B,
                "x_samples": x_values,
                "reparameterizations": list(reparams.keys()),
            },
            "notes": {
                "pressure_point": (
                    "If failure ordering is not invariant under simple reparameterizations, "
                    "it is not a physically meaningful comparator."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "ordering_by_reparameterization": orderings,
                    "ordering_invariant": stable,
                }
            },
        }

    def export_json(self, x_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(x_values=x_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    x_values = [i / 200.0 for i in range(0, 201)]

    toy = Toy084FailureOrderingRobustness()
    json_path = toy.export_json(x_values=x_values)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
