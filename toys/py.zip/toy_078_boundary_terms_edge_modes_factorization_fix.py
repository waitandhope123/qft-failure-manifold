#!/usr/bin/env python3
"""
Toy 078 — Edge modes / boundary terms restore factorization (gauge factorization fix proxy)

What it probes (pressure point):
- In gauge theories, Hilbert space does not factorize across a spatial cut due to Gauss law.
- Naively defining ρ_A by tracing over A^c can be ill-defined or misses "edge modes".
- Adding boundary degrees of freedom (edge modes) restores a notion of factorization and
  accounts for entanglement contributions (contact terms).

Model (minimal, deterministic, discrete):
- Two regions A and B each have a "bulk" qubit, but gauge constraint ties them via a shared edge charge.
- Physical subspace constraint: Z_edge = Z_A_bulk * Z_B_bulk (proxy Gauss law).
- Compare:
  (1) naive factorization ignoring edge (trace B bulk only)
  (2) extended Hilbert space with explicit edge mode, then trace properly
- Compute reduced density matrices and entropies to show mismatch/fix.

State:
- Take a maximally entangled bulk state across A and B (Bell) and project to physical subspace.
- Show that naive reduced state differs from extended-edge construction.

Diagnostics:
- Von Neumann entropy S_A under both constructions.
- Trace distance between reduced density matrices.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def von_neumann_entropy(rho: np.ndarray, eps: float = 1e-12) -> float:
    w = np.linalg.eigvalsh(0.5 * (rho + rho.conj().T))
    w = np.real(w)
    w = np.clip(w, 0.0, 1.0)
    s = 0.0
    for lam in w:
        if lam > eps:
            s -= float(lam) * math.log(float(lam))
    return s


def partial_trace(rho: np.ndarray, dims: Tuple[int, ...], keep: Tuple[int, ...]) -> np.ndarray:
    """
    Partial trace for small systems.
    dims: subsystem dimensions, product = rho dimension
    keep: indices to keep
    """
    n = len(dims)
    keep = tuple(keep)
    trace_out = tuple(i for i in range(n) if i not in keep)

    # reshape into tensor with indices (i1..in, j1..jn)
    D = int(np.prod(dims))
    require(rho.shape == (D, D), "rho shape mismatch.")
    tensor = rho.reshape(*dims, *dims)

    # trace out subsystems one by one
    for k in sorted(trace_out, reverse=True):
        tensor = np.trace(tensor, axis1=k, axis2=k + n)

    kept_dims = [dims[i] for i in keep]
    Dk = int(np.prod(kept_dims)) if kept_dims else 1
    return tensor.reshape(Dk, Dk)


def trace_distance(rho: np.ndarray, sigma: np.ndarray) -> float:
    # (1/2)||rho-sigma||_1
    A = rho - sigma
    w = np.linalg.eigvalsh(0.5 * (A + A.conj().T))
    return 0.5 * float(np.sum(np.abs(w)))


# ----------------------------
# Toy 078
# ----------------------------

class Toy078BoundaryTermsEdgeModesFactorizationFix:
    toy_id = "078"

    def __init__(self) -> None:
        # Pauli Z
        self.Z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
        self.I = np.eye(2, dtype=complex)

    def bell_state_density(self) -> np.ndarray:
        # |Φ+> = (|00>+|11>)/sqrt(2) on (A_bulk, B_bulk)
        psi = np.zeros((4,), dtype=complex)
        psi[0] = 1.0 / math.sqrt(2.0)
        psi[3] = 1.0 / math.sqrt(2.0)
        rho = np.outer(psi, psi.conj())
        return rho

    def embed_with_edge(self, rho_AB: np.ndarray) -> np.ndarray:
        """
        Extend to (A_bulk, edge, B_bulk).
        Impose physical constraint by correlating edge with Z_A * Z_B:
          edge qubit is |0> if eigenvalue +1, |1> if eigenvalue -1.
        This mimics adding an edge mode that stores boundary charge.
        """
        # Build projector that maps bulk basis |a b> to |a e(a,b) b>
        # Bulk basis ordering: |00>,|01>,|10>,|11> with Z eigenvalues (+1,-1)
        # z(0)=+1, z(1)=-1
        def z(bit: int) -> int:
            return 1 if bit == 0 else -1

        # Isometry V: C^4 -> C^8 (2*2*2)
        V = np.zeros((8, 4), dtype=complex)
        for a in [0, 1]:
            for b in [0, 1]:
                bulk_index = 2 * a + b
                charge = z(a) * z(b)  # +1 or -1
                e = 0 if charge == 1 else 1
                full_index = (a * 4) + (e * 2) + b  # (A,edge,B)
                V[full_index, bulk_index] = 1.0

        # rho_ext = V rho V†
        return V @ rho_AB @ V.conj().T

    def build_payload(self) -> Dict[str, Any]:
        # Start with Bell state on bulks
        rho_AB = self.bell_state_density()

        # Construction 1: naive factorization (just trace B bulk, no edge)
        rho_A_naive = partial_trace(rho_AB, dims=(2, 2), keep=(0,))  # keep A_bulk
        S_naive = von_neumann_entropy(rho_A_naive)

        # Construction 2: extended Hilbert space with explicit edge
        rho_AeB = self.embed_with_edge(rho_AB)  # dims (A_bulk, edge, B_bulk)
        rho_A_extended = partial_trace(rho_AeB, dims=(2, 2, 2), keep=(0, 1))  # keep A_bulk+edge
        S_extended = von_neumann_entropy(rho_A_extended)

        # Compare reduced states on A_bulk only after tracing edge as well (what local observer sees)
        rho_A_from_extended_then_trace_edge = partial_trace(rho_A_extended, dims=(2, 2), keep=(0,))
        S_A_local = von_neumann_entropy(rho_A_from_extended_then_trace_edge)

        td = trace_distance(rho_A_naive, rho_A_from_extended_then_trace_edge)

        sample_points = [
            {
                "coordinates": {"construction": "naive_no_edge"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Gauge/edge toy; no curvature."},
                "local_observables": {
                    "S_A": finite_or_none(S_naive),
                    "rho_A_eigs": [finite_or_none(float(x)) for x in np.linalg.eigvalsh(rho_A_naive).real.tolist()],
                },
                "causal_structure": {"note": "Naive tracing ignores edge modes; factorization can be inconsistent."},
            },
            {
                "coordinates": {"construction": "extended_with_edge_keep_A_edge"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Gauge/edge toy; no curvature."},
                "local_observables": {
                    "S_Aedge": finite_or_none(S_extended),
                    "rho_Aedge_eigs": [finite_or_none(float(x)) for x in np.linalg.eigvalsh(rho_A_extended).real.tolist()],
                },
                "causal_structure": {"note": "Extended Hilbert space restores factorization by adding boundary edge mode."},
            },
            {
                "coordinates": {"construction": "extended_then_trace_edge_to_A_bulk"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Gauge/edge toy; no curvature."},
                "local_observables": {
                    "S_A_bulk_local": finite_or_none(S_A_local),
                    "rho_A_bulk_local_eigs": [
                        finite_or_none(float(x)) for x in np.linalg.eigvalsh(rho_A_from_extended_then_trace_edge).real.tolist()
                    ],
                    "trace_distance_to_naive_rho_A": finite_or_none(td),
                },
                "causal_structure": {"note": "Local reduced state depends on whether edge is handled; mismatch quantifies failure/fix."},
            },
        ]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): edge modes / boundary terms restore factorization",
            "spacetime": "Discrete gauge constraint proxy (finite Hilbert space)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "constraint": "Z_edge = Z_A_bulk * Z_B_bulk (proxy Gauss law)",
                "state": "Bell state on bulks, embedded with edge charge",
            },
            "notes": {
                "pressure_point": (
                    "Gauge constraints obstruct naive Hilbert-space factorization across a cut. "
                    "Adding edge modes (boundary degrees of freedom) restores a consistent factorization and changes entanglement accounting."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "S_A_naive": finite_or_none(S_naive),
                    "S_Aedge_extended": finite_or_none(S_extended),
                    "S_A_bulk_local_from_extended": finite_or_none(S_A_local),
                    "trace_distance_naive_vs_extended_local": finite_or_none(td),
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 078: edge modes / boundary terms restore factorization (proxy).")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy078BoundaryTermsEdgeModesFactorizationFix()
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
