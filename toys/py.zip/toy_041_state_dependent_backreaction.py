#!/usr/bin/env python3
"""
Toy 041 — State-dependent backreaction (mean-field / Hartree proxy)

Pressure point:
- QFT dynamics become state-dependent once expectation values feed back
  into effective parameters.
- There is no invariant, state-independent Hamiltonian once backreaction
  is included, even in weakly interacting theories.

Model:
- Scalar field in a finite volume with discrete modes.
- Mean-field (Hartree) approximation:
      m_eff^2(t) = m0^2 + λ ⟨φ^2⟩(t)
- Different initial states → different effective dynamics.

Units: ℏ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


class Toy041StateDependentBackreaction:
    toy_id = "041"

    def __init__(
        self,
        *,
        m0: float = 1.0,
        lam: float = 0.2,
        modes: int = 10,
        dt: float = 0.05,
        steps: int = 200,
        n_init_a: float = 0.5,
        n_init_b: float = 0.6,
    ) -> None:
        require(m0 > 0.0, "m0 must be > 0")
        require(lam >= 0.0, "lambda must be >= 0")
        require(modes >= 1, "modes >= 1")
        require(dt > 0.0 and steps >= 1, "dt>0, steps>=1")

        self.m0 = float(m0)
        self.lam = float(lam)
        self.modes = int(modes)
        self.dt = float(dt)
        self.steps = int(steps)
        self.n_init_a = float(n_init_a)
        self.n_init_b = float(n_init_b)

        # discrete momenta k_n = n*pi/L with L=1
        self.ks = [(n + 1) * math.pi for n in range(self.modes)]

    def omega(self, k: float, m_eff: float) -> float:
        return math.sqrt(k * k + m_eff * m_eff)

    def phi2_expectation(self, occupations: List[float], m_eff: float) -> float:
        val = 0.0
        for k, n in zip(self.ks, occupations):
            w = self.omega(k, m_eff)
            val += (n + 0.5) / w
        return val

    def evolve(self, n_init: float) -> List[Dict[str, float]]:
        occupations = [n_init for _ in self.ks]
        m_eff = self.m0
        history: List[Dict[str, float]] = []

        for step in range(self.steps + 1):
            t = step * self.dt
            phi2 = self.phi2_expectation(occupations, m_eff)
            m_eff = math.sqrt(self.m0 * self.m0 + self.lam * phi2)

            history.append({
                "t": t,
                "phi2": phi2,
                "m_eff": m_eff,
            })

        return history

    def build_payload(self) -> Dict[str, Any]:
        hist_a = self.evolve(self.n_init_a)
        hist_b = self.evolve(self.n_init_b)

        sample_points: List[Dict[str, Any]] = []

        for a, b in zip(hist_a, hist_b):
            dm = b["m_eff"] - a["m_eff"]
            sample_points.append({
                "coordinates": {"t": a["t"]},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "m_eff_state_A": a["m_eff"],
                    "m_eff_state_B": b["m_eff"],
                    "delta_m_eff": dm,
                },
                "causal_structure": {
                    "note": "State-dependent effective dynamics"
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (mean-field backreaction proxy)",
            "spacetime": "Finite-volume scalar field",
            "units": {"c": 1, "hbar": 1},
            "parameters": {
                "m0": self.m0,
                "lambda": self.lam,
                "modes": self.modes,
                "dt": self.dt,
                "steps": self.steps,
                "initial_occupation_A": self.n_init_a,
                "initial_occupation_B": self.n_init_b,
            },
            "notes": {
                "pressure_point": (
                    "Including backreaction makes dynamics state-dependent; "
                    "there is no invariant Hamiltonian independent of the state."
                ),
                "approximation": "Hartree / mean-field",
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "final_m_eff_A": hist_a[-1]["m_eff"],
                    "final_m_eff_B": hist_b[-1]["m_eff"],
                    "final_difference": hist_b[-1]["m_eff"] - hist_a[-1]["m_eff"],
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy041StateDependentBackreaction()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
