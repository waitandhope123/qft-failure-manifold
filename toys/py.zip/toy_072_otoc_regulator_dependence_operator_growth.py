#!/usr/bin/env python3
"""
Toy 072 — OTOC / operator growth is regulator-dependent (finite Hilbert space proxy)

What it probes (pressure point):
- Operator growth and chaos diagnostics (OTOCs, Lyapunov exponents) depend on UV regularization,
  truncation, and operator definitions.
- In finite-dimensional or truncated systems, early-time growth may look universal, but
  late-time behavior, saturation scale, and extracted exponents depend on the cutoff.

Model (controlled, deterministic):
- Single large-spin (SU(2)) kicked-top–like model as a minimal proxy.
- Hilbert space dimension D = 2J+1 acts as a UV cutoff.
- Compute OTOC C(t) = -Tr([W(t), V]^2)/D with W=J_z, V=J_x.
- Compare across different J (cutoffs) at fixed dynamics.

Diagnostics:
- Early-time growth rate fit over a fixed window.
- Saturation value and time-to-saturation vs cutoff.
- Demonstrates regulator dependence of chaos diagnostics.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Spin operators
# ----------------------------

def spin_ops(J: int):
    D = 2 * J + 1
    m = np.arange(J, -J - 1, -1)
    Jz = np.diag(m.astype(float))
    Jp = np.zeros((D, D), dtype=complex)
    for i in range(D - 1):
        mm = m[i]
        Jp[i, i + 1] = math.sqrt(J * (J + 1) - mm * (mm - 1))
    Jm = Jp.T.conj()
    Jx = 0.5 * (Jp + Jm)
    Jy = -0.5j * (Jp - Jm)
    return Jx, Jy, Jz


# ----------------------------
# Toy 072
# ----------------------------

class Toy072OTOCRegulatorDependence:
    toy_id = "072"

    def __init__(self, *, kappa: float = 3.0) -> None:
        require(kappa > 0.0, "kappa must be > 0.")
        self.kappa = float(kappa)

    def floquet(self, J: int) -> np.ndarray:
        Jx, _, Jz = spin_ops(J)
        # Kicked-top style Floquet: U = exp(-i kappa Jz^2 / (2J)) exp(-i Jx)
        U1 = scipy_expm(-1j * self.kappa * (Jz @ Jz) / (2.0 * J))
        U2 = scipy_expm(-1j * Jx)
        return U1 @ U2

    def otoc(self, U: np.ndarray, W: np.ndarray, V: np.ndarray, t: int) -> float:
        D = U.shape[0]
        Ut = np.linalg.matrix_power(U, t)
        Wt = Ut.conj().T @ W @ Ut
        comm = Wt @ V - V @ Wt
        C = -np.trace(comm @ comm.conj().T).real / D
        return C

    def build_payload(self, Js: List[int], t_max: int, fit_window: List[int]) -> Dict[str, Any]:
        require(len(Js) >= 2, "Need multiple cutoffs J.")
        require(t_max >= 5, "t_max too small.")
        require(len(fit_window) == 2 and fit_window[0] < fit_window[1], "Bad fit window.")

        sample_points = []
        summaries = {}

        for J in Js:
            D = 2 * J + 1
            Jx, _, Jz = spin_ops(J)
            U = self.floquet(J)
            Cts = [self.otoc(U, Jz, Jx, t) for t in range(t_max + 1)]

            # Early-time growth fit (log-linear)
            t0, t1 = fit_window
            ys = [Cts[t] for t in range(t0, t1 + 1) if Cts[t] > 0]
            xs = [t for t in range(t0, t1 + 1) if Cts[t] > 0]
            slope = None
            if len(xs) >= 2:
                coeff = np.polyfit(xs, np.log(ys), 1)
                slope = float(coeff[0])

            sat = max(Cts)
            tsat = int(np.argmax(Cts))

            summaries[str(J)] = {
                "D": D,
                "early_time_growth_rate_fit": finite_or_none(slope),
                "saturation_value": finite_or_none(sat),
                "time_to_saturation": tsat,
            }

            for t, Ct in enumerate(Cts):
                sample_points.append({
                    "coordinates": {"J_cutoff": J, "t": t},
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "QFT toy; no spacetime curvature.",
                    },
                    "local_observables": {
                        "OTOC": finite_or_none(Ct),
                    },
                    "causal_structure": {
                        "note": "Operator growth diagnostics depend on finite-dimensional cutoff.",
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): OTOC / operator growth vs regulator",
            "spacetime": "Finite Hilbert space (Floquet dynamics)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "kappa": self.kappa,
                "J_cutoffs": Js,
                "t_max": t_max,
                "fit_window": fit_window,
            },
            "notes": {
                "pressure_point": (
                    "Chaos diagnostics extracted from OTOCs depend on UV cutoff (Hilbert-space dimension). "
                    "Early-time growth, saturation scale, and inferred exponents are regulator dependent."
                ),
            },
            "sample_points": sample_points,
            "observables": {"summary": summaries},
        }

    def export_json(self, Js: List[int], t_max: int, fit_window: List[int],
                    out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(Js=Js, t_max=t_max, fit_window=fit_window)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# SciPy-free expm (Padé fallback)
# ----------------------------

def scipy_expm(A: np.ndarray) -> np.ndarray:
    # Minimal Padé (scaling & squaring) to avoid external deps
    from numpy.linalg import norm
    n = A.shape[0]
    I = np.eye(n, dtype=complex)
    s = max(0, int(math.ceil(math.log2(norm(A, ord=2)))) if norm(A, ord=2) > 0 else 0)
    As = A / (2 ** s)
    X = As.copy()
    c = 1.0
    E = I + As
    D = I - As
    for k in range(2, 7):
        c *= (7 - k + 1) / (k * (2 * 7 - k + 1))
        X = As @ X
        E = E + c * X
        D = D + ((-1) ** k) * c * X
    F = np.linalg.solve(D, E)
    for _ in range(s):
        F = F @ F
    return F


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 072: OTOC regulator dependence via finite-spin model.")
    ap.add_argument("--J", type=str, default="10,20,40", help="Comma-separated spin cutoffs J")
    ap.add_argument("--t_max", type=int, default=30, help="Maximum time steps")
    ap.add_argument("--fit_window", type=str, default="2,6", help="Comma-separated fit window t0,t1")
    ap.add_argument("--kappa", type=float, default=3.0, help="Kick strength")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    Js = [int(x) for x in args.J.split(",") if x.strip()]
    t0, t1 = [int(x) for x in args.fit_window.split(",")]

    toy = Toy072OTOCRegulatorDependence(kappa=float(args.kappa))
    out_path = args.out.strip() or None
    json_path = toy.export_json(Js=Js, t_max=int(args.t_max), fit_window=[t0, t1], out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
