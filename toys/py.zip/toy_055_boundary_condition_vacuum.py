#!/usr/bin/env python3
"""
Toy 055 — Vacuum selection depends on boundary conditions

Pressure point:
- In QFT, the vacuum is not determined solely by local equations of motion.
- Boundary conditions (spatial, temporal, or asymptotic) select inequivalent vacua.
- “The vacuum” is not an intrinsic object.

Model:
- Free scalar field mode with two boundary conditions:
    (A) Periodic
    (B) Dirichlet
- Compare zero-point energies and mode spectra.

Units: ℏ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy055BoundaryConditionVacuum:
    toy_id = "055"

    def __init__(
        self,
        *,
        L: float = 1.0,
        max_mode: int = 20,
    ) -> None:
        self.L = float(L)
        self.max_mode = int(max_mode)

    def modes_periodic(self) -> List[float]:
        return [2.0 * math.pi * n / self.L for n in range(1, self.max_mode + 1)]

    def modes_dirichlet(self) -> List[float]:
        return [math.pi * n / self.L for n in range(1, self.max_mode + 1)]

    def vacuum_energy(self, modes: List[float]) -> float:
        return 0.5 * sum(abs(k) for k in modes)

    def build_payload(self) -> Dict[str, Any]:
        modes_p = self.modes_periodic()
        modes_d = self.modes_dirichlet()

        E_p = self.vacuum_energy(modes_p)
        E_d = self.vacuum_energy(modes_d)

        sample_points = [{
            "coordinates": {"boundary": "comparison"},
            "curvature_invariants": {
                "analogy": None
            },
            "local_observables": {
                "vacuum_energy_periodic": E_p,
                "vacuum_energy_dirichlet": E_d,
                "energy_difference": E_p - E_d,
            },
            "causal_structure": {
                "note": "Boundary conditions select inequivalent vacua"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (boundary dependence)",
            "spacetime": "1D finite interval",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "L": self.L,
                "max_mode": self.max_mode,
            },
            "notes": {
                "pressure_point": (
                    "Vacuum structure depends on boundary conditions. "
                    "Different boundaries produce inequivalent zero-point energies."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "vacuum_energy_gap": sample_points[0]["local_observables"]["energy_difference"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy055BoundaryConditionVacuum()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
