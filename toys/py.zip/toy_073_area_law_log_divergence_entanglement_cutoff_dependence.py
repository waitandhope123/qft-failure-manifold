#!/usr/bin/env python3
"""
Toy 073 — Entanglement entropy cutoff dependence (1D free scalar / harmonic chain)

What it probes (pressure point):
- Vacuum entanglement entropy is UV divergent and regulator dependent.
- In 1+1D CFT, interval entropy scales ~ (c/3) ln(L/a) + const.
- On a lattice (spacing a), the same subsystem shows logarithmic growth as a -> 0
  at fixed physical interval length L_phys.

Model (controlled, deterministic):
- 1D periodic harmonic chain (discretized free scalar) with N sites, spacing a, mass m:
    H = 1/2 Σ_i [ p_i^2 + m^2 x_i^2 + ( (x_{i+1}-x_i)/a )^2 ]
  (set spring constant so continuum limit is sensible)
- Ground state is Gaussian. For a contiguous block A of length n_A sites,
  entanglement entropy S(A) computed from covariance matrices X, P restricted to A:
    X_ij = <x_i x_j>,  P_ij = <p_i p_j>
  Symplectic eigenvalues ν_k = eigenvalues of sqrt(X_A P_A)
  Von Neumann entropy:
    S = Σ_k [ (ν_k+1/2) ln(ν_k+1/2) - (ν_k-1/2) ln(ν_k-1/2) ]

Cutoff scan:
- Fix physical interval length L_phys and total physical size L_tot.
- Vary lattice spacing a => N = round(L_tot / a), n_A = round(L_phys / a).
- Compute S(a) and compare to expected ~ A + B ln(1/a).

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 073
# ----------------------------

class Toy073EntanglementCutoffDependence:
    toy_id = "073"

    def __init__(self, *, L_tot: float = 40.0, L_phys: float = 10.0, m: float = 0.2) -> None:
        require(L_tot > 0.0, "L_tot must be > 0.")
        require(L_phys > 0.0 and L_phys < L_tot, "Require 0 < L_phys < L_tot.")
        require(m >= 0.0, "m must be >= 0.")
        self.L_tot = float(L_tot)
        self.L_phys = float(L_phys)
        self.m = float(m)

    def _build_modes(self, N: int, a: float) -> np.ndarray:
        """
        Normal mode frequencies for periodic chain:
          ω_k^2 = m^2 + (2/a)^2 sin^2(π k / N)
        """
        k = np.arange(N, dtype=float)
        w2 = (self.m ** 2) + (2.0 / a) ** 2 * (np.sin(np.pi * k / N) ** 2)
        w = np.sqrt(w2)
        return w

    def _covariances(self, N: int, a: float) -> tuple[np.ndarray, np.ndarray]:
        """
        Ground state covariances for periodic Gaussian chain:
          X_ij = (1/2N) Σ_k (1/ω_k) cos(2π k (i-j)/N)
          P_ij = (1/2N) Σ_k (ω_k)   cos(2π k (i-j)/N)

        Return full NxN X and P (Toeplitz/circulant), built via FFT for speed.
        """
        w = self._build_modes(N, a)

        # Fourier coefficients for circulant covariance
        # For real-space covariance c[d] = (1/N) Σ_k f_k e^{i 2π k d/N}
        # Here include factor 1/2.
        fX = 0.5 * (1.0 / w)
        fP = 0.5 * w

        # Inverse FFT gives c[d] for d=0..N-1
        cX = np.fft.ifft(fX).real
        cP = np.fft.ifft(fP).real

        # Build circulant matrices via indexing
        idx = np.arange(N)
        diff = (idx[:, None] - idx[None, :]) % N
        X = cX[diff]
        P = cP[diff]
        return X, P

    def entanglement_entropy_block(self, N: int, a: float, nA: int) -> float:
        require(2 <= nA < N, "Need 2 <= nA < N.")
        X, P = self._covariances(N, a)
        XA = X[:nA, :nA]
        PA = P[:nA, :nA]

        # Symplectic eigenvalues of sqrt(XA PA)
        # Numerical safety: symmetrize
        M = 0.5 * (XA @ PA + (XA @ PA).T)
        eig = np.linalg.eigvalsh(M)
        eig = np.maximum(eig, 0.0)
        nu = np.sqrt(eig)

        # Entropy per mode: s(nu) = (nu+1/2)ln(nu+1/2) - (nu-1/2)ln(nu-1/2)
        # For physical Gaussian states, nu >= 1/2.
        # Numerical clamp:
        nu = np.maximum(nu, 0.5 + 1e-15)

        term1 = (nu + 0.5) * np.log(nu + 0.5)
        term2 = (nu - 0.5) * np.log(nu - 0.5)
        S = float(np.sum(term1 - term2))
        return S

    def build_payload(self, a_values: List[float]) -> Dict[str, Any]:
        require(len(a_values) >= 2, "Need at least two lattice spacings a.")
        require(all(a > 0.0 for a in a_values), "All a must be > 0.")

        sample_points: List[Dict[str, Any]] = []
        records = []

        for a in a_values:
            N = int(round(self.L_tot / a))
            N = max(N, 32)
            if N % 2 == 1:
                N += 1

            nA = int(round(self.L_phys / a))
            nA = max(2, min(nA, N - 2))

            S = self.entanglement_entropy_block(N=N, a=float(a), nA=nA)

            # simple predictor: ln(L_phys/a)
            log_arg = self.L_phys / a
            lnL_over_a = math.log(log_arg) if log_arg > 0 else None

            records.append((a, S, lnL_over_a))

            sample_points.append({
                "coordinates": {
                    "a": float(a),
                    "N_sites": int(N),
                    "nA_sites": int(nA),
                    "L_tot_phys": self.L_tot,
                    "L_A_phys": self.L_phys,
                },
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "entanglement_entropy_S": finite_or_none(S),
                    "ln_L_over_a": finite_or_none(lnL_over_a) if lnL_over_a is not None else None,
                    "interpretation": (
                        "As a decreases at fixed physical interval, vacuum entanglement entropy grows ~ const + B ln(L/a)."
                    ),
                },
                "causal_structure": {
                    "note": "UV cutoff a controls short-distance entanglement; divergence reflects nonlocal vacuum structure.",
                },
            })

        # Fit S ≈ A + B ln(L/a) using least squares (deterministic)
        xs = np.array([r[2] for r in records if r[2] is not None], dtype=float)
        ys = np.array([r[1] for r in records if r[2] is not None], dtype=float)

        fit_A = fit_B = fit_r2 = None
        if len(xs) >= 2:
            Xmat = np.vstack([np.ones_like(xs), xs]).T
            beta, *_ = np.linalg.lstsq(Xmat, ys, rcond=None)
            fit_A, fit_B = float(beta[0]), float(beta[1])
            yhat = Xmat @ beta
            ss_res = float(np.sum((ys - yhat) ** 2))
            ss_tot = float(np.sum((ys - float(np.mean(ys))) ** 2))
            fit_r2 = None if ss_tot == 0.0 else (1.0 - ss_res / ss_tot)

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): vacuum entanglement entropy UV divergence (harmonic chain)",
            "spacetime": "1D lattice regulator (periodic), ground-state Gaussian",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "L_tot": self.L_tot,
                "L_phys_interval": self.L_phys,
                "mass_m": self.m,
                "a_samples": a_values,
            },
            "notes": {
                "pressure_point": (
                    "Vacuum entanglement entropy is UV divergent. Changing the cutoff (lattice spacing a) changes S, "
                    "typically with logarithmic scaling in 1+1D. This demonstrates regulator dependence of entanglement."
                ),
                "key_formulas": {
                    "omega_k": "ω_k^2 = m^2 + (2/a)^2 sin^2(π k / N)",
                    "X_ij": "X_ij=(1/2N) Σ_k (1/ω_k) cos(2π k (i-j)/N)",
                    "P_ij": "P_ij=(1/2N) Σ_k (ω_k) cos(2π k (i-j)/N)",
                    "S": "S=Σ_k[(ν_k+1/2)ln(ν_k+1/2)-(ν_k-1/2)ln(ν_k-1/2)], ν_k=spec(sqrt(X_A P_A))",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "fit_S_vs_ln_L_over_a": {
                    "A_intercept": finite_or_none(fit_A) if fit_A is not None else None,
                    "B_slope": finite_or_none(fit_B) if fit_B is not None else None,
                    "R2": finite_or_none(fit_r2) if fit_r2 is not None else None,
                    "model": "S ≈ A + B ln(L_phys/a)",
                }
            },
        }

    def export_json(self, a_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(a_values=a_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 073: entanglement entropy cutoff dependence in harmonic chain.")
    ap.add_argument("--L_tot", type=float, default=40.0, help="Total physical size")
    ap.add_argument("--L_phys", type=float, default=10.0, help="Subsystem physical length")
    ap.add_argument("--m", type=float, default=0.2, help="Mass parameter m>=0")
    ap.add_argument("--a", type=str, default="1.0,0.8,0.6,0.5,0.4,0.3,0.25,0.2",
                    help="Comma-separated lattice spacings a>0")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy073EntanglementCutoffDependence(L_tot=float(args.L_tot), L_phys=float(args.L_phys), m=float(args.m))
    a_values = parse_csv_floats(args.a)

    out_path = args.out.strip() or None
    json_path = toy.export_json(a_values=a_values, out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
