#!/usr/bin/env python3
"""
Toy 046 — Non-existence of a sharp local stress-energy operator

Pressure point:
- In QFT, local energy density is not a well-defined operator.
- Any attempt to localize energy requires smearing, and results depend on
  the smearing scale and profile.
- There is no invariant, sharply local stress-energy observable.

Model:
- Free scalar field in 1+1D, single mode approximation.
- Define a would-be local energy density operator.
- Compute expectation values under different smearing widths.

Units: ℏ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


class Toy046NoLocalEnergyDensity:
    toy_id = "046"

    def __init__(
        self,
        *,
        omega: float = 1.0,
        smearings: List[float] | None = None,
    ) -> None:
        require(omega > 0.0, "omega > 0")
        self.omega = float(omega)
        self.smearings = smearings or [0.2, 0.5, 1.0, 2.0]

    def smeared_energy(self, sigma: float) -> float:
        """
        Vacuum expectation of smeared energy density proxy.
        Diverges as sigma -> 0.
        """
        require(sigma > 0.0, "sigma > 0")
        return self.omega / (sigma * math.sqrt(math.pi))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for sigma in self.smearings:
            E = self.smeared_energy(sigma)
            sample_points.append({
                "coordinates": {"smearing_width": sigma},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "smeared_energy_density": E,
                },
                "causal_structure": {
                    "note": "Energy density defined only after smearing"
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (localization failure proxy)",
            "spacetime": "1+1D free scalar (single-mode)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "omega": self.omega,
                "smearing_widths": self.smearings,
            },
            "notes": {
                "pressure_point": (
                    "Local stress-energy operators do not exist as sharp observables. "
                    "Energy density depends on smearing scale and diverges as localization "
                    "is sharpened."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "min_smearing": min(self.smearings),
                    "max_energy_density": max(
                        sp["local_observables"]["smeared_energy_density"]
                        for sp in sample_points
                    ),
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy046NoLocalEnergyDensity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
