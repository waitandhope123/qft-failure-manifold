#!/usr/bin/env python3
"""
Toy 016 — State dependence of local energy density (same theory, same spacetime)

Pressure point:
- Local energy density is not fixed by the theory or spacetime alone.
- Different quantum states on the same background yield radically different local observables.
- “Vacuum” is not a unique or privileged state.

Model:
- Free real scalar field in 1+1D
- Compare vacuum, thermal, and squeezed states
- Compute ⟨T_tt⟩ proxy for each state

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


# ----------------------------
# Toy 016
# ----------------------------

class Toy016StateDependentEnergy:
    toy_id = "016"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        temperature: float = 1.0,
        squeeze_r: float = 0.8,
        cutoff: float = 20.0,
        dk: float = 0.02,
    ) -> None:
        self.m = float(mass)
        self.T = float(temperature)
        self.r = float(squeeze_r)
        self.Lambda = float(cutoff)
        self.dk = float(dk)

    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def energy_density_vacuum(self) -> Optional[float]:
        # Divergent; explicitly undefined without renormalization
        return None

    def energy_density_thermal(self) -> float:
        """
        ρ_T = ∫ dk / (2π) ω_k / (exp(ω_k / T) - 1)
        """
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega(k)
            if w > 0:
                s += w / (math.exp(w / self.T) - 1.0)
            k += self.dk
        return s * self.dk / (2.0 * math.pi)

    def energy_density_squeezed(self) -> float:
        """
        Proxy: enhanced occupation n_k ~ sinh^2(r)
        """
        n = math.sinh(self.r) ** 2
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            s += self.omega(k) * n
            k += self.dk
        return s * self.dk / (2.0 * math.pi)

    def build_payload(self) -> Dict[str, Any]:
        rho_vac = self.energy_density_vacuum()
        rho_th = self.energy_density_thermal()
        rho_sq = self.energy_density_squeezed()

        sample_points = [
            {
                "coordinates": {"state": "vacuum"},
                "curvature_invariants": {"cutoff_Lambda": self.Lambda},
                "local_observables": {
                    "energy_density_T_tt": rho_vac,
                },
                "causal_structure": {
                    "state_unique": False,
                },
            },
            {
                "coordinates": {"state": "thermal"},
                "curvature_invariants": {"temperature": self.T},
                "local_observables": {
                    "energy_density_T_tt": rho_th,
                },
                "causal_structure": {
                    "state_unique": False,
                },
            },
            {
                "coordinates": {"state": "squeezed"},
                "curvature_invariants": {"squeeze_parameter_r": self.r},
                "local_observables": {
                    "energy_density_T_tt": rho_sq,
                },
                "causal_structure": {
                    "state_unique": False,
                },
            },
        ]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "temperature": self.T,
                "squeeze_r": self.r,
                "cutoff_Lambda": self.Lambda,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Different quantum states on same background",
                    "Energy density computed as regulated proxy",
                ],
                "pressure_point": (
                    "Local observables depend strongly on quantum state. "
                    "Geometry and field content alone do not fix physical measurements."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "comparison": "⟨T_tt⟩ differs by state despite identical theory and spacetime."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    Toy016StateDependentEnergy().export_json()


if __name__ == "__main__":
    main()
