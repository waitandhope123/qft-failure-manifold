#!/usr/bin/env python3
"""
Toy 061 — Truncation-induced unitarity breakdown (single-mode squeezing)

What it probes (pressure point):
- Exact QFT-like dynamics (here: a single bosonic mode under squeezing / Bogoliubov evolution)
  produces support over arbitrarily high occupation numbers.
- Any hard truncation of the Hilbert space (n <= Nmax) necessarily discards amplitude.
  If you keep the truncated state without renormalizing, its norm decays (<1): an operational
  "non-unitarity" induced purely by truncation.
- Even if you renormalize, observables become cutoff-dependent as probability leaks beyond Nmax.

Model (controlled, analytic):
- Squeezed vacuum |0;r> of a single bosonic mode with squeeze parameter r(t)=gamma*t.
- Exact number distribution lives on even n only:
    P(2k) = (1/cosh r) * [ (2k)! / (2^{2k} (k!)^2 ) ] * (tanh r)^{2k}
    P(odd) = 0
- Exact mean occupation: <n>_exact = sinh^2 r

Truncation:
- Keep only n <= Nmax (equivalently k <= floor(Nmax/2)).
- Retained norm: Z(Nmax) = sum_{n<=Nmax} P(n)  (<=1)
- Leakage: 1 - Z
- Truncated mean (raw, not renormalized): <n>_raw = sum_{n<=Nmax} n P(n)
- Truncated mean (conditioned, renormalized): <n>_cond = <n>_raw / Z  (if Z>0)

Export:
- Strict lab JSON schema (same top-level keys as GR lab protocol).
- Writes <script_name>.json by default.

Determinism:
- No randomness. Purely analytic probabilities.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


def log_binom_2k_k(k: int) -> float:
    """
    log( (2k)! / (k!)^2 ) using lgamma for stability.
    """
    require(k >= 0, "k must be >= 0")
    return math.lgamma(2 * k + 1) - 2.0 * math.lgamma(k + 1)


# ----------------------------
# Toy 061
# ----------------------------

class Toy061TruncationInducedUnitarityBreakdown:
    toy_id = "061"

    def __init__(self, gamma: float = 0.5) -> None:
        require(gamma > 0.0, "gamma must be > 0.")
        self.gamma = float(gamma)

    def r_of_t(self, t: float) -> float:
        return self.gamma * float(t)

    def p_2k(self, r: float, k: int) -> float:
        """
        P(2k) for squeezed vacuum.

        P(2k) = (1/cosh r) * C(2k,k) / 4^k * (tanh r)^(2k)

        Computed in log space for stability:
        log P = -log(cosh r) + log C(2k,k) - k log 4 + 2k log(tanh r)
        """
        require(k >= 0, "k must be >= 0")
        # handle r ~ 0 safely
        if r == 0.0:
            return 1.0 if k == 0 else 0.0

        th = math.tanh(r)
        ch = math.cosh(r)
        # tanh(r) in (0,1); log ok
        logP = -math.log(ch) + log_binom_2k_k(k) - k * math.log(4.0) + (2.0 * k) * math.log(th)
        # exp could underflow for large k; that's fine (prob ~ 0)
        return math.exp(logP)

    def exact_mean_n(self, r: float) -> float:
        return math.sinh(r) ** 2

    def truncation_stats(self, r: float, Nmax: int) -> Dict[str, Any]:
        require(Nmax >= 0, "Nmax must be >= 0")
        kmax = Nmax // 2

        Z = 0.0
        n_raw = 0.0

        for k in range(0, kmax + 1):
            p = self.p_2k(r, k)
            n = 2 * k
            Z += p
            n_raw += n * p

        leaked = 1.0 - Z
        n_cond = None if Z <= 0.0 else (n_raw / Z)

        n_exact = self.exact_mean_n(r)

        rel_err_raw = None
        if n_exact != 0.0:
            rel_err_raw = (n_raw - n_exact) / n_exact

        rel_err_cond = None
        if n_cond is not None and n_exact != 0.0:
            rel_err_cond = (n_cond - n_exact) / n_exact

        return {
            "retained_norm_Z": finite_or_none(Z),
            "leakage_1_minus_Z": finite_or_none(leaked),
            "mean_occupation_exact_sinh2r": finite_or_none(n_exact),
            "mean_occupation_truncated_raw": finite_or_none(n_raw),
            "mean_occupation_truncated_conditioned": finite_or_none(n_cond) if n_cond is not None else None,
            "relative_error_raw_vs_exact": finite_or_none(rel_err_raw) if rel_err_raw is not None else None,
            "relative_error_conditioned_vs_exact": finite_or_none(rel_err_cond) if rel_err_cond is not None else None,
            "kmax_floor_Nmax_over_2": kmax,
        }

    def build_payload(self, t_values: List[float], Nmax_values: List[int]) -> Dict[str, Any]:
        require(len(t_values) >= 1, "Need at least one t sample.")
        require(len(Nmax_values) >= 1, "Need at least one Nmax sample.")
        require(all(t >= 0.0 for t in t_values), "All t must be >= 0.")
        require(all(N >= 0 for N in Nmax_values), "All Nmax must be >= 0.")

        sample_points: List[Dict[str, Any]] = []

        for t in t_values:
            r = self.r_of_t(t)
            for Nmax in Nmax_values:
                stats = self.truncation_stats(r=r, Nmax=Nmax)

                sample_points.append({
                    "coordinates": {
                        "t": float(t),
                        "r_squeeze": finite_or_none(r),
                        "Nmax_truncation": int(Nmax),
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "QFT toy (no spacetime curvature invariants).",
                    },
                    "local_observables": {
                        "dynamics": {
                            "model": "single_mode_squeezed_vacuum",
                            "r_of_t": "r(t)=gamma*t",
                            "gamma": self.gamma,
                        },
                        "truncation": {
                            **stats,
                            "interpretation": (
                                "Z<1 indicates amplitude discarded by truncation (operational non-unitarity). "
                                "Conditioned observables (renormalized) remain cutoff-dependent as leakage grows."
                            ),
                        },
                    },
                    "causal_structure": {
                        "microcausality": None,
                        "note": "This toy targets Hilbert-space truncation, not spacetime causality.",
                    },
                })

        # Summaries: worst leakage across grid, and worst relative error (conditioned) where defined
        max_leak = 0.0
        max_abs_rel_err_cond = 0.0
        any_rel_err_cond = False

        for sp in sample_points:
            leak = sp["local_observables"]["truncation"]["leakage_1_minus_Z"]
            if leak is not None:
                max_leak = max(max_leak, float(leak))

            rec = sp["local_observables"]["truncation"]["relative_error_conditioned_vs_exact"]
            if rec is not None:
                any_rel_err_cond = True
                max_abs_rel_err_cond = max(max_abs_rel_err_cond, abs(float(rec)))

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): single-mode Bogoliubov/squeezing + Hilbert-space truncation",
            "spacetime": "N/A (flat background; mode-level model)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "gamma": self.gamma,
                "t_samples": t_values,
                "Nmax_samples": Nmax_values,
            },
            "notes": {
                "pressure_point": (
                    "Unitary evolution can require unbounded Hilbert-space support. "
                    "Hard truncations necessarily discard amplitude, inducing operational non-unitarity (norm loss) "
                    "and cutoff-dependent observables even after renormalization."
                ),
                "key_formulas": {
                    "r(t)": "r(t)=gamma*t",
                    "P(2k)": "P(2k)=(1/cosh r)*[(2k)!/(2^{2k}(k!)^2)]*(tanh r)^{2k}",
                    "n_exact": "<n> = sinh^2 r",
                    "Z_trunc": "Z(Nmax)=sum_{n<=Nmax} P(n)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_leakage_over_grid": finite_or_none(max_leak),
                    "max_abs_relative_error_conditioned_over_grid": (
                        finite_or_none(max_abs_rel_err_cond) if any_rel_err_cond else None
                    ),
                }
            },
        }

    def export_json(self, t_values: List[float], Nmax_values: List[int], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_values=t_values, Nmax_values=Nmax_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 061: truncation-induced unitarity breakdown via squeezed-vacuum leakage.")
    ap.add_argument("--gamma", type=float, default=0.5, help="Squeeze growth rate: r(t)=gamma*t (gamma>0)")
    ap.add_argument("--t", type=str, default="0,0.5,1,1.5,2,2.5,3", help="Comma-separated times t>=0")
    ap.add_argument("--Nmax", type=str, default="2,4,6,10,20,40", help="Comma-separated occupation cutoffs Nmax>=0")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy061TruncationInducedUnitarityBreakdown(gamma=float(args.gamma))
    t_values = parse_csv_floats(args.t)
    Nmax_values = parse_csv_ints(args.Nmax)

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, Nmax_values=Nmax_values, out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
