#!/usr/bin/env python3
"""
Toy 070 — IR superselection & nonseparable Hilbert space (sector explosion proxy)

What it probes (pressure point):
- In QFT with long-range fields (massless gauge bosons / gravity), conserved charges and
  asymptotic symmetries can lead to superselection sectors labeled by continuous data
  (e.g., soft charges / dressing profiles).
- If sectors are continuously labeled, the physical state space behaves like a direct integral
  over sectors rather than a single separable Hilbert space with one cyclic vacuum.
- Operationally: finite measurements in a bounded region cannot distinguish sectors, but
  globally they are orthogonal (no finite-energy operator connects them).

Model (controlled proxy):
- Consider a family of IR sectors labeled by a continuous parameter α ∈ [0,1].
- States from different sectors have overlap:
    |⟨α | β⟩|^2 = exp( - C * |α-β|^2 / Λ_ir )
  with C>0 and Λ_ir an IR regulator. As Λ_ir -> 0, distinct sectors become orthogonal.
- Discretize α into M bins; as Λ_ir decreases, effective dimension (number of nearly-orthogonal
  sectors) increases.

Diagnostics:
- For given (Λ_ir, M), build the Gram matrix G_{ij} = ⟨α_i|α_j⟩
- Compute:
  * effective rank via eigenvalue threshold
  * participation ratio (1 / Σ p_i^2) for normalized eigenvalues
  * average off-diagonal overlap
- Shows "sector explosion" as Λ_ir -> 0.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


def jacobi_eigvals_symmetric(A: List[List[float]], tol: float = 1e-12, max_sweeps: int = 200) -> List[float]:
    """
    Simple deterministic Jacobi eigenvalue algorithm for small symmetric matrices.
    O(n^3) but fine for M<=200ish. Avoids external deps.
    Returns eigenvalues.
    """
    n = len(A)
    # copy
    a = [row[:] for row in A]

    for _ in range(max_sweeps):
        # find largest off-diagonal
        p = q = 0
        max_val = 0.0
        for i in range(n):
            for j in range(i + 1, n):
                v = abs(a[i][j])
                if v > max_val:
                    max_val = v
                    p, q = i, j

        if max_val < tol:
            break

        app = a[p][p]
        aqq = a[q][q]
        apq = a[p][q]

        phi = 0.5 * math.atan2(2.0 * apq, (aqq - app))
        c = math.cos(phi)
        s = math.sin(phi)

        # rotate
        for k in range(n):
            if k != p and k != q:
                aik = a[p][k]
                akq = a[q][k]
                a[p][k] = c * aik - s * akq
                a[k][p] = a[p][k]
                a[q][k] = s * aik + c * akq
                a[k][q] = a[q][k]

        a[p][p] = c * c * app - 2.0 * s * c * apq + s * s * aqq
        a[q][q] = s * s * app + 2.0 * s * c * apq + c * c * aqq
        a[p][q] = 0.0
        a[q][p] = 0.0

    return [a[i][i] for i in range(n)]


# ----------------------------
# Toy 070
# ----------------------------

class Toy070HilbertSpaceNonseparabilityIRSuperselection:
    toy_id = "070"

    def __init__(self, *, C: float = 1.0) -> None:
        require(C > 0.0, "C must be > 0.")
        self.C = float(C)

    def overlap(self, alpha: float, beta: float, Lambda_ir: float) -> float:
        """
        ⟨α|β⟩ = exp( - (C/2) * |α-β|^2 / Λ_ir )
        (Amplitude; squared overlap would have C * ... / Λ_ir)
        """
        require(Lambda_ir > 0.0, "Lambda_ir must be > 0.")
        d = alpha - beta
        return math.exp(-0.5 * self.C * (d * d) / Lambda_ir)

    def gram_matrix(self, M: int, Lambda_ir: float) -> List[List[float]]:
        require(M >= 2, "M must be >= 2.")
        alphas = [i / (M - 1) for i in range(M)]
        G = [[0.0 for _ in range(M)] for _ in range(M)]
        for i in range(M):
            for j in range(M):
                G[i][j] = self.overlap(alphas[i], alphas[j], Lambda_ir)
        return G

    def metrics(self, M: int, Lambda_ir: float, eig_tol: float) -> Dict[str, Any]:
        G = self.gram_matrix(M, Lambda_ir)
        eigs = jacobi_eigvals_symmetric(G, tol=1e-12, max_sweeps=400)
        # numerical cleanup
        eigs = [max(0.0, float(e)) for e in eigs]

        # effective rank: count eigenvalues above eig_tol * max_eig
        max_e = max(eigs) if eigs else 0.0
        thr = eig_tol * max_e if max_e > 0.0 else 0.0
        eff_rank = sum(1 for e in eigs if e > thr)

        # participation ratio of normalized eigenvalues
        s = sum(eigs)
        pr = None
        if s > 0.0:
            p = [e / s for e in eigs]
            pr = 1.0 / sum(pi * pi for pi in p)

        # average off-diagonal overlap
        off_sum = 0.0
        off_ct = 0
        for i in range(M):
            for j in range(M):
                if i != j:
                    off_sum += G[i][j]
                    off_ct += 1
        avg_off = off_sum / off_ct if off_ct else 0.0

        return {
            "effective_rank": eff_rank,
            "participation_ratio": finite_or_none(pr) if pr is not None else None,
            "avg_off_diagonal_overlap": finite_or_none(avg_off),
            "max_eigenvalue": finite_or_none(max_e),
            "eig_threshold_used": finite_or_none(thr),
        }

    def build_payload(self, Lambda_ir_values: List[float], M_values: List[int], eig_tol: float) -> Dict[str, Any]:
        require(len(Lambda_ir_values) >= 1, "Need Lambda_ir samples.")
        require(len(M_values) >= 1, "Need M samples.")
        require(all(L > 0.0 for L in Lambda_ir_values), "All Lambda_ir must be > 0.")
        require(all(M >= 2 for M in M_values), "All M must be >= 2.")
        require(eig_tol > 0.0, "eig_tol must be > 0.")

        sample_points: List[Dict[str, Any]] = []

        max_eff_rank = 0
        for L in Lambda_ir_values:
            for M in M_values:
                met = self.metrics(M=int(M), Lambda_ir=float(L), eig_tol=float(eig_tol))
                max_eff_rank = max(max_eff_rank, int(met["effective_rank"]))

                sample_points.append({
                    "coordinates": {
                        "Lambda_ir": float(L),
                        "M_sectors_discretized": int(M),
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "QFT toy; no spacetime curvature.",
                    },
                    "local_observables": {
                        "sector_model": {
                            "alpha_range": [0.0, 1.0],
                            "C": self.C,
                            "overlap_amp": "exp(-(C/2)*(alpha-beta)^2/Lambda_ir)",
                        },
                        "gram_matrix_metrics": met,
                        "interpretation": (
                            "As Lambda_ir decreases, distinct IR sectors become orthogonal and the effective number "
                            "of superselection sectors increases (nonseparability/sector explosion proxy)."
                        ),
                    },
                    "causal_structure": {
                        "note": "Superselection prevents finite operators from connecting sectors; locality hides sector labels.",
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): IR superselection / nonseparable sector structure proxy",
            "spacetime": "Asymptotic IR structure (no local probe)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "C": self.C,
                "Lambda_ir_samples": Lambda_ir_values,
                "M_samples": M_values,
                "eig_tol_fraction_of_max": eig_tol,
            },
            "notes": {
                "pressure_point": (
                    "IR structure can produce continuously-labeled superselection sectors. "
                    "As the IR regulator is removed, sectors become orthogonal, effectively enlarging the state space "
                    "beyond a single separable Hilbert space picture."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_effective_rank_over_samples": max_eff_rank,
                }
            },
        }

    def export_json(self, Lambda_ir_values: List[float], M_values: List[int], eig_tol: float,
                    out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(Lambda_ir_values=Lambda_ir_values, M_values=M_values, eig_tol=eig_tol)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 070: IR superselection sector explosion / nonseparability proxy.")
    ap.add_argument("--C", type=float, default=1.0, help="Overlap decay coefficient C (>0)")
    ap.add_argument("--Lambda_ir", type=str, default="1e-1,3e-2,1e-2,3e-3,1e-3,3e-4,1e-4",
                    help="Comma-separated IR regulators (>0)")
    ap.add_argument("--M", type=str, default="10,20,40,80,120", help="Comma-separated discretization sizes M>=2")
    ap.add_argument("--eig_tol", type=float, default=1e-3, help="Eigenvalue threshold as fraction of max eigenvalue")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy070HilbertSpaceNonseparabilityIRSuperselection(C=float(args.C))
    Lvals = parse_csv_floats(args.Lambda_ir)
    Mvals = parse_csv_ints(args.M)

    out_path = args.out.strip() or None
    json_path = toy.export_json(Lambda_ir_values=Lvals, M_values=Mvals, eig_tol=float(args.eig_tol), out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
