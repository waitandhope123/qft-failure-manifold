#!/usr/bin/env python3
"""
Toy 097 — Operator-algebra reconstruction non-uniqueness (entanglement / center choice boundary)

What it probes (pressure point):
- "Reconstruct the global state from local data" can fail: many inequivalent global states share
  identical reduced states on overlapping subsystems.
- In gauge theories / AQFT, the choice of local algebra (presence of a center / edge modes) changes
  what "the reduced state" even means. Factorization is not canonical.
- This toy makes that boundary explicit with finite-dimensional algebras: same local marginals,
  different global correlations.

Model (deterministic, finite Hilbert space):
- Three qubits A, B, C with global density matrix ρ_ABC.
- We construct two distinct global states:
    ρ^(1): a GHZ-class pure state (|000>+|111>)/√2
    ρ^(2): a classical mixture 1/2 |000><000| + 1/2 |111><111|
  These have the SAME two-body marginals on AB and BC (and AC), but different global structure
  (different tripartite correlations; one is pure entangled, the other is mixed classical).

- "Algebra choice" proxy:
  Define two reconstructions from the same AB and BC marginals:
    * max_entropy reconstruction (Jaynes): ρ_ME = argmax S(ρ) subject to fixed ρ_AB and ρ_BC
      (approximated by an iterative proportional fitting / quantum IPF loop)
    * center-extended reconstruction: treat B as having an explicit classical center label z∈{0,1}
      and reconstruct block-diagonal state consistent with marginals (yields the mixture).

Diagnostics:
- Compare reconstructions to true states using:
    * global purity Tr(ρ^2)
    * tripartite mutual information proxy:
        I3 = S(A)+S(B)+S(C) - S(AB) - S(AC) - S(BC) + S(ABC)
    * fidelity to GHZ state projector (overlap with |GHZ><GHZ|)

Determinism:
- No randomness. Fixed iterative loops with fixed tolerance/iterations.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"

def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)

def kron(*ops: np.ndarray) -> np.ndarray:
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out

def dagger(M: np.ndarray) -> np.ndarray:
    return np.conjugate(M.T)

def normalize_density(rho: np.ndarray) -> np.ndarray:
    tr = np.trace(rho).real
    if tr <= 0:
        return rho
    return rho / tr

def partial_trace(rho: np.ndarray, keep: List[int], dims: List[int]) -> np.ndarray:
    """
    Partial trace for small systems.
    dims: list of subsystem dimensions, e.g. [2,2,2]
    keep: indices to keep (0=A,1=B,2=C)
    """
    dims = list(dims)
    n = len(dims)

    D = int(np.prod(dims))
    assert rho.shape == (D, D), f"rho shape {rho.shape} incompatible with dims {dims}"

    keep = sorted(keep)
    trace_out = [i for i in range(n) if i not in keep]

    reshaped = rho.reshape(dims + dims)

    # IMPORTANT: after each trace, total subsystems decreases by 1
    cur_n = n
    for i in sorted(trace_out, reverse=True):
        reshaped = np.trace(reshaped, axis1=i, axis2=i + cur_n)
        cur_n -= 1

    new_dims = [dims[i] for i in keep]
    d_keep = int(np.prod(new_dims))
    return reshaped.reshape(d_keep, d_keep)

def von_neumann_entropy(rho: np.ndarray, eps: float = 1e-15) -> float:
    rhoH = 0.5 * (rho + dagger(rho))
    vals = np.linalg.eigvalsh(rhoH)
    vals = np.maximum(vals.real, 0.0)
    vals = vals / (np.sum(vals) + eps)
    s = 0.0
    for lam in vals:
        if lam > eps:
            s -= float(lam) * math.log(float(lam))
    return s

def purity(rho: np.ndarray) -> float:
    return float(np.trace(rho @ rho).real)

def fidelity_with_projector(rho: np.ndarray, P: np.ndarray) -> float:
    # For projector P=|ψ><ψ|, fidelity = Tr(P rho)
    return float(np.trace(P @ rho).real)


# ----------------------------
# Toy 097
# ----------------------------

class Toy097OperatorAlgebraReconstructionNonUniqueness:
    toy_id = "097"

    def __init__(self, *, ipf_iters: int = 80, ipf_eps: float = 1e-10) -> None:
        require(ipf_iters >= 1, "ipf_iters must be >= 1.")
        require(ipf_eps > 0.0, "ipf_eps must be > 0.")
        self.ipf_iters = int(ipf_iters)
        self.ipf_eps = float(ipf_eps)
        self.dims = [2, 2, 2]  # A,B,C

        # computational basis projectors
        self.P0 = np.array([[1.0, 0.0], [0.0, 0.0]])
        self.P1 = np.array([[0.0, 0.0], [0.0, 1.0]])
        self.I2 = np.eye(2)

        # GHZ state
        ghz = np.zeros((8, 1), dtype=complex)
        ghz[0, 0] = 1.0 / math.sqrt(2.0)
        ghz[7, 0] = 1.0 / math.sqrt(2.0)
        self.P_GHZ = ghz @ dagger(ghz)

    def state_ghz_pure(self) -> np.ndarray:
        return self.P_GHZ.copy()

    def state_classical_mixture(self) -> np.ndarray:
        # 1/2 |000><000| + 1/2 |111><111|
        rho = np.zeros((8, 8), dtype=complex)
        rho[0, 0] = 0.5
        rho[7, 7] = 0.5
        return rho

    def max_entropy_reconstruct_from_marginals(self, rho_ab: np.ndarray, rho_bc: np.ndarray) -> np.ndarray:
        """
        Quantum IPF-like projection:
        - Start from maximally mixed state.
        - Alternately replace AB marginal and BC marginal using
          exponential map approximation: ρ <- exp(log ρ + log target_marg - log current_marg)
        For 8x8 this is manageable. Deterministic fixed iteration count.

        Note: This is a toy proxy for max-entropy consistent state.
        """
        rho = np.eye(8, dtype=complex) / 8.0

        def logm_psd(M: np.ndarray) -> np.ndarray:
            MH = 0.5 * (M + dagger(M))
            vals, vecs = np.linalg.eigh(MH)
            vals = np.maximum(vals.real, self.ipf_eps)
            return vecs @ np.diag(np.log(vals)) @ dagger(vecs)

        def expm_herm(H: np.ndarray) -> np.ndarray:
            HH = 0.5 * (H + dagger(H))
            vals, vecs = np.linalg.eigh(HH)
            vals = vals.real
            return vecs @ np.diag(np.exp(vals)) @ dagger(vecs)

        for _ in range(self.ipf_iters):
            # enforce AB
            cur_ab = partial_trace(rho, keep=[0, 1], dims=self.dims)
            # lift to ABC by tensoring identity on C (approximate)
            lift_ab = kron(np.eye(4), self.I2)  # acts as placeholder, not used directly

            # Update: rho <- exp(log rho + log(rho_ab⊗I/2) - log(cur_ab⊗I/2))
            rho_ab_lift = kron(rho_ab, self.I2 / 2.0)
            cur_ab_lift = kron(cur_ab, self.I2 / 2.0)
            rho = expm_herm(logm_psd(rho) + logm_psd(rho_ab_lift) - logm_psd(cur_ab_lift))
            rho = normalize_density(rho)

            # enforce BC
            cur_bc = partial_trace(rho, keep=[1, 2], dims=self.dims)
            rho_bc_lift = kron(self.I2 / 2.0, rho_bc)
            cur_bc_lift = kron(self.I2 / 2.0, cur_bc)
            rho = expm_herm(logm_psd(rho) + logm_psd(rho_bc_lift) - logm_psd(cur_bc_lift))
            rho = normalize_density(rho)

        # clip tiny negatives via eig cleanup
        rhoH = 0.5 * (rho + dagger(rho))
        vals, vecs = np.linalg.eigh(rhoH)
        vals = np.maximum(vals.real, 0.0)
        rho_clean = vecs @ np.diag(vals) @ dagger(vecs)
        return normalize_density(rho_clean)

    def center_extended_reconstruction(self, rho_ab: np.ndarray, rho_bc: np.ndarray) -> np.ndarray:
        """
        Center/edge-mode proxy:
        - Extract the diagonal of B in the computational basis as a "center label".
        - Reconstruct a block-diagonal state consistent with those classical weights,
          producing a mixture-like global state.
        This intentionally mirrors how adding a center can restore factorization at the price
        of extra superselection structure.
        """
        # p(z) from B marginal
        rho_b = partial_trace(rho_ab, keep=[1], dims=[2, 2])
        p0 = float(np.trace(self.P0 @ rho_b).real)
        p1 = float(np.trace(self.P1 @ rho_b).real)

        # conditional AB and BC blocks (toy: take projective slices)
        # AB|B=z
        AB0 = (kron(self.I2, self.P0) @ rho_ab @ kron(self.I2, self.P0))
        AB1 = (kron(self.I2, self.P1) @ rho_ab @ kron(self.I2, self.P1))
        # normalize within block
        AB0 = normalize_density(AB0) if p0 > 0 else AB0
        AB1 = normalize_density(AB1) if p1 > 0 else AB1

        # BC|B=z
        BC0 = (kron(self.P0, self.I2) @ rho_bc @ kron(self.P0, self.I2))
        BC1 = (kron(self.P1, self.I2) @ rho_bc @ kron(self.P1, self.I2))
        BC0 = normalize_density(BC0) if p0 > 0 else BC0
        BC1 = normalize_density(BC1) if p1 > 0 else BC1

        # build ρ_ABC = sum_z p(z) ρ_{A|z} ⊗ |z><z| ⊗ ρ_{C|z}
        # Extract ρ_{A|z} from ABz by tracing B, and ρ_{C|z} from BCz by tracing B.
        rho = np.zeros((8, 8), dtype=complex)
        for z, pz, ABz, BCz, Pz in [
            (0, p0, AB0, BC0, self.P0),
            (1, p1, AB1, BC1, self.P1),
        ]:
            if pz <= 0:
                continue
            rhoA = partial_trace(ABz, keep=[0], dims=[2, 2])
            rhoC = partial_trace(BCz, keep=[1], dims=[2, 2])  # in BC, keep C is index 1
            block = kron(rhoA, Pz, rhoC)
            rho += pz * block
        return normalize_density(rho)

    def diagnostics(self, rho: np.ndarray) -> Dict[str, Any]:
        rhoA = partial_trace(rho, keep=[0], dims=self.dims)
        rhoB = partial_trace(rho, keep=[1], dims=self.dims)
        rhoC = partial_trace(rho, keep=[2], dims=self.dims)
        rhoAB = partial_trace(rho, keep=[0, 1], dims=self.dims)
        rhoAC = partial_trace(rho, keep=[0, 2], dims=self.dims)
        rhoBC = partial_trace(rho, keep=[1, 2], dims=self.dims)

        SA = von_neumann_entropy(rhoA)
        SB = von_neumann_entropy(rhoB)
        SC = von_neumann_entropy(rhoC)
        SAB = von_neumann_entropy(rhoAB)
        SAC = von_neumann_entropy(rhoAC)
        SBC = von_neumann_entropy(rhoBC)
        SABC = von_neumann_entropy(rho)

        I3 = SA + SB + SC - SAB - SAC - SBC + SABC

        return {
            "purity_Tr_rho2": finite_or_none(purity(rho)),
            "S_A": finite_or_none(SA),
            "S_B": finite_or_none(SB),
            "S_C": finite_or_none(SC),
            "S_AB": finite_or_none(SAB),
            "S_AC": finite_or_none(SAC),
            "S_BC": finite_or_none(SBC),
            "S_ABC": finite_or_none(SABC),
            "I3_tripartite_mutual_info": finite_or_none(I3),
            "fidelity_with_GHZ_projector": finite_or_none(fidelity_with_projector(rho, self.P_GHZ)),
        }

    def build_payload(self) -> Dict[str, Any]:
        rho1 = self.state_ghz_pure()
        rho2 = self.state_classical_mixture()

        # local marginals (same for both)
        rho1_ab = partial_trace(rho1, keep=[0, 1], dims=self.dims)
        rho1_bc = partial_trace(rho1, keep=[1, 2], dims=self.dims)

        rho2_ab = partial_trace(rho2, keep=[0, 1], dims=self.dims)
        rho2_bc = partial_trace(rho2, keep=[1, 2], dims=self.dims)

        # verify marginals match (numerically)
        ab_diff = float(np.linalg.norm(rho1_ab - rho2_ab))
        bc_diff = float(np.linalg.norm(rho1_bc - rho2_bc))

        # reconstructions from the same marginals
        rho_ME = self.max_entropy_reconstruct_from_marginals(rho1_ab, rho1_bc)
        rho_center = self.center_extended_reconstruction(rho1_ab, rho1_bc)

        d1 = self.diagnostics(rho1)
        d2 = self.diagnostics(rho2)
        dME = self.diagnostics(rho_ME)
        dC = self.diagnostics(rho_center)

        sample_points = [
            {
                "coordinates": {"case": "true_state_ghz_pure"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Finite algebra toy."},
                "local_observables": d1,
                "causal_structure": {"note": "Global state with strong tripartite entanglement."},
            },
            {
                "coordinates": {"case": "true_state_classical_mixture"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Finite algebra toy."},
                "local_observables": d2,
                "causal_structure": {"note": "Same local marginals as GHZ, different global correlations."},
            },
            {
                "coordinates": {"case": "reconstruction_max_entropy_from_AB_BC"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Finite algebra toy."},
                "local_observables": dME,
                "causal_structure": {"note": "Max-entropy prior selects one completion of the same local data."},
            },
            {
                "coordinates": {"case": "reconstruction_center_extended"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Finite algebra toy."},
                "local_observables": dC,
                "causal_structure": {"note": "Adding a center/edge-mode label selects a different completion."},
            },
        ]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): operator-algebra reconstruction non-uniqueness (center choice)",
            "spacetime": "Finite-dimensional operator algebra proxy (three-qubit system)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "system": "Three qubits A,B,C",
                "reconstruction_inputs": "rho_AB and rho_BC (identical for GHZ and mixture)",
                "ipf_iters": self.ipf_iters,
                "ipf_eps": self.ipf_eps,
            },
            "notes": {
                "pressure_point": (
                    "Local data (overlapping marginals) need not fix a unique global state; "
                    "the choice of operator algebra / center (edge modes) changes reconstruction. "
                    "This mirrors factorization ambiguities in AQFT/gauge theories."
                ),
                "marginal_checks": {
                    "||rho_AB(GHZ)-rho_AB(mix)||": finite_or_none(ab_diff),
                    "||rho_BC(GHZ)-rho_BC(mix)||": finite_or_none(bc_diff),
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "marginals_match_within_numerical_norm": (ab_diff < 1e-12 and bc_diff < 1e-12),
                    "key_signal": (
                        "True states share identical local marginals, but differ in purity and GHZ overlap; "
                        "reconstructions differ depending on prior/center choice."
                    ),
                }
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 097: operator-algebra reconstruction non-uniqueness.")
    ap.add_argument("--ipf_iters", type=int, default=80, help="Iterations for max-entropy IPF-like reconstruction")
    ap.add_argument("--ipf_eps", type=float, default=1e-10, help="Eigenvalue floor for logs")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy097OperatorAlgebraReconstructionNonUniqueness(ipf_iters=int(args.ipf_iters), ipf_eps=float(args.ipf_eps))
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
