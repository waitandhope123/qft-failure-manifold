#!/usr/bin/env python3
"""
Toy 092 — Ward identity / gauge invariance audit under regulator choice (scheme dependence proxy)

What it probes (pressure point):
- Gauge invariance is not automatic under naive regulators (e.g., hard momentum cutoffs).
- Ward identities can be violated by the regulator, and "fixing" them may require
  counterterms that are not uniquely determined by low-energy data (scheme dependence).
- Compares a gauge-respecting scheme vs a gauge-breaking scheme using a deterministic proxy integral.

Model (deterministic proxy):
- Consider a would-be transverse vacuum polarization tensor:
    Π_{μν}(p) = (p_μ p_ν - p^2 δ_{μν}) Π(p^2)   if Ward identity holds (p_μ Π_{μν}=0).
- We do not compute real QED/QCD loops; instead we compute two scalar proxy integrals that should match
  if the scheme preserves the identity:
    I1(Λ,p) = ∫_{|k|<Λ} d^4k  1/((k^2+m^2)((k+p)^2+m^2))
    I2(Λ,p) = ∫_{|k|<Λ} d^4k  (k·(k+p))/((k^2+m^2)((k+p)^2+m^2))
  In a gauge-respecting regularization (dim-reg-like), a specific linear relation holds between these
  after renormalization; hard cutoffs generically spoil it.

- We define a Ward residual:
    W = | I2 - R(p,m)*I1 |
  with R chosen from the dim-reg-like reference at large Λ (calibrated once).

- Two "schemes":
  * "dimreg_proxy": uses analytic UV subtraction (explicitly subtracts leading Λ^2 and log Λ terms)
  * "hard_cutoff": uses plain cutoff without subtraction (or with limited subtraction)

Numerics:
- Deterministic 4D radial integration reduced to 1D using angular average approximation:
  Replace |k+p|^2 by k^2 + p^2 in denominators (keeps UV behavior, kills exact gauge structure),
  which is precisely what makes scheme dependence visible in a toy way.

Outputs:
- Scan over Λ and p, export I1, I2 in both schemes, Ward residuals, and "counterterm fix" amount:
    δ = (I2 - R I1)  (the amount you'd need to add/subtract to enforce the identity)

Determinism:
- No randomness.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def linspace(a: float, b: float, n: int) -> List[float]:
    require(n >= 2, "linspace requires n>=2")
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


# ----------------------------
# Toy 092
# ----------------------------

class Toy092WardIdentityRegulatorDependenceAudit:
    toy_id = "092"

    def __init__(
        self,
        *,
        m: float = 1.0,
        n_k: int = 4000,
    ) -> None:
        require(m > 0.0, "m must be > 0.")
        require(n_k >= 1000, "n_k must be >= 1000 for decent quadrature.")
        self.m = float(m)
        self.n_k = int(n_k)

    # 4D measure: d^4k = 2π^2 k^3 dk
    def _measure(self, k: float) -> float:
        return 2.0 * (math.pi ** 2) * (k ** 3)

    def _den(self, k: float, p: float) -> float:
        # angular-averaged proxy: (k^2+m^2)((k^2+p^2)+m^2)
        return (k * k + self.m * self.m) * (k * k + p * p + self.m * self.m)

    def I1_cutoff(self, Lam: float, p: float) -> float:
        # ∫_{0}^{Λ} 2π^2 k^3 dk / den
        Lam = float(Lam)
        p = float(p)
        dk = Lam / self.n_k
        s = 0.0
        for i in range(self.n_k + 1):
            k = i * dk
            w = 0.5 if (i == 0 or i == self.n_k) else 1.0
            s += w * self._measure(k) / self._den(k, p)
        return s * dk

    def I2_cutoff(self, Lam: float, p: float) -> float:
        # ∫ 2π^2 k^3 dk * (k·(k+p)) / den ; angular-average proxy: k·(k+p) -> k^2
        Lam = float(Lam)
        p = float(p)
        dk = Lam / self.n_k
        s = 0.0
        for i in range(self.n_k + 1):
            k = i * dk
            w = 0.5 if (i == 0 or i == self.n_k) else 1.0
            num = (k * k)
            s += w * self._measure(k) * num / self._den(k, p)
        return s * dk

    def dimreg_proxy_subtract(self, I: float, Lam: float) -> float:
        """
        Analytic UV subtraction proxy:
        subtract leading power and log pieces fitted from asymptotics in a deterministic way.
        For our toy integrals, UV behavior ~ c2 Λ^2 + cL log(Λ) + finite.
        We model-subtract:
            c2 Λ^2 + cL log(1+Λ)
        where c2,cL are fixed functions of m chosen to cancel dominant growth.
        """
        # crude deterministic coefficients
        c2 = 0.25 / (self.m * self.m + 1.0)
        cL = 0.10 / (self.m * self.m + 1.0)
        return I - c2 * (Lam ** 2) - cL * math.log1p(Lam)

    def calibrate_R(self, Lam_ref: float, p_ref: float) -> float:
        """
        Define R(p,m) by the dimreg_proxy at a reference point:
            R = I2_dimreg / I1_dimreg
        This is the "Ward relation" target for this toy.
        """
        I1 = self.dimreg_proxy_subtract(self.I1_cutoff(Lam_ref, p_ref), Lam_ref)
        I2 = self.dimreg_proxy_subtract(self.I2_cutoff(Lam_ref, p_ref), Lam_ref)
        if I1 == 0.0:
            return 0.0
        return I2 / I1

    def build_payload(self, Lam_values: List[float], p_values: List[float]) -> Dict[str, Any]:
        require(len(Lam_values) >= 3, "Need multiple Lambda samples.")
        require(len(p_values) >= 2, "Need multiple p samples.")
        require(all(L > 0.0 for L in Lam_values), "Lambda must be > 0.")
        require(all(p >= 0.0 for p in p_values), "p must be >= 0.")

        # Calibrate Ward target ratio R using large cutoff and moderate p
        Lam_ref = max(Lam_values)
        p_ref = p_values[len(p_values) // 2]
        R = self.calibrate_R(Lam_ref, p_ref)

        sample_points: List[Dict[str, Any]] = []

        # summary trackers
        max_ward_violation_cutoff = 0.0
        max_ward_violation_dimreg = 0.0

        for p in p_values:
            for Lam in Lam_values:
                I1c = self.I1_cutoff(Lam, p)
                I2c = self.I2_cutoff(Lam, p)

                I1d = self.dimreg_proxy_subtract(I1c, Lam)
                I2d = self.dimreg_proxy_subtract(I2c, Lam)

                ward_cutoff = abs(I2c - R * I1c)
                ward_dimreg = abs(I2d - R * I1d)

                max_ward_violation_cutoff = max(max_ward_violation_cutoff, ward_cutoff)
                max_ward_violation_dimreg = max(max_ward_violation_dimreg, ward_dimreg)

                # "counterterm fix" amount needed to enforce Ward in each scheme
                delta_cutoff = (R * I1c - I2c)
                delta_dimreg = (R * I1d - I2d)

                sample_points.append({
                    "coordinates": {"Lambda": float(Lam), "p": float(p)},
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "Loop-regulator audit proxy; no spacetime curvature.",
                    },
                    "local_observables": {
                        "calibrated_R_target": finite_or_none(R),
                        "hard_cutoff": {
                            "I1": finite_or_none(I1c),
                            "I2": finite_or_none(I2c),
                            "ward_residual": finite_or_none(ward_cutoff),
                            "counterterm_fix_delta": finite_or_none(delta_cutoff),
                        },
                        "dimreg_proxy": {
                            "I1_subtracted": finite_or_none(I1d),
                            "I2_subtracted": finite_or_none(I2d),
                            "ward_residual": finite_or_none(ward_dimreg),
                            "counterterm_fix_delta": finite_or_none(delta_dimreg),
                        },
                    },
                    "causal_structure": {
                        "note": (
                            "Ward identity residual depends strongly on regulator; restoring it requires "
                            "scheme-dependent subtractions/counterterms."
                        ),
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): Ward identity violation under regulator choice",
            "spacetime": "Momentum-space loop integral proxy",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "mass_m": self.m,
                "n_k_quadrature": self.n_k,
                "Lambda_samples": Lam_values,
                "p_samples": p_values,
                "calibration": {"Lambda_ref": Lam_ref, "p_ref": p_ref},
            },
            "notes": {
                "pressure_point": (
                    "Gauge symmetry constraints (Ward identities) are regulator-sensitive. "
                    "Hard cutoffs can violate them; 'fixing' requires scheme-dependent counterterms, "
                    "reducing predictivity."
                ),
                "warning": (
                    "This is a deliberate proxy: angular averaging preserves UV behavior while making "
                    "scheme dependence visible. Do not interpret I1/I2 as literal QED values."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_ward_residual_hard_cutoff": finite_or_none(max_ward_violation_cutoff),
                    "max_ward_residual_dimreg_proxy": finite_or_none(max_ward_violation_dimreg),
                    "expectation": (
                        "Dimreg_proxy residual should be parametrically smaller/stabler than hard cutoff."
                    ),
                }
            },
        }

    def export_json(self, Lam_values: List[float], p_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(Lam_values=Lam_values, p_values=p_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 092: Ward identity regulator dependence audit (proxy).")
    ap.add_argument("--m", type=float, default=1.0, help="Mass parameter m>0")
    ap.add_argument("--n_k", type=int, default=4000, help="Quadrature steps")
    ap.add_argument("--Lambda", type=str, default="2,4,6,8,10,12", help="Comma-separated cutoff samples")
    ap.add_argument("--p", type=str, default="0,0.5,1.0,2.0", help="Comma-separated external momentum samples")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    Lam_values = [float(x.strip()) for x in args.Lambda.split(",") if x.strip()]
    p_values = [float(x.strip()) for x in args.p.split(",") if x.strip()]

    toy = Toy092WardIdentityRegulatorDependenceAudit(m=float(args.m), n_k=int(args.n_k))
    out_path = args.out.strip() or None
    json_path = toy.export_json(Lam_values=Lam_values, p_values=p_values, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
