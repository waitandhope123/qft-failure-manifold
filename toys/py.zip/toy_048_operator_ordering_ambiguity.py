#!/usr/bin/env python3
"""
Toy 048 — Ordering ambiguity (operator ordering changes physics)

Pressure point:
- In QFT, composite operators are not uniquely defined.
- Different operator orderings (normal, Weyl, time-ordered) lead to
  different numerical predictions.
- “The observable” is not invariant without an ordering prescription.

Model:
- Single harmonic oscillator.
- Compare expectation values of x^2 p^2 under different orderings
  in the same quantum state.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy048OperatorOrderingAmbiguity:
    toy_id = "048"

    def __init__(self) -> None:
        # ladder operators
        a = np.array([[0, 1], [0, 0]], dtype=complex)
        adag = a.T.conj()

        self.x = (a + adag) / math.sqrt(2.0)
        self.p = (adag - a) / (1j * math.sqrt(2.0))

        # vacuum state
        self.psi = np.array([1.0, 0.0], dtype=complex)

    def expect(self, O: np.ndarray) -> float:
        return float(np.real(np.vdot(self.psi, O @ self.psi)))

    def build_payload(self) -> Dict[str, Any]:
        # different orderings
        xp2 = self.x @ self.p @ self.p
        pxp = self.p @ self.x @ self.p
        p2x = self.p @ self.p @ self.x

        sym = (xp2 + pxp + p2x) / 3.0

        sample_points = [{
            "coordinates": {"state": "vacuum"},
            "curvature_invariants": {
                "analogy": None
            },
            "local_observables": {
                "x_p2_ordering": self.expect(xp2),
                "p_x_p_ordering": self.expect(pxp),
                "p2_x_ordering": self.expect(p2x),
                "weyl_symmetrized": self.expect(sym),
            },
            "causal_structure": {
                "note": "Operator ordering affects observables"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (operator definition ambiguity)",
            "spacetime": "Single harmonic oscillator",
            "units": {"hbar": 1},
            "parameters": {},
            "notes": {
                "pressure_point": (
                    "Composite operators require an ordering prescription. "
                    "Different orderings produce inequivalent numerical predictions."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "ordering_spread": max(
                        abs(v)
                        for v in sample_points[0]["local_observables"].values()
                    )
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy048OperatorOrderingAmbiguity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
