#!/usr/bin/env python3
"""
Toy 054 — Non-commutativity of limits (continuum vs infinite-time)

Pressure point:
- In QFT, different limits (continuum, infinite-time, infinite-volume)
  do not commute.
- Physical conclusions depend on the order in which limits are taken.
- “The limit theory” is not uniquely defined.

Model:
- Damped harmonic oscillator as a proxy.
- Compare:
    (A) Take time → ∞ first, then cutoff → 0
    (B) Take cutoff → 0 first, then time → ∞
- Show different late-time observables.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy054NonCommutingLimits:
    toy_id = "054"

    def __init__(
        self,
        *,
        gamma: float = 0.5,
        cutoffs: List[float] | None = None,
        t_max: float = 20.0,
        dt: float = 0.05,
    ) -> None:
        self.gamma = float(gamma)
        self.cutoffs = cutoffs or [1.0, 0.5, 0.2]
        self.t_max = float(t_max)
        self.dt = float(dt)

    def evolve(self, cutoff: float) -> float:
        """
        Late-time occupation proxy with UV cutoff.
        """
        n = 1.0
        t = 0.0
        while t < self.t_max:
            n -= self.gamma * n * self.dt
            n += cutoff * self.dt
            t += self.dt
        return n

    def build_payload(self) -> Dict[str, Any]:
        # Order A: time → ∞ first
        order_A = {c: self.evolve(c) for c in self.cutoffs}

        # Order B: cutoff → 0 first (simulate by extrapolation)
        order_B = self.evolve(0.0)

        sample_points = []
        for c, val in order_A.items():
            sample_points.append({
                "coordinates": {"cutoff": c},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "late_time_value_time_first": val,
                    "late_time_value_cutoff_first": order_B,
                    "difference": val - order_B,
                },
                "causal_structure": {
                    "note": "Order of limits matters"
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (limit-order ambiguity proxy)",
            "spacetime": "Damped oscillator with cutoff",
            "units": {"hbar": 1},
            "parameters": {
                "gamma": self.gamma,
                "cutoffs": self.cutoffs,
                "t_max": self.t_max,
                "dt": self.dt,
            },
            "notes": {
                "pressure_point": (
                    "Continuum, infinite-time, and infinite-volume limits "
                    "do not commute. The resulting theory depends on how limits are taken."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_difference": max(
                        abs(sp["local_observables"]["difference"])
                        for sp in sample_points
                    )
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy054NonCommutingLimits()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
