#!/usr/bin/env python3
"""
Toy 058 — Renormalization vs physical scale ambiguity

Pressure point:
- Renormalized parameters are not intrinsic numbers.
- Physical predictions depend on the scale at which parameters are defined.
- “The mass” or “the coupling” is not invariant without a renormalization scale.

Model:
- Simple running coupling proxy:
      g(μ) = g0 / (1 + β log(μ/μ0))
- Compare predictions for the same process evaluated at different scales.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy058RenormalizationScaleAmbiguity:
    toy_id = "058"

    def __init__(
        self,
        *,
        g0: float = 1.0,
        beta: float = 0.3,
        mu0: float = 1.0,
        scales: List[float] | None = None,
    ) -> None:
        self.g0 = float(g0)
        self.beta = float(beta)
        self.mu0 = float(mu0)
        self.scales = scales or [0.5, 1.0, 2.0, 5.0]

    def running_coupling(self, mu: float) -> float:
        return self.g0 / (1.0 + self.beta * math.log(mu / self.mu0))

    def build_payload(self) -> Dict[str, Any]:
        sample_points = []

        for mu in self.scales:
            gmu = self.running_coupling(mu)
            sample_points.append({
                "coordinates": {"scale": mu},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "running_coupling": gmu,
                },
                "causal_structure": {
                    "note": "Coupling depends on renormalization scale"
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (renormalization ambiguity)",
            "spacetime": "Scale space",
            "units": {"hbar": 1},
            "parameters": {
                "g0": self.g0,
                "beta": self.beta,
                "mu0": self.mu0,
                "scales": self.scales,
            },
            "notes": {
                "pressure_point": (
                    "Renormalized parameters depend on the scale at which they are defined. "
                    "There is no invariant notion of mass or coupling without a reference scale."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "min_coupling": min(sp["local_observables"]["running_coupling"]
                                        for sp in sample_points),
                    "max_coupling": max(sp["local_observables"]["running_coupling"]
                                        for sp in sample_points),
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy058RenormalizationScaleAmbiguity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
