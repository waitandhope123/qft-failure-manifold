#!/usr/bin/env python3
"""
Toy 063 — Källén–Lehmann / reflection-positivity violation (spectral negativity proxy)

What it probes (pressure point):
- In a consistent relativistic QFT, the Källén–Lehmann spectral density ρ(μ^2) is nonnegative.
  This implies Euclidean reflection positivity and guarantees Hilbert-space positivity.
- Many "effective" or modified propagators (higher-derivative, wrong-sign residues, ad hoc UV fixes)
  violate spectral positivity: they cannot correspond to a unitary, positive-norm QFT.

Model (controlled proxy):
- Consider a Euclidean two-point function as a superposition of free massive propagators:
    G_E(p^2) = ∫ dμ^2  ρ(μ^2) / (p^2 + μ^2)
- If ρ includes negative weights, the "time-sliced" Schwinger function can become negative:
    C(t) = ∫_0^∞ dω  ρ_eff(ω) e^{-ω t}
  In a reflection-positive theory, C(t) >= 0 for all t.

Discrete approximation:
- Choose a set of masses m_i and weights w_i approximating ρ:
    C(t) ≈ Σ_i w_i e^{-m_i t}
- If any w_i < 0, C(t) can dip below zero at some t (positivity violation).

Diagnostics:
- For each parameter set, compute:
  * min_t C(t) over a grid
  * fraction of t where C(t) < 0
  * whether any negative spectral weights were used

Export:
- Strict lab JSON schema.
- Writes <script_name>.json by default.

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


def parse_pairs(masses_csv: str, weights_csv: str) -> Tuple[List[float], List[float]]:
    ms = parse_csv_floats(masses_csv)
    ws = parse_csv_floats(weights_csv)
    require(len(ms) == len(ws), "masses and weights must have same length.")
    require(len(ms) >= 1, "Need at least one spectral component.")
    require(all(m > 0.0 for m in ms), "All masses must be > 0.")
    return ms, ws


# ----------------------------
# Toy 063
# ----------------------------

class Toy063KallenLehmannReflectionPositivityViolation:
    toy_id = "063"

    def __init__(self, masses: List[float], weights: List[float]) -> None:
        require(len(masses) == len(weights) and len(masses) >= 1, "Need matching masses/weights.")
        require(all(m > 0.0 for m in masses), "All masses must be > 0.")
        self.masses = [float(m) for m in masses]
        self.weights = [float(w) for w in weights]

    def C_of_t(self, t: float) -> float:
        return sum(w * math.exp(-m * t) for m, w in zip(self.masses, self.weights))

    def analyze(self, t_grid: List[float]) -> Dict[str, Any]:
        vals = [self.C_of_t(t) for t in t_grid]
        minC = min(vals)
        maxC = max(vals)
        neg_count = sum(1 for v in vals if v < 0.0)
        frac_neg = neg_count / len(vals) if len(vals) else None

        any_neg_weight = any(w < 0.0 for w in self.weights)

        # Simple "first crossing" estimate: smallest t where C(t)<0
        first_neg_t = None
        for t, v in zip(t_grid, vals):
            if v < 0.0:
                first_neg_t = t
                break

        return {
            "min_C_t": finite_or_none(minC),
            "max_C_t": finite_or_none(maxC),
            "fraction_negative_over_grid": finite_or_none(frac_neg),
            "first_t_with_C_negative": finite_or_none(first_neg_t),
            "any_negative_spectral_weight": any_neg_weight,
        }

    def build_payload(self, t_min: float, t_max: float, n_t: int) -> Dict[str, Any]:
        require(t_min >= 0.0 and t_max > t_min, "Require 0<=t_min<t_max.")
        require(n_t >= 3, "n_t must be >= 3.")
        t_grid = [t_min + (t_max - t_min) * i / (n_t - 1) for i in range(n_t)]

        analysis = self.analyze(t_grid)

        # sample_points: one per t (so it's comparable with other toys as a curve)
        sample_points: List[Dict[str, Any]] = []
        for t in t_grid:
            Ct = self.C_of_t(t)
            sample_points.append({
                "coordinates": {"t_euclidean": float(t)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "schwinger_function_C_t": finite_or_none(Ct),
                    "reflection_positivity_expected": True,
                    "reflection_positivity_satisfied_at_t": (Ct >= 0.0),
                },
                "causal_structure": {
                    "note": "Reflection positivity ↔ Hilbert-space positivity/unitarity; not a spacetime causal test.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (axiomatic proxy): Källén–Lehmann positivity / reflection positivity",
            "spacetime": "Euclidean QFT (Schwinger function)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "spectral_masses": self.masses,
                "spectral_weights": self.weights,
                "t_grid": {"t_min": t_min, "t_max": t_max, "n_t": n_t},
            },
            "notes": {
                "pressure_point": (
                    "A consistent QFT requires nonnegative spectral density. "
                    "Negative spectral weights imply reflection-positivity violation and cannot arise from a "
                    "unitary, positive-norm Hilbert space. This toy detects that via C(t) negativity."
                ),
                "key_formulas": {
                    "C(t)": "C(t)=Σ_i w_i e^{-m_i t} (discrete spectral approximation)",
                    "positivity": "Reflection positivity ⇒ C(t) ≥ 0 for all t",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": analysis,
            },
        }

    def export_json(self, t_min: float, t_max: float, n_t: int, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_min=t_min, t_max=t_max, n_t=n_t)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 063: reflection-positivity violation from negative spectral weights.")
    ap.add_argument("--masses", type=str, default="1.0,3.0,6.0", help="Comma-separated masses m_i > 0")
    ap.add_argument("--weights", type=str, default="1.0,-0.6,0.2", help="Comma-separated weights w_i (can be negative)")
    ap.add_argument("--t_min", type=float, default=0.0, help="Minimum Euclidean time")
    ap.add_argument("--t_max", type=float, default=5.0, help="Maximum Euclidean time")
    ap.add_argument("--n_t", type=int, default=301, help="Number of t samples")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    masses, weights = parse_pairs(args.masses, args.weights)
    toy = Toy063KallenLehmannReflectionPositivityViolation(masses=masses, weights=weights)

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_min=float(args.t_min), t_max=float(args.t_max), n_t=int(args.n_t), out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
