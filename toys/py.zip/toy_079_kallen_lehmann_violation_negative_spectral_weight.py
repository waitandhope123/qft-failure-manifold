#!/usr/bin/env python3
"""
Toy 079 — Källén–Lehmann / spectral positivity violation (non-unitary/approximation diagnostic)

What it probes (pressure point):
- In a unitary, causal QFT, 2-point functions admit a Källén–Lehmann representation with
  nonnegative spectral density ρ(μ^2) >= 0.
- Many approximations (bad truncations, gauge-fixing artifacts, non-unitary effective dynamics)
  can yield correlators whose inferred spectral density becomes negative — a sharp diagnostic
  that the object cannot be a physical Wightman function of any unitary QFT.

Model (controlled, deterministic):
- Consider Euclidean correlator sampled at times t_i:
    G_E(t) = ∫_0^∞ dω  ρ(ω) e^{-ω t}
- Start with a positive ρ_true, generate G_true.
- Then build an "approximate" correlator by adding a small oscillatory distortion to G_E(t)
  that is consistent-looking in Euclidean time but incompatible with positive ρ.
- Invert (unconstrained) to obtain ρ_hat; check negativity fraction.

Diagnostics:
- Reconstruct ρ_hat via Tikhonov regularization (same machinery as Toy 071).
- Report:
  * min(ρ_hat)
  * total negative spectral weight fraction
  * fit residual (shows Euclidean fit can still be good)

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def gaussian(omega: np.ndarray, mu: float, sig: float) -> np.ndarray:
    return np.exp(-0.5 * ((omega - mu) / sig) ** 2) / (sig * math.sqrt(2.0 * math.pi))


# ----------------------------
# Toy 079
# ----------------------------

class Toy079KallenLehmannViolationNegativeSpectralWeight:
    toy_id = "079"

    def __init__(
        self,
        *,
        omega_max: float = 20.0,
        n_omega: int = 400,
        t_min: float = 0.05,
        t_max: float = 2.0,
        n_t: int = 40,
    ) -> None:
        require(omega_max > 0.0, "omega_max must be > 0.")
        require(n_omega >= 80, "n_omega must be >= 80.")
        require(t_min > 0.0 and t_max > t_min, "Require 0 < t_min < t_max.")
        require(n_t >= 15, "n_t must be >= 15.")
        self.omega_max = float(omega_max)
        self.n_omega = int(n_omega)
        self.t_min = float(t_min)
        self.t_max = float(t_max)
        self.n_t = int(n_t)

        self.omega = np.linspace(0.0, self.omega_max, self.n_omega)
        self.domega = self.omega[1] - self.omega[0]
        self.t = np.linspace(self.t_min, self.t_max, self.n_t)

    def rho_true(self) -> np.ndarray:
        rho = (
            0.85 * gaussian(self.omega, mu=3.0, sig=0.45) +
            0.15 * gaussian(self.omega, mu=9.0, sig=0.90)
        )
        return np.maximum(rho, 0.0)

    def kernel(self) -> np.ndarray:
        return np.exp(-np.outer(self.t, self.omega)) * self.domega

    def tikhonov(self, K: np.ndarray, G: np.ndarray, lam: float) -> np.ndarray:
        KT = K.T
        A = KT @ K
        b = KT @ G
        return np.linalg.solve(A + lam * np.eye(A.shape[0]), b)

    def build_payload(self, lam: float, distortion_amp: float, distortion_freq: float) -> Dict[str, Any]:
        require(lam >= 0.0, "lam must be >= 0.")
        require(distortion_amp >= 0.0, "distortion_amp must be >= 0.")
        require(distortion_freq > 0.0, "distortion_freq must be > 0.")

        rho = self.rho_true()
        K = self.kernel()
        G_true = K @ rho

        # Build distorted Euclidean correlator (approximation artifact)
        # G_dist = G_true * (1 + a sin(ω_d t))
        G_dist = G_true * (1.0 + distortion_amp * np.sin(distortion_freq * self.t))

        # Invert for rho_hat
        rho_hat = self.tikhonov(K, G_dist, lam=lam)
        G_hat = K @ rho_hat

        # Negativity diagnostics
        neg = np.minimum(rho_hat, 0.0)
        pos = np.maximum(rho_hat, 0.0)
        neg_weight = float(np.sum(np.abs(neg)) * self.domega)
        pos_weight = float(np.sum(pos) * self.domega)
        frac_neg = None if (pos_weight + neg_weight) == 0.0 else (neg_weight / (pos_weight + neg_weight))

        # Fit residuals
        resid_true = float(np.linalg.norm(G_hat - G_true))
        resid_dist = float(np.linalg.norm(G_hat - G_dist))

        # Downsample spectra for JSON
        stride = max(1, self.n_omega // 150)
        omega_ds = self.omega[::stride]
        rho_ds = rho[::stride]
        rho_hat_ds = rho_hat[::stride]

        sample_points: List[Dict[str, Any]] = []
        for i, ti in enumerate(self.t.tolist()):
            sample_points.append({
                "coordinates": {"t_euclidean": float(ti)},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "QFT toy; no curvature."},
                "local_observables": {
                    "G_true": finite_or_none(float(G_true[i])),
                    "G_distorted": finite_or_none(float(G_dist[i])),
                    "G_reconstructed": finite_or_none(float(G_hat[i])),
                    "abs_fit_error_to_distorted": finite_or_none(float(abs(G_hat[i] - G_dist[i]))),
                },
                "causal_structure": {"note": "Spectral positivity is a unitarity diagnostic; violations signal non-physical correlator."},
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): Källén–Lehmann positivity violation diagnostic",
            "spacetime": "Euclidean correlator sampling (spectral representation)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "omega_grid": {"omega_max": self.omega_max, "n_omega": self.n_omega},
                "t_grid": {"t_min": self.t_min, "t_max": self.t_max, "n_t": self.n_t},
                "tikhonov_lambda": lam,
                "distortion": {"amp": distortion_amp, "freq": distortion_freq},
            },
            "notes": {
                "pressure_point": (
                    "Unitary QFT requires nonnegative spectral density. "
                    "Approximate Euclidean correlators can look reasonable but imply negative spectral weight when inverted, "
                    "signaling the object is not a physical Wightman function of any unitary theory."
                ),
                "formula": "G_E(t)=∫ dω ρ(ω) e^{-ω t}, with ρ(ω) >= 0 in unitary QFT",
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "min_rho_hat": finite_or_none(float(np.min(rho_hat))),
                    "negative_spectral_weight": finite_or_none(neg_weight),
                    "positive_spectral_weight": finite_or_none(pos_weight),
                    "negative_fraction": finite_or_none(frac_neg) if frac_neg is not None else None,
                    "residual_L2_to_true": finite_or_none(resid_true),
                    "residual_L2_to_distorted": finite_or_none(resid_dist),
                },
                "spectral_snapshots_downsampled": {
                    "omega": omega_ds.tolist(),
                    "rho_true": rho_ds.tolist(),
                    "rho_hat": rho_hat_ds.tolist(),
                },
            },
        }

    def export_json(self, lam: float, distortion_amp: float, distortion_freq: float,
                    out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(lam=lam, distortion_amp=distortion_amp, distortion_freq=distortion_freq)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 079: spectral positivity violation diagnostic (Källén–Lehmann proxy).")
    ap.add_argument("--lam", type=float, default=1e-4, help="Tikhonov lambda")
    ap.add_argument("--amp", type=float, default=0.15, help="Distortion amplitude")
    ap.add_argument("--freq", type=float, default=7.0, help="Distortion frequency in Euclidean time")
    ap.add_argument("--omega_max", type=float, default=20.0, help="Max omega")
    ap.add_argument("--n_omega", type=int, default=400, help="Omega points")
    ap.add_argument("--t_min", type=float, default=0.05, help="Min t")
    ap.add_argument("--t_max", type=float, default=2.0, help="Max t")
    ap.add_argument("--n_t", type=int, default=40, help="t points")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy079KallenLehmannViolationNegativeSpectralWeight(
        omega_max=float(args.omega_max),
        n_omega=int(args.n_omega),
        t_min=float(args.t_min),
        t_max=float(args.t_max),
        n_t=int(args.n_t),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(
        lam=float(args.lam),
        distortion_amp=float(args.amp),
        distortion_freq=float(args.freq),
        out_path=out_path,
    )
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
