#!/usr/bin/env python3
"""
Toy 059 — Time-ordering vs causal ordering ambiguity

Pressure point:
- In relativistic QFT, time ordering is frame-dependent.
- For non-commuting observables, different time orderings give different
  correlation functions.
- “The correlator” is not invariant without a causal prescription.

Model:
- Two non-commuting operators A, B on a two-level system.
- Compute time-ordered correlators in two opposite orders.
- Show explicit disagreement.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import os
import numpy as np
from typing import Any, Dict


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy059TimeOrderingAmbiguity:
    toy_id = "059"

    def __init__(self) -> None:
        # Pauli matrices
        self.sx = np.array([[0, 1], [1, 0]], dtype=complex)
        self.sz = np.array([[1, 0], [0, -1]], dtype=complex)

        # State |+>
        self.psi = np.array([1.0, 1.0], dtype=complex)
        self.psi /= np.linalg.norm(self.psi)

    def expect(self, O: np.ndarray) -> float:
        return float(np.real(np.vdot(self.psi, O @ self.psi)))

    def build_payload(self) -> Dict[str, Any]:
        AB = self.expect(self.sx @ self.sz)
        BA = self.expect(self.sz @ self.sx)

        sample_points = [{
            "coordinates": {"ordering": "comparison"},
            "curvature_invariants": {
                "analogy": None
            },
            "local_observables": {
                "time_order_A_then_B": AB,
                "time_order_B_then_A": BA,
                "difference": AB - BA,
            },
            "causal_structure": {
                "note": "Time ordering of non-commuting operators is not invariant"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (time-ordering ambiguity)",
            "spacetime": "Two-level system",
            "units": {"hbar": 1},
            "parameters": {},
            "notes": {
                "pressure_point": (
                    "Correlation functions of non-commuting observables depend on "
                    "time ordering. In relativistic settings, time ordering is frame-dependent."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "ordering_gap": sample_points[0]["local_observables"]["difference"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy059TimeOrderingAmbiguity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
