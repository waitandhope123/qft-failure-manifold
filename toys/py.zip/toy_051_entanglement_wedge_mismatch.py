#!/usr/bin/env python3
"""
Toy 051 — Entanglement wedge mismatch (local access vs global reconstruction)

Pressure point:
- In QFT, local measurements do not determine the global state.
- Different global states can agree on all local observables in a region.
- “Knowing everything locally” does not fix the global quantum state.

Model:
- Three-qubit system (A, B, C).
- Construct two different global pure states:
    (1) GHZ-like state
    (2) Product-entangled hybrid
- Show they are indistinguishable on subsystem AB but differ globally.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import os
import numpy as np
from typing import Any, Dict


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy051EntanglementWedgeMismatch:
    toy_id = "051"

    def __init__(self) -> None:
        pass

    def partial_trace(self, rho: np.ndarray, keep: list[int]) -> np.ndarray:
        """
        Partial trace over qubits not in 'keep'.
        """
        rho = rho.reshape([2, 2, 2, 2, 2, 2])
        axes = [i for i in range(3) if i not in keep]
        for ax in sorted(axes, reverse=True):
            rho = np.trace(rho, axis1=ax, axis2=ax + 3)
        return rho

    def build_payload(self) -> Dict[str, Any]:
        # Basis ordering: |abc>
        zero = np.array([1, 0], dtype=complex)
        one = np.array([0, 1], dtype=complex)

        # GHZ state
        ghz = (np.kron(np.kron(zero, zero), zero) +
               np.kron(np.kron(one, one), one)) / np.sqrt(2)

        # Alternative state: Bell pair on AB, product with C
        bell_ab = (np.kron(zero, zero) + np.kron(one, one)) / np.sqrt(2)
        psi_alt = np.kron(bell_ab, zero)

        rho_ghz = np.outer(ghz, ghz.conj())
        rho_alt = np.outer(psi_alt, psi_alt.conj())

        # Reduced density matrices on AB
        rho_ghz_ab = self.partial_trace(rho_ghz, keep=[0, 1])
        rho_alt_ab = self.partial_trace(rho_alt, keep=[0, 1])

        diff_norm = float(np.linalg.norm(rho_ghz_ab - rho_alt_ab))

        sample_points = [{
            "coordinates": {"subsystem": "AB"},
            "curvature_invariants": {
                "analogy": None
            },
            "local_observables": {
                "reduced_state_difference_norm": diff_norm,
            },
            "causal_structure": {
                "note": "Identical local data, distinct global states"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (state reconstruction failure proxy)",
            "spacetime": "Three-qubit system",
            "units": {"hbar": 1},
            "parameters": {},
            "notes": {
                "pressure_point": (
                    "Local reduced density matrices do not determine the global state. "
                    "Global information is inaccessible to local observers."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "local_indistinguishability_norm": diff_norm
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy051EntanglementWedgeMismatch()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
