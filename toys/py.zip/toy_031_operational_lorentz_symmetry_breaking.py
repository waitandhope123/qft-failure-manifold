#!/usr/bin/env python3
"""
Toy 031 — Finite detector resolution vs Lorentz invariance (operational symmetry breaking)

Pressure point:
- QFT is Lorentz invariant, but real detectors are not.
- Finite spatial/temporal resolution breaks exact Lorentz symmetry operationally.
- What an observer measures depends on detector frame and resolution.

GR parallel:
- Coordinate invariance vs physical observers
- Local frames break global symmetries operationally

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free scalar field in 1+1D
- Gaussian-smeared detector in different inertial frames
- Compare response under boosts for fixed detector resolution

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy031OperationalLorentzBreaking:
    toy_id = "031"

    def __init__(
        self,
        *,
        smearing_scale: float = 1.0,
        boost_rapidities: List[float] = [0.0, 0.5, 1.0, 1.5],
        gap: float = 1.0,
    ) -> None:
        self.sigma = float(smearing_scale)
        self.etas = [float(e) for e in boost_rapidities]
        self.Omega = float(gap)

    def detector_response_proxy(self, eta: float) -> float:
        """
        Proxy for detector response under boost η.
        Finite smearing introduces frame dependence.
        """
        gamma = math.cosh(eta)
        return math.exp(-self.Omega * self.sigma * gamma)

    def lorentz_invariant_limit(self) -> float:
        """
        Idealized pointlike detector (σ → 0) would be invariant.
        """
        return 1.0

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        inv = self.lorentz_invariant_limit()

        for eta in self.etas:
            resp = self.detector_response_proxy(eta)

            sample_points.append({
                "coordinates": {
                    "boost_rapidity_eta": eta,
                },
                "curvature_invariants": {
                    "ideal_lorentz_invariant_response": inv,
                },
                "local_observables": {
                    "detector_response_proxy": resp,
                },
                "causal_structure": {
                    "operational_lorentz_invariance": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "smearing_scale": self.sigma,
                "boost_rapidities": self.etas,
                "gap": self.Omega,
            },
            "notes": {
                "assumptions": [
                    "Finite-resolution detector",
                    "Gaussian smearing",
                    "Boosted inertial observers",
                ],
                "pressure_point": (
                    "Exact Lorentz invariance is broken at the operational level "
                    "by finite detector resolution, even though the theory is invariant."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "operational_lorentz_invariance": False,
                    "detector_independence": False,
                },
                "regime_classification": {
                    "sigma_to_zero": "lorentz_invariant_limit",
                    "finite_sigma": "frame_dependent_measurement",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy031OperationalLorentzBreaking().export_json()


if __name__ == "__main__":
    main()
