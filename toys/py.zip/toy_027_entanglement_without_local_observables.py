#!/usr/bin/env python3
"""
Toy 027 — Entanglement wedge vs local access (information without observables)

Pressure point:
- Quantum information can exist without any local operator access.
- Entanglement structure carries information not recoverable from local measurements.
- Knowledge ≠ observability.

GR parallel:
- Bulk geometry not reconstructible from local curvature alone
- Horizon hides information without destroying it

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Bipartite quantum field mode system (proxy)
- Track entanglement entropy vs accessible local observables
- Independent diagnostic: mutual information saturation

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy027EntanglementWithoutObservables:
    toy_id = "027"

    def __init__(
        self,
        *,
        entanglement_strengths: List[float] = [0.2, 0.5, 1.0, 2.0],
    ) -> None:
        self.rs = [float(r) for r in entanglement_strengths]

    def entanglement_entropy(self, r: float) -> float:
        """
        S ~ cosh^2(r) log cosh^2(r) - sinh^2(r) log sinh^2(r)
        (standard two-mode squeezing entropy)
        """
        n = math.sinh(r) ** 2
        if n == 0:
            return 0.0
        return (n + 1) * math.log(n + 1) - n * math.log(n)

    def local_observable_access(self, r: float) -> bool:
        """
        Independent diagnostic:
        Local operators cannot distinguish global entanglement structure.
        """
        return False

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for r in self.rs:
            S = self.entanglement_entropy(r)
            local_access = self.local_observable_access(r)

            sample_points.append({
                "coordinates": {
                    "squeezing_parameter_r": r,
                },
                "curvature_invariants": {
                    "global_state_purity": True,
                },
                "local_observables": {
                    "entanglement_entropy": S,
                    "local_operator_access": local_access,
                },
                "causal_structure": {
                    "information_locally_observable": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Abstract bipartite mode space",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "entanglement_strengths": self.rs,
            },
            "notes": {
                "assumptions": [
                    "Two-mode squeezed state",
                    "Perfect global purity",
                    "Local operators restricted to one subsystem",
                ],
                "pressure_point": (
                    "Quantum information can exist without local observability. "
                    "Entanglement encodes structure inaccessible to local probes."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "local_completeness": False,
                    "information_equals_observables": False,
                },
                "regime_classification": {
                    "weak_entanglement": "low_hidden_information",
                    "strong_entanglement": "large_hidden_information",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy027EntanglementWithoutObservables().export_json()


if __name__ == "__main__":
    main()
