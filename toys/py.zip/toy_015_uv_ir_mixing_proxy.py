#!/usr/bin/env python3
"""
Toy 015 — UV/IR mixing proxy: sensitivity of long-distance observables to UV cutoff

Pressure point:
- In QFT, short-distance (UV) structure can affect long-distance (IR) observables.
- Decoupling intuition can fail: IR physics is not always independent of UV completion.
- Even in free theories, regulated correlators retain UV imprint.

Model:
- Free real scalar field in 1+1D
- Equal-time two-point correlator at fixed large separation x
- Vary UV momentum cutoff Λ and track IR correlator value

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


# ----------------------------
# Toy 015
# ----------------------------

class Toy015UVIRMixing:
    toy_id = "015"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        separation_x: float = 5.0,
        cutoffs: List[float] = [5.0, 10.0, 20.0, 40.0],
        dk: float = 0.02,
    ) -> None:
        self.m = float(mass)
        self.x = float(separation_x)
        self.cutoffs = [float(L) for L in cutoffs]
        self.dk = float(dk)

    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def correlator(self, Lambda: float) -> float:
        """
        G(x) = ∫_{-Λ}^{Λ} dk / (4π ω_k) cos(k x)
        """
        s = 0.0
        k = -Lambda
        while k <= Lambda:
            w = self.omega(k)
            s += math.cos(k * self.x) / (4.0 * math.pi * w)
            k += self.dk
        return s * self.dk

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for Lambda in self.cutoffs:
            G = self.correlator(Lambda)

            sample_points.append({
                "coordinates": {
                    "separation_x": self.x,
                    "cutoff_Lambda": Lambda,
                },
                "curvature_invariants": {
                    "uv_scale_Lambda": Lambda,
                },
                "local_observables": {
                    "equal_time_correlator_G": G,
                },
                "causal_structure": {
                    "ir_observable_uv_sensitive": True,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "separation_x": self.x,
                "cutoffs": self.cutoffs,
                "dk": self.dk,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Hard momentum cutoff regulator",
                    "Equal-time correlator used as IR observable",
                ],
                "pressure_point": (
                    "Long-distance observables retain sensitivity to UV cutoff. "
                    "Decoupling between UV and IR is not automatic."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "trend": "Correlator value shifts with increasing UV cutoff even at fixed large x."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    Toy015UVIRMixing().export_json()


if __name__ == "__main__":
    main()
