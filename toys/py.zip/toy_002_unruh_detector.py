#!/usr/bin/env python3
"""
Toy 002 — Unruh detector response in flat spacetime (thermality without curvature)

Pressure point:
- The same QFT vacuum produces different particle content for different observers.
- Thermality appears without curvature or gravity.
- Particle concept is observer-dependent.

Model:
- Free real scalar field in 1+1D Minkowski spacetime
- Unruh–DeWitt detector with energy gap Ω
- Compare inertial vs uniformly accelerated trajectories
- Finite switching time and UV cutoff

Units: ħ = c = k_B = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 002
# ----------------------------

class Toy002UnruhDetector:
    toy_id = "002"

    def __init__(
        self,
        *,
        gap: float = 1.0,
        acceleration: float = 1.0,
        cutoff: float = 15,
        dk: float = 0.08,
        tau_max: float = 6,
        dtau: float = 0.05,
    ) -> None:
        require(gap > 0.0, "gap must be > 0")
        require(acceleration >= 0.0, "acceleration must be >= 0")

        self.Omega = float(gap)
        self.a = float(acceleration)
        self.Lambda = float(cutoff)
        self.dk = float(dk)
        self.tau_max = float(tau_max)
        self.dtau = float(dtau)

    def omega_k(self, k: float) -> float:
        return abs(k)

    # Minkowski vacuum Wightman function along trajectory
    def wightman_on_worldline(self, tau: float, tau_p: float) -> float:
        if self.a == 0.0:
            t = tau
            x = 0.0
            tp = tau_p
            xp = 0.0
        else:
            t = math.sinh(self.a * tau) / self.a
            x = math.cosh(self.a * tau) / self.a
            tp = math.sinh(self.a * tau_p) / self.a
            xp = math.cosh(self.a * tau_p) / self.a

        dt = t - tp
        dx = x - xp

        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega_k(k)
            s += math.cos(w * dt - k * dx) / (4.0 * math.pi * w if w > 0 else 1.0)
            k += self.dk
        return s * self.dk

    # Detector response function
    def response(self) -> float:
        R = 0.0
        tau = -self.tau_max
        while tau <= self.tau_max:
            tau_p = -self.tau_max
            while tau_p <= self.tau_max:
                G = self.wightman_on_worldline(tau, tau_p)
                phase = math.cos(self.Omega * (tau - tau_p))
                R += phase * G
                tau_p += self.dtau
            tau += self.dtau
        return R * (self.dtau ** 2)

    def build_payload(self) -> Dict[str, Any]:
        response_value = self.response()

        sample_points = [{
            "coordinates": {
                "tau": None,
                "trajectory": "accelerated" if self.a > 0 else "inertial",
            },
            "curvature_invariants": {
                "acceleration_a": self.a,
                "cutoff_Lambda": self.Lambda,
            },
            "local_observables": {
                "detector_gap_Omega": self.Omega,
                "response_function": response_value,
            },
            "causal_structure": {
                "has_horizon": self.a > 0.0,
                "unruh_temperature": (self.a / (2.0 * math.pi)) if self.a > 0 else 0.0,
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1, "kB": 1},
            "parameters": {
                "gap_Omega": self.Omega,
                "acceleration_a": self.a,
                "cutoff_Lambda": self.Lambda,
                "tau_max": self.tau_max,
                "dtau": self.dtau,
            },
            "notes": {
                "assumptions": [
                    "Free massless scalar field",
                    "Unruh–DeWitt point detector",
                    "Finite interaction time",
                    "Momentum cutoff regulator",
                ],
                "pressure_point": (
                    "Thermal response arises for accelerated observers in flat spacetime. "
                    "Particle content is observer-dependent despite identical vacuum state."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "expected_behavior": (
                    "Inertial detector response → vacuum noise only; "
                    "accelerated detector response → thermal spectrum at T = a / (2π)."
                )
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy002UnruhDetector(
        gap=1.0,
        acceleration=1.0,
    )
    toy.export_json()


if __name__ == "__main__":
    main()
