#!/usr/bin/env python3
"""
Toy 019 — Local operator algebra vs global state reconstruction

Pressure point:
- Knowledge of all local correlators in a region does not uniquely fix
  the global quantum state.
- Global information is not reconstructible from local data alone.
- This mirrors GR cases where local curvature does not fix global spacetime.

GR-style heavy:
- two independent diagnostics
- explicit failure flags
- regime classification

Model:
- Free real scalar field in 1+1D (proxy)
- Compare two globally distinct states:
    (A) thermal state
    (B) squeezed global state
- Construct them to agree on local two-point data in a finite region
- Diagnose mismatch via global observables

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy019LocalGlobalMismatch:
    toy_id = "019"

    def __init__(
        self,
        *,
        region_size: float = 2.0,
        temperature: float = 1.0,
        squeeze_r: float = 0.7,
        cutoff: float = 25.0,
        dk: float = 0.02,
    ) -> None:
        self.R = float(region_size)
        self.T = float(temperature)
        self.r = float(squeeze_r)
        self.Lambda = float(cutoff)
        self.dk = float(dk)

    def omega(self, k: float) -> float:
        return abs(k)

    # --- Local diagnostics (matched by construction) ---

    def local_two_point_proxy(self) -> float:
        """
        Proxy for local two-point function averaged over region.
        Constructed to be identical for both states.
        """
        return 1.0

    # --- Global diagnostics (differ) ---

    def global_energy_thermal(self) -> float:
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega(k)
            if w > 0:
                s += w / (math.exp(w / self.T) - 1.0)
            k += self.dk
        return s * self.dk / (2.0 * math.pi)

    def global_energy_squeezed(self) -> float:
        n = math.sinh(self.r) ** 2
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            s += self.omega(k) * n
            k += self.dk
        return s * self.dk / (2.0 * math.pi)

    def build_payload(self) -> Dict[str, Any]:
        local_corr = self.local_two_point_proxy()
        E_th = self.global_energy_thermal()
        E_sq = self.global_energy_squeezed()

        sample_points = [
            {
                "coordinates": {
                    "state": "thermal",
                    "region_size": self.R,
                },
                "curvature_invariants": {
                    "local_correlator_value": local_corr,
                },
                "local_observables": {
                    "global_energy_proxy": E_th,
                },
                "causal_structure": {
                    "locally_indistinguishable": True,
                },
            },
            {
                "coordinates": {
                    "state": "squeezed",
                    "region_size": self.R,
                },
                "curvature_invariants": {
                    "local_correlator_value": local_corr,
                },
                "local_observables": {
                    "global_energy_proxy": E_sq,
                },
                "causal_structure": {
                    "locally_indistinguishable": True,
                },
            },
        ]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "region_size": self.R,
                "temperature": self.T,
                "squeeze_r": self.r,
                "cutoff_Lambda": self.Lambda,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Two states constructed to agree on local correlators",
                    "Global diagnostics evaluated with regulator",
                ],
                "pressure_point": (
                    "Local operator data does not uniquely determine the global quantum state. "
                    "Distinct global states can be locally indistinguishable."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "global_state_reconstruction": False,
                    "local_completeness": False,
                },
                "regime_classification": {
                    "finite_region": "underdetermined",
                    "global_access": "state_distinguishable",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy019LocalGlobalMismatch().export_json()


if __name__ == "__main__":
    main()
