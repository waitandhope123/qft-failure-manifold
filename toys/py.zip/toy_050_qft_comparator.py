#!/usr/bin/env python3
"""
Toy 050 — Cross-toy comparator (QFT lab meta-instrument)

Pressure point:
- Claims about QFT structure are meaningless without explicit comparison.
- Different toys probing “the same concept” may disagree numerically or structurally.
- Comparison itself must be treated as an operational observable.

Model:
- Load multiple QFT toy JSON outputs.
- Check schema consistency.
- Extract shared diagnostics when present.
- Report mismatches, absences, and divergences.

This is a META-toy, mirroring GR Toy 050.
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Tuple


REQUIRED_TOP_LEVEL_KEYS = [
    "toy_id",
    "theory",
    "spacetime",
    "units",
    "parameters",
    "notes",
    "sample_points",
    "observables",
]


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def check_schema(payload: Dict[str, Any]) -> List[str]:
    return [k for k in REQUIRED_TOP_LEVEL_KEYS if k not in payload]


def coord_signature(coords: Dict[str, Any]) -> Tuple[Tuple[str, Any], ...]:
    return tuple(sorted(coords.items(), key=lambda kv: kv[0]))


class Toy050QFTComparator:
    toy_id = "050"

    def __init__(self, json_paths: List[str]) -> None:
        if len(json_paths) < 2:
            raise ValueError("Need at least two toy JSON files to compare.")
        self.json_paths = json_paths

    def build_payload(self) -> Dict[str, Any]:
        payloads = [(p, load_json(p)) for p in self.json_paths]

        schema_issues = {
            os.path.basename(p): check_schema(d)
            for p, d in payloads
        }

        # build index of sample points by coordinate signature
        indices: Dict[str, Dict[Tuple[Tuple[str, Any], ...], Dict[str, Any]]] = {}

        for p, d in payloads:
            idx: Dict[Tuple[Tuple[str, Any], ...], Dict[str, Any]] = {}
            for sp in d.get("sample_points", []):
                sig = coord_signature(sp.get("coordinates", {}))
                idx[sig] = sp
            indices[os.path.basename(p)] = idx

        # union of all coordinate signatures
        all_sigs = set()
        for idx in indices.values():
            all_sigs |= set(idx.keys())

        sample_points: List[Dict[str, Any]] = []

        for sig in sorted(all_sigs):
            present = {}
            for name, idx in indices.items():
                present[name] = sig in idx

            sample_points.append({
                "coordinates": dict(sig),
                "curvature_invariants": {},
                "local_observables": {
                    "present_in_files": present
                },
                "causal_structure": {},
            })

        return {
            "toy_id": self.toy_id,
            "theory": "QFT Lab Meta-Comparator",
            "spacetime": "Cross-toy comparison space",
            "units": {},
            "parameters": {
                "input_files": [os.path.basename(p) for p in self.json_paths]
            },
            "notes": {
                "pressure_point": (
                    "QFT claims require explicit cross-toy comparison. "
                    "Absence, mismatch, or non-overlap is meaningful data."
                ),
                "schema_requirements": REQUIRED_TOP_LEVEL_KEYS,
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "schema_issues": schema_issues,
                    "total_coordinate_signatures": len(all_sigs),
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    import argparse

    ap = argparse.ArgumentParser(description="Toy 050: QFT cross-toy comparator")
    ap.add_argument("json_files", nargs="+", help="Toy JSON files to compare")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy050QFTComparator(args.json_files)
    out = args.out.strip() or None
    path = toy.export_json(out_path=out)
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
