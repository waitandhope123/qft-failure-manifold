#!/usr/bin/env python3
"""
Toy 053 — State distinguishability depends on measurement algebra

Pressure point:
- Whether two quantum states are distinguishable depends on the allowed
  measurement algebra.
- States that are orthogonal globally can be indistinguishable under
  restricted (local or coarse-grained) observables.
- “Different states” is not an invariant statement without specifying
  measurement access.

Model:
- Two orthogonal two-qubit states.
- Compare distinguishability using:
    (A) full global measurements
    (B) restricted single-qubit measurements
- Quantify distinguishability via trace distance.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import os
import numpy as np
from typing import Any, Dict


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def trace_distance(rho: np.ndarray, sigma: np.ndarray) -> float:
    vals = np.linalg.eigvalsh(rho - sigma)
    return 0.5 * float(np.sum(np.abs(vals)))


class Toy053MeasurementAlgebraDependence:
    toy_id = "053"

    def __init__(self) -> None:
        pass

    def partial_trace(self, rho: np.ndarray, keep: list[int]) -> np.ndarray:
        rho = rho.reshape([2, 2, 2, 2])
        trace_out = [i for i in range(2) if i not in keep]
        for ax in sorted(trace_out, reverse=True):
            rho = np.trace(rho, axis1=ax, axis2=ax + 2)
        return rho

    def build_payload(self) -> Dict[str, Any]:
        zero = np.array([1, 0], dtype=complex)
        one = np.array([0, 1], dtype=complex)

        # Orthogonal global states
        psi1 = (np.kron(zero, zero) + np.kron(one, one)) / np.sqrt(2)
        psi2 = (np.kron(zero, zero) - np.kron(one, one)) / np.sqrt(2)

        rho1 = np.outer(psi1, psi1.conj())
        rho2 = np.outer(psi2, psi2.conj())

        # Global distinguishability
        D_global = trace_distance(rho1, rho2)

        # Local reduced states (single qubit)
        rho1_A = self.partial_trace(rho1, keep=[0])
        rho2_A = self.partial_trace(rho2, keep=[0])
        D_local = trace_distance(rho1_A, rho2_A)

        sample_points = [{
            "coordinates": {"access": "comparison"},
            "curvature_invariants": {
                "analogy": None
            },
            "local_observables": {
                "trace_distance_global": D_global,
                "trace_distance_single_qubit": D_local,
            },
            "causal_structure": {
                "note": "Distinguishability depends on measurement algebra"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (operational distinguishability proxy)",
            "spacetime": "Two-qubit system",
            "units": {"hbar": 1},
            "parameters": {},
            "notes": {
                "pressure_point": (
                    "State distinguishability is relative to the measurement algebra. "
                    "Globally distinct states can be operationally identical locally."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "global_vs_local_gap": D_global - D_local
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy053MeasurementAlgebraDependence()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
