#!/usr/bin/env python3
"""
Toy 066 — Gauge-fixed propagator vs Ward identity (regulator/gauge-breaking proxy)

What it probes (pressure point):
- Gauge symmetry enforces Ward identities. If your regulator, discretization, or truncation
  breaks gauge invariance, Ward identities fail and unphysical longitudinal modes can leak
  into observables.
- This toy quantifies Ward identity violation in a simple Abelian gauge theory proxy.

Model (controlled proxy; Euclidean momentum space):
- Free U(1) gauge field in covariant gauge with parameter ξ.
- Exact propagator:
    D_{μν}(p) = (δ_{μν} - p_μ p_ν / p^2)/p^2  +  ξ (p_μ p_ν)/(p^4)
  Ward identity for conserved current insertion implies:
    p_μ D_{μν}(p) = ξ p_ν / p^2
- Gauge-invariant observables depend only on transverse part; longitudinal leakage indicates breaking.

Gauge-breaking perturbation (proxy):
- Add a small "bad regulator" term that distorts only the longitudinal sector:
    D'_{μν}(p) = D_{μν}(p) + ε * (p_μ p_ν)/(p^2 + Λ^2)^2
  This spoils the exact Ward identity.

Diagnostics:
- For sampled 4-momenta p, compute:
    W_ν(p) = p_μ D'_{μν}(p) - ξ p_ν / p^2
  Report ||W|| and relative violation.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


def norm(v: List[float]) -> float:
    return math.sqrt(sum(x * x for x in v))


# ----------------------------
# Toy 066
# ----------------------------

class Toy066GaugeFixedPropagatorWardIdentityViolation:
    toy_id = "066"

    def __init__(self, *, xi: float = 1.0, eps: float = 0.05, Lambda: float = 2.0) -> None:
        require(xi >= 0.0, "xi must be >= 0.")
        require(eps >= 0.0, "eps must be >= 0.")
        require(Lambda > 0.0, "Lambda must be > 0.")
        self.xi = float(xi)
        self.eps = float(eps)
        self.Lambda = float(Lambda)

    def p2(self, p: List[float]) -> float:
        return sum(x * x for x in p)

    def D_mu_nu(self, p: List[float], mu: int, nu: int) -> float:
        """
        Euclidean covariant-gauge propagator (component):
          D_{μν} = (δ_{μν} - p_μ p_ν/p^2)/p^2 + xi * p_μ p_ν / p^4
        """
        p2 = self.p2(p)
        require(p2 > 0.0, "p^2 must be > 0 (exclude p=0).")
        delta = 1.0 if mu == nu else 0.0
        pmu, pnu = p[mu], p[nu]
        transverse = (delta - pmu * pnu / p2) / p2
        longitudinal = self.xi * (pmu * pnu) / (p2 * p2)
        return transverse + longitudinal

    def Dprime_mu_nu(self, p: List[float], mu: int, nu: int) -> float:
        """
        Gauge-breaking modified propagator:
          D' = D + eps * p_μ p_ν / (p^2 + Λ^2)^2
        """
        p2 = self.p2(p)
        base = self.D_mu_nu(p, mu, nu)
        pmu, pnu = p[mu], p[nu]
        bad = self.eps * (pmu * pnu) / ((p2 + self.Lambda * self.Lambda) ** 2)
        return base + bad

    def ward_residual(self, p: List[float]) -> Dict[str, Any]:
        """
        Compute W_nu(p) = p_mu D'_{mu nu}(p) - xi * p_nu / p^2
        and norms.
        """
        p2 = self.p2(p)
        require(p2 > 0.0, "p^2 must be > 0.")
        W = [0.0, 0.0, 0.0, 0.0]
        target = [self.xi * p[i] / p2 for i in range(4)]

        for nu in range(4):
            acc = 0.0
            for mu in range(4):
                acc += p[mu] * self.Dprime_mu_nu(p, mu, nu)
            W[nu] = acc - target[nu]

        Wnorm = norm(W)
        tnorm = norm(target)
        rel = None if tnorm == 0.0 else (Wnorm / tnorm)

        return {
            "p": p,
            "p2": p2,
            "W_vector": [finite_or_none(x) for x in W],
            "W_norm": finite_or_none(Wnorm),
            "target_norm": finite_or_none(tnorm),
            "relative_violation_W_over_target": finite_or_none(rel) if rel is not None else None,
        }

    def build_payload(self, p_magnitudes: List[float], directions: List[List[float]]) -> Dict[str, Any]:
        require(len(p_magnitudes) >= 1, "Need at least one p magnitude.")
        require(len(directions) >= 1, "Need at least one direction.")
        require(all(pm > 0.0 for pm in p_magnitudes), "All p magnitudes must be > 0.")

        # Normalize directions
        dirs: List[List[float]] = []
        for d in directions:
            require(len(d) == 4, "Directions must be 4-vectors.")
            dn = norm(d)
            require(dn > 0.0, "Direction vector must be nonzero.")
            dirs.append([x / dn for x in d])

        sample_points: List[Dict[str, Any]] = []

        max_rel = 0.0
        for pm in p_magnitudes:
            for d in dirs:
                p = [pm * x for x in d]
                res = self.ward_residual(p)
                rel = res["relative_violation_W_over_target"]
                if rel is not None:
                    max_rel = max(max_rel, float(rel))

                sample_points.append({
                    "coordinates": {
                        "p_vector": p,
                        "p_magnitude": float(pm),
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "QFT toy; no spacetime curvature.",
                    },
                    "local_observables": {
                        "propagator": {
                            "xi_gauge_parameter": self.xi,
                            "eps_gauge_breaking_strength": self.eps,
                            "Lambda_regulator_scale": self.Lambda,
                        },
                        "ward_identity_test": {
                            "W_vector": res["W_vector"],
                            "W_norm": res["W_norm"],
                            "relative_violation_W_over_target": res["relative_violation_W_over_target"],
                            "interpretation": (
                                "Ward identity residual measures gauge-invariance breaking in the longitudinal sector. "
                                "In exact covariant gauge, residual would be zero (up to numerics)."
                            ),
                        },
                    },
                    "causal_structure": {
                        "note": "Gauge symmetry controls unphysical modes; violations contaminate observables.",
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): gauge symmetry + Ward identity diagnostic",
            "spacetime": "Euclidean momentum space (free U(1) gauge field, covariant gauge)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "xi": self.xi,
                "eps": self.eps,
                "Lambda": self.Lambda,
                "p_magnitudes": p_magnitudes,
                "directions_used": directions,
            },
            "notes": {
                "pressure_point": (
                    "Gauge invariance enforces Ward identities. Regulators or truncations that break gauge symmetry "
                    "produce Ward identity violations, allowing unphysical longitudinal contamination."
                ),
                "key_formulas": {
                    "D_mu_nu": "D=(δ_{μν}-p_μ p_ν/p^2)/p^2 + ξ p_μ p_ν/p^4",
                    "Ward": "p_μ D_{μν} = ξ p_ν/p^2",
                    "D_prime": "D' = D + ε p_μ p_ν/(p^2+Λ^2)^2",
                    "Residual": "W_ν = p_μ D'_{μν} - ξ p_ν/p^2",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_relative_ward_violation_over_samples": finite_or_none(max_rel),
                }
            },
        }

    def export_json(self, p_magnitudes: List[float], directions: List[List[float]], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(p_magnitudes=p_magnitudes, directions=directions)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 066: Ward identity violation from gauge-breaking propagator distortion.")
    ap.add_argument("--xi", type=float, default=1.0, help="Covariant gauge parameter xi (>=0)")
    ap.add_argument("--eps", type=float, default=0.05, help="Gauge-breaking strength eps (>=0)")
    ap.add_argument("--Lambda", type=float, default=2.0, help="Regulator scale Lambda (>0)")
    ap.add_argument("--p", type=str, default="0.5,1,2,4,8", help="Comma-separated momentum magnitudes |p|")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    p_mags = parse_csv_floats(args.p)

    # A small deterministic set of 4D directions
    directions = [
        [1.0, 0.0, 0.0, 0.0],
        [1.0, 1.0, 0.0, 0.0],
        [1.0, 1.0, 1.0, 0.0],
        [1.0, 1.0, 1.0, 1.0],
        [2.0, -1.0, 0.5, -0.25],
    ]

    toy = Toy066GaugeFixedPropagatorWardIdentityViolation(xi=float(args.xi), eps=float(args.eps), Lambda=float(args.Lambda))

    out_path = args.out.strip() or None
    json_path = toy.export_json(p_magnitudes=p_mags, directions=directions, out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
