#!/usr/bin/env python3
"""
Toy 010 — Inequivalent vacua: Bogoliubov transformation stress test

Pressure point:
- Different mode decompositions define inequivalent vacua.
- Particle number is not invariant.
- Same field algebra, different Fock spaces.

Model:
- Free scalar field in 1+1D
- Two mode bases related by Bogoliubov transformation
- Compute particle number expectation mismatch

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy010BogoliubovVacua:
    toy_id = "010"

    def __init__(
        self,
        *,
        alpha: float = 0.8,
        beta: float = 0.6,
        modes: List[int] = [1, 2, 3, 4, 5],
    ) -> None:
        # enforce |alpha|^2 - |beta|^2 = 1 approximately
        self.alpha = alpha
        self.beta = beta
        self.modes = modes

    def particle_number(self) -> Dict[int, float]:
        # ⟨0_A | N_B | 0_A⟩ = |β|^2
        return {n: self.beta**2 for n in self.modes}

    def build_payload(self) -> Dict[str, Any]:
        numbers = self.particle_number()

        sample_points = [{
            "coordinates": {"mode_index": n},
            "curvature_invariants": {
                "bogoliubov_alpha": self.alpha,
                "bogoliubov_beta": self.beta,
            },
            "local_observables": {
                "particle_number_expectation": numbers[n],
            },
            "causal_structure": {
                "vacuum_equivalence": False,
            },
        } for n in self.modes]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (mode space)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "alpha": self.alpha,
                "beta": self.beta,
                "modes": self.modes,
            },
            "notes": {
                "pressure_point": (
                    "Vacuum states related by Bogoliubov transformations "
                    "are generally inequivalent; particle number is observer- and basis-dependent."
                )
            },
            "sample_points": sample_points,
            "observables": {
                "statement": "No invariant notion of particles exists."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy010BogoliubovVacua().export_json()


if __name__ == "__main__":
    main()
