#!/usr/bin/env python3
"""
Toy 068 — IR dressing & infraparticle divergence (soft-photon/QED proxy)

What it probes (pressure point):
- In gauge theories with massless quanta (QED), naive Fock "one-electron" states are not
  physical asymptotic states: they have zero overlap with exact charged states due to
  an infinite cloud of soft photons (infraparticles).
- Inclusive observables are finite (Bloch–Nordsieck / KLN), but exclusive S-matrix elements
  and state overlaps can vanish as IR regulators are removed.

Model (controlled proxy):
- Overlap between a bare charged Fock state and an IR-dressed (coherent) state behaves like:
    |⟨bare | dressed⟩|^2 ~ exp( - A * ln(Λ_IR^{-1}) ) = (Λ_IR)^A
  where Λ_IR is an IR cutoff (e.g., photon mass m_γ or detector energy resolution),
  and A > 0 depends on coupling and kinematics.
- As Λ_IR -> 0, overlap -> 0 (orthogonality catastrophe).

We also track the expected number of soft photons in the dressing:
    N_soft ~ A * ln(Λ_IR^{-1})
which diverges logarithmically.

Diagnostics:
- For a list of IR cutoffs Λ_IR, compute:
  * overlap probability P_overlap
  * log overlap
  * expected soft photon number N_soft
  * rate of decay w.r.t. ln(1/Λ_IR)

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


# ----------------------------
# Toy 068
# ----------------------------

class Toy068IRSoftPhotonDressingInfraparticleDivergence:
    toy_id = "068"

    def __init__(self, *, A: float = 0.2, Lambda_ref: float = 1.0) -> None:
        """
        A: positive coefficient controlling IR catastrophe strength (proxy for coupling/kinematics).
        Lambda_ref: reference scale to make logs dimensionless.
        """
        require(A > 0.0, "A must be > 0.")
        require(Lambda_ref > 0.0, "Lambda_ref must be > 0.")
        self.A = float(A)
        self.Lambda_ref = float(Lambda_ref)

    def overlap_probability(self, Lambda_ir: float) -> float:
        """
        P_overlap(Lambda_ir) = (Lambda_ir / Lambda_ref)^A
        """
        require(Lambda_ir > 0.0, "Lambda_ir must be > 0.")
        x = Lambda_ir / self.Lambda_ref
        return x ** self.A

    def expected_soft_quanta(self, Lambda_ir: float) -> float:
        """
        N_soft(Lambda_ir) = A * ln(Lambda_ref / Lambda_ir)
        """
        require(Lambda_ir > 0.0, "Lambda_ir must be > 0.")
        return self.A * math.log(self.Lambda_ref / Lambda_ir)

    def build_payload(self, Lambda_ir_values: List[float]) -> Dict[str, Any]:
        require(len(Lambda_ir_values) >= 1, "Need at least one Lambda_ir sample.")
        require(all(L > 0.0 for L in Lambda_ir_values), "All Lambda_ir must be > 0.")

        sample_points: List[Dict[str, Any]] = []

        # Track summary slopes in log space
        # log P = A * log(Lambda_ir/Lambda_ref)
        # d(log P)/d(log Lambda_ir) = A
        for L in Lambda_ir_values:
            P = self.overlap_probability(L)
            logP = math.log(P) if P > 0.0 else float("-inf")
            Nsoft = self.expected_soft_quanta(L)

            sample_points.append({
                "coordinates": {
                    "Lambda_ir": float(L),
                    "Lambda_ref": self.Lambda_ref,
                },
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "ir_dressing": {
                        "A_coefficient": self.A,
                        "overlap_probability_bare_vs_dressed": finite_or_none(P),
                        "log_overlap_probability": finite_or_none(logP) if math.isfinite(logP) else None,
                        "expected_soft_quanta_N_soft": finite_or_none(Nsoft),
                        "interpretation": (
                            "As Lambda_ir -> 0, overlap -> 0 and N_soft -> infinity: "
                            "exclusive Fock states become unphysical (infraparticle / IR catastrophe)."
                        ),
                    },
                },
                "causal_structure": {
                    "note": "This is an IR (asymptotic state) failure mode, not a microcausality test.",
                },
            })

        # Summary: smallest cutoff overlap and largest N_soft
        minP = min(self.overlap_probability(L) for L in Lambda_ir_values)
        maxN = max(self.expected_soft_quanta(L) for L in Lambda_ir_values)

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): IR dressing / infraparticle orthogonality catastrophe proxy",
            "spacetime": "Minkowski asymptotics (IR regulated)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "A": self.A,
                "Lambda_ref": self.Lambda_ref,
                "Lambda_ir_samples": Lambda_ir_values,
            },
            "notes": {
                "pressure_point": (
                    "In theories with massless gauge bosons, naive Fock charged states are not physical asymptotic states. "
                    "As the IR regulator is removed, overlaps with bare states vanish and soft radiation becomes infinite. "
                    "Inclusive observables remain finite but exclusive amplitudes lose meaning."
                ),
                "key_formulas": {
                    "overlap": "P_overlap = (Lambda_ir/Lambda_ref)^A",
                    "soft_number": "N_soft = A ln(Lambda_ref/Lambda_ir)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "min_overlap_probability_over_samples": finite_or_none(minP),
                    "max_expected_soft_quanta_over_samples": finite_or_none(maxN),
                    "log_slope_dlogP_dlogLambda": finite_or_none(self.A),
                }
            },
        }

    def export_json(self, Lambda_ir_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(Lambda_ir_values=Lambda_ir_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 068: IR dressing and infraparticle orthogonality catastrophe proxy.")
    ap.add_argument("--A", type=float, default=0.2, help="IR catastrophe strength coefficient A (>0)")
    ap.add_argument("--Lambda_ref", type=float, default=1.0, help="Reference scale for logs (>0)")
    ap.add_argument("--Lambda_ir", type=str, default="1e-1,3e-2,1e-2,3e-3,1e-3,3e-4,1e-4",
                    help="Comma-separated IR cutoffs (>0)")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy068IRSoftPhotonDressingInfraparticleDivergence(A=float(args.A), Lambda_ref=float(args.Lambda_ref))
    Lvals = parse_csv_floats(args.Lambda_ir)

    out_path = args.out.strip() or None
    json_path = toy.export_json(Lambda_ir_values=Lvals, out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
