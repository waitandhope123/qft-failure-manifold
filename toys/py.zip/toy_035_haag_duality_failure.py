#!/usr/bin/env python3
"""
Toy 035 — Haag duality failure (boundary degrees of freedom)

Pressure point:
- The algebra of observables in a region is not always equal to the
  commutant of its complement (Haag duality can fail).
- Boundary degrees of freedom and global constraints obstruct clean duality.
- Local completeness of observables breaks down.

GR parallel:
- Bulk/boundary mismatch
- Edge modes at horizons and boundaries

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Local observable algebra for an interval (proxy)
- Compare naive algebra vs commutant-based reconstruction
- Track boundary contribution mismatch

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy035HaagDualityFailure:
    toy_id = "035"

    def __init__(
        self,
        *,
        region_sizes: List[float] = [1.0, 2.0, 5.0],
        boundary_mode_strength: float = 1.0,
    ) -> None:
        self.regions = [float(R) for R in region_sizes]
        self.edge = float(boundary_mode_strength)

    def algebra_dimension_proxy(self, region_size: float) -> float:
        """
        Proxy for size of local observable algebra.
        """
        return region_size

    def commutant_dimension_proxy(self, region_size: float) -> float:
        """
        Proxy for commutant algebra size including boundary modes.
        """
        return region_size + self.edge

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for R in self.regions:
            A = self.algebra_dimension_proxy(R)
            C = self.commutant_dimension_proxy(R)

            sample_points.append({
                "coordinates": {
                    "region_size": R,
                },
                "curvature_invariants": {
                    "boundary_modes_present": True,
                },
                "local_observables": {
                    "local_algebra_dimension_proxy": A,
                    "commutant_algebra_dimension_proxy": C,
                },
                "causal_structure": {
                    "haag_duality_exact": A == C,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (interval algebra)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "region_sizes": self.regions,
                "boundary_mode_strength": self.edge,
            },
            "notes": {
                "assumptions": [
                    "Boundary (edge) modes included",
                    "Local algebra treated as proxy",
                ],
                "pressure_point": (
                    "Haag duality can fail due to boundary degrees of freedom. "
                    "The observable content of a region is not fully captured "
                    "by its naive local algebra."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "haag_duality": False,
                    "local_completeness": False,
                },
                "regime_classification": {
                    "no_edge_modes": "haag_duality_holds",
                    "edge_modes_present": "duality_failure",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy035HaagDualityFailure().export_json()


if __name__ == "__main__":
    main()
