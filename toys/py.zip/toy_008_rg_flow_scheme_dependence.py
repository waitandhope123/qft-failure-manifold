#!/usr/bin/env python3
"""
Toy 008 — Renormalization-group flow & scheme dependence (φ^4 coupling)

Pressure point:
- Running couplings depend on renormalization scheme and scale.
- “The value of the coupling” is not an invariant quantity.
- Physics is encoded in relations across scales, not parameters at one scale.

Model:
- φ^4 theory in 1+1D (super-renormalizable; use a toy beta function)
- Compare two schemes with different finite parts
- Integrate RG flow numerically

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


# ----------------------------
# Toy 008
# ----------------------------

class Toy008RGFlowSchemeDependence:
    toy_id = "008"

    def __init__(
        self,
        *,
        lambda0: float = 0.2,
        mu0: float = 1.0,
        mus: List[float] = [0.5, 1.0, 2.0, 5.0, 10.0],
        beta_coeff: float = 0.1,
        scheme_shift: float = 0.05,
    ) -> None:
        self.lambda0 = float(lambda0)
        self.mu0 = float(mu0)
        self.mus = [float(mu) for mu in mus]
        self.b = float(beta_coeff)
        self.delta = float(scheme_shift)

    # Simple toy beta function: dλ/d ln μ = b λ^2
    def run_lambda(self, mu: float, scheme: str) -> Optional[float]:
        if mu <= 0:
            return None
        denom = 1.0 - self.b * self.lambda0 * math.log(mu / self.mu0)
        if denom <= 0:
            return None
        lam = self.lambda0 / denom
        if scheme == "B":
            lam += self.delta * lam**2  # finite scheme-dependent shift
        return lam

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for mu in self.mus:
            lam_A = self.run_lambda(mu, "A")
            lam_B = self.run_lambda(mu, "B")

            sample_points.append({
                "coordinates": {
                    "renormalization_scale_mu": mu,
                },
                "curvature_invariants": {
                    "beta_coefficient_b": self.b,
                },
                "local_observables": {
                    "lambda_scheme_A": lam_A,
                    "lambda_scheme_B": lam_B,
                    "difference": None if (lam_A is None or lam_B is None) else lam_B - lam_A,
                },
                "causal_structure": {
                    "landau_pole_encountered": (lam_A is None or lam_B is None),
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (RG flow)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "lambda0": self.lambda0,
                "mu0": self.mu0,
                "beta_coefficient": self.b,
                "scheme_shift": self.delta,
                "mu_samples": self.mus,
            },
            "notes": {
                "assumptions": [
                    "Perturbative RG flow",
                    "Toy beta function",
                    "Two renormalization schemes differing by finite terms",
                ],
                "pressure_point": (
                    "Running couplings are scheme-dependent. "
                    "Only relations between observables across scales are physical."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "invariant_statement": "No unique coupling value exists at a single scale."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy008RGFlowSchemeDependence()
    toy.export_json()


if __name__ == "__main__":
    main()
