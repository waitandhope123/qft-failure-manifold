#!/usr/bin/env python3
"""
Toy 012 — Haag's theorem stress test (interaction picture obstruction)

Pressure point:
- Interacting QFT cannot share the same Hilbert space as free QFT.
- The interaction picture does not exist nonperturbatively.
- “Free + interaction” is not a well-defined global decomposition.

Model:
- Scalar field in 1+1D
- Compare free vs interacting Hamiltonian ground states (proxy)
- Diagnose orthogonality growth with volume / mode count

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


# ----------------------------
# Toy 012
# ----------------------------

class Toy012HaagTheoremProxy:
    toy_id = "012"

    def __init__(
        self,
        *,
        coupling: float = 0.1,
        mode_counts: List[int] = [10, 20, 40, 80],
    ) -> None:
        self.lam = float(coupling)
        self.mode_counts = [int(n) for n in mode_counts]

    def vacuum_overlap_proxy(self, N: int) -> float:
        """
        Proxy for vacuum overlap:
        ⟨0_free | 0_int⟩ ~ exp(-c λ^2 N)
        capturing orthogonality catastrophe as N → ∞.
        """
        c = 0.5
        return math.exp(-c * self.lam * self.lam * N)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for N in self.mode_counts:
            overlap = self.vacuum_overlap_proxy(N)

            sample_points.append({
                "coordinates": {
                    "mode_count_N": N,
                },
                "curvature_invariants": {
                    "hilbert_space_dimension_proxy": N,
                },
                "local_observables": {
                    "vacuum_overlap_proxy": overlap,
                    "unitarily_equivalent": overlap > 1e-3,
                },
                "causal_structure": {
                    "interaction_picture_valid": overlap > 1e-3,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (mode space)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "coupling_lambda": self.lam,
                "mode_counts": self.mode_counts,
            },
            "notes": {
                "assumptions": [
                    "Scalar field",
                    "Weak interaction treated via overlap proxy",
                ],
                "pressure_point": (
                    "Free and interacting vacua become orthogonal in the infinite-mode limit. "
                    "The interaction picture fails nonperturbatively (Haag’s theorem)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "trend": "Vacuum overlap decays exponentially with number of modes."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    Toy012HaagTheoremProxy().export_json()


if __name__ == "__main__":
    main()
