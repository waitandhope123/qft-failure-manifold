#!/usr/bin/env python3
"""
Toy 007 — Källén–Lehmann spectral positivity stress test

Pressure point:
- Not every two-point function corresponds to a physical QFT.
- Spectral density must be positive for a unitary theory.
- Approximations, truncations, or ad-hoc propagators can violate positivity.

Model:
- Free scalar field in 1+1D (control)
- Construct spectral density numerically from propagator
- Introduce a deformed propagator to demonstrate positivity violation

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


# ----------------------------
# Toy 007
# ----------------------------

class Toy007SpectralPositivity:
    toy_id = "007"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        deformation_alpha: float = 0.3,
        omega_max: float = 10.0,
        domega: float = 0.02,
    ) -> None:
        self.m = float(mass)
        self.alpha = float(deformation_alpha)
        self.omega_max = float(omega_max)
        self.domega = float(domega)

    # Free spectral density (exact)
    def rho_free(self, omega: float) -> float:
        return 1.0 if omega >= self.m else 0.0

    # Deformed (non-QFT-consistent) spectral density
    def rho_deformed(self, omega: float) -> float:
        base = self.rho_free(omega)
        return base * (1.0 - self.alpha * math.sin(omega))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        omega = 0.0
        while omega <= self.omega_max:
            rho_f = self.rho_free(omega)
            rho_d = self.rho_deformed(omega)

            sample_points.append({
                "coordinates": {
                    "energy_omega": omega,
                },
                "curvature_invariants": {
                    "spectral_threshold_mass": self.m,
                },
                "local_observables": {
                    "rho_free": rho_f,
                    "rho_deformed": rho_d,
                },
                "causal_structure": {
                    "positivity_free": rho_f >= 0.0,
                    "positivity_deformed": rho_d >= 0.0,
                },
            })

            omega += self.domega

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (spectral representation)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "deformation_alpha": self.alpha,
                "omega_max": self.omega_max,
                "domega": self.domega,
            },
            "notes": {
                "assumptions": [
                    "Scalar two-point function",
                    "Spectral representation",
                ],
                "pressure_point": (
                    "Spectral positivity is a nontrivial constraint. "
                    "Small deformations of propagators can violate unitarity."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "unitarity_test": "ρ(ω) ≥ 0 required for physical QFT",
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy007SpectralPositivity()
    toy.export_json()


if __name__ == "__main__":
    main()
