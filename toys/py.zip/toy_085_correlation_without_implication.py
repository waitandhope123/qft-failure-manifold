#!/usr/bin/env python3
"""
Toy 085 — Correlation without implication (failure-mode non-implication test)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
- Undefined quantities are exported as null.
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 085
# ----------------------------

class Toy085CorrelationWithoutImplication:
    toy_id = "085"

    def __init__(
        self,
        *,
        threshold_A: float = 0.4,
        threshold_B: float = 0.4,
        power_A: float = 1.0,
        power_B: float = 1.0,
    ) -> None:
        require(threshold_A > 0.0, "threshold_A must be > 0.")
        require(threshold_B > 0.0, "threshold_B must be > 0.")
        self.threshold_A = float(threshold_A)
        self.threshold_B = float(threshold_B)
        self.power_A = float(power_A)
        self.power_B = float(power_B)

    # correlated but distinct diagnostics
    def metric_A(self, x: float) -> float:
        return x ** self.power_A

    def metric_B(self, x: float) -> float:
        return (x ** self.power_B) * (1.0 + 0.2 * math.sin(5.0 * x))

    def build_payload(self, x_values: List[float]) -> Dict[str, Any]:
        require(len(x_values) >= 5, "Need multiple x samples.")
        require(all(x >= 0.0 for x in x_values), "x must be >= 0.")

        sample_points: List[Dict[str, Any]] = []

        violations = []

        for x in x_values:
            A = self.metric_A(x)
            B = self.metric_B(x)

            fail_A = A >= self.threshold_A
            fail_B = B >= self.threshold_B

            if fail_A and not fail_B:
                violations.append(("A_not_B", x))
            if fail_B and not fail_A:
                violations.append(("B_not_A", x))

            sample_points.append({
                "coordinates": {"x": x},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Abstract diagnostic space; no spacetime curvature.",
                },
                "local_observables": {
                    "metric_A": finite_or_none(A),
                    "metric_B": finite_or_none(B),
                    "threshold_A": self.threshold_A,
                    "threshold_B": self.threshold_B,
                    "A_failed": fail_A,
                    "B_failed": fail_B,
                },
                "causal_structure": {
                    "note": (
                        "Metrics are correlated but failure of one does not imply failure of the other."
                    ),
                },
            })

        implication_holds = len(violations) == 0

        return {
            "toy_id": self.toy_id,
            "theory": "Meta: correlation without implication",
            "spacetime": "Abstract one-parameter diagnostic space",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "threshold_A": self.threshold_A,
                "threshold_B": self.threshold_B,
                "power_A": self.power_A,
                "power_B": self.power_B,
                "x_samples": x_values,
            },
            "notes": {
                "pressure_point": (
                    "Even strongly correlated diagnostics need not imply each other’s failure; "
                    "correlation is weaker than implication."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "implication_A_implies_B": implication_holds,
                    "counterexamples": [
                        {"type": v[0], "x": finite_or_none(v[1])} for v in violations
                    ],
                }
            },
        }

    def export_json(self, x_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(x_values=x_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    x_values = [i / 200.0 for i in range(0, 201)]

    toy = Toy085CorrelationWithoutImplication()
    json_path = toy.export_json(x_values=x_values)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
