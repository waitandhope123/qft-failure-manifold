#!/usr/bin/env python3
"""
Toy 091 — Källén–Lehmann reconstruction non-uniqueness under noisy Euclidean data (ill-posed inverse problem)

What it probes (pressure point):
- Euclidean correlators G(t) do not uniquely determine the real-time/spectral content when data is finite
  and noisy; analytic continuation / spectral reconstruction is ill-posed.
- Small perturbations in G(t) can cause large changes in inferred spectral density ρ(ω).
- Different regularization choices (priors) yield mutually incompatible “best-fit” spectra.

Model (controlled, deterministic):
- Spectral representation (toy discretization):
    G(t) = ∫_0^∞ dω  ρ(ω) e^{-ω t}
  Discretize ω on a grid and t on a grid:
    G ≈ K ρ,   K_{i j} = exp(-ω_j t_i) Δω

- Generate a ground-truth spectrum as a sum of Gaussians (positive).
- Compute exact G_true, then add deterministic "noise" pattern:
    G_noisy = G_true * (1 + eta * sin(phase*i))
  (no randomness)

- Reconstruct ρ via Tikhonov regularization:
    ρ_hat = argmin_{ρ>=0} ||Kρ - G_noisy||^2 + α ||Lρ||^2
  where L is a discrete second-derivative (smoothness prior).
- Enforce nonnegativity by simple projection (clip) after solving; iterate a few times.

Diagnostics:
- Reconstruction error in correlator space: ||Kρ_hat - G_noisy|| / ||G_noisy||
- Reconstruction variability across α values: pairwise distances between ρ_hat(α)
- Resolution loss: peak positions/amplitudes drift with α, even while G-fit stays good.

Determinism:
- No randomness.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 091
# ----------------------------

class Toy091KallenLehmannReconstructionIllPosed:
    toy_id = "091"

    def __init__(
        self,
        *,
        t_max: float = 6.0,
        n_t: int = 60,
        w_max: float = 10.0,
        n_w: int = 200,
        eta: float = 0.01,
        noise_phase: float = 0.7,
        n_proj_iters: int = 6,
    ) -> None:
        require(t_max > 0.0, "t_max must be > 0.")
        require(n_t >= 10, "n_t must be >= 10.")
        require(w_max > 0.0, "w_max must be > 0.")
        require(n_w >= 50, "n_w must be >= 50.")
        require(eta >= 0.0, "eta must be >= 0.")
        require(n_proj_iters >= 1, "n_proj_iters must be >= 1.")
        self.t_max = float(t_max)
        self.n_t = int(n_t)
        self.w_max = float(w_max)
        self.n_w = int(n_w)
        self.eta = float(eta)
        self.noise_phase = float(noise_phase)
        self.n_proj_iters = int(n_proj_iters)

        self.t_grid = np.linspace(0.0, self.t_max, self.n_t)
        self.w_grid = np.linspace(0.0, self.w_max, self.n_w)
        self.dw = float(self.w_grid[1] - self.w_grid[0])

        # kernel K_{i j} = exp(-w_j t_i) * dw
        T, W = np.meshgrid(self.t_grid, self.w_grid, indexing="ij")
        self.K = np.exp(-W * T) * self.dw

        # smoothness operator (second derivative) for ρ
        self.L = self._second_derivative_matrix(self.n_w)

    def _second_derivative_matrix(self, n: int) -> np.ndarray:
        L = np.zeros((n, n), dtype=float)
        for i in range(n):
            if i > 0:
                L[i, i - 1] = 1.0
            L[i, i] = -2.0
            if i < n - 1:
                L[i, i + 1] = 1.0
        # boundary softening
        L[0, 0] = -1.0
        L[-1, -1] = -1.0
        return L

    def _rho_true(self) -> np.ndarray:
        # deterministic “true” spectrum: sum of Gaussians, strictly positive
        w = self.w_grid
        rho = (
            0.9 * np.exp(-0.5 * ((w - 1.8) / 0.25) ** 2)
            + 0.6 * np.exp(-0.5 * ((w - 4.2) / 0.35) ** 2)
            + 0.3 * np.exp(-0.5 * ((w - 7.2) / 0.50) ** 2)
        )
        rho = np.maximum(rho, 0.0)
        return rho

    def _noise_pattern(self) -> np.ndarray:
        i = np.arange(self.n_t, dtype=float)
        return 1.0 + self.eta * np.sin(self.noise_phase * i)

    def _solve_tikhonov_nonneg(self, G: np.ndarray, alpha: float) -> np.ndarray:
        """
        Solve (K^T K + alpha L^T L) rho = K^T G with iterative nonneg projection.
        Deterministic. Not perfect NNLS, but adequate for the toy pressure point.
        """
        KT = self.K.T
        A = KT @ self.K + float(alpha) * (self.L.T @ self.L)
        b = KT @ G

        # start from unconstrained solution
        rho = np.linalg.solve(A, b)

        # project to nonnegative and re-solve with fixed active set approximation
        for _ in range(self.n_proj_iters):
            rho = np.maximum(rho, 0.0)
            active = (rho > 0.0)
            if not np.any(active):
                break
            # solve restricted system on active set
            Aaa = A[np.ix_(active, active)]
            baa = b[active]
            sol = np.linalg.solve(Aaa, baa)
            rho_new = np.zeros_like(rho)
            rho_new[active] = sol
            rho = np.maximum(rho_new, 0.0)

        return rho

    def _rel_fit_error(self, G_fit: np.ndarray, G_target: np.ndarray) -> float:
        num = float(np.linalg.norm(G_fit - G_target))
        den = float(np.linalg.norm(G_target) + 1e-30)
        return num / den

    def build_payload(self, alphas: List[float]) -> Dict[str, Any]:
        require(len(alphas) >= 3, "Need multiple alpha values to show non-uniqueness.")
        require(all(a > 0.0 for a in alphas), "alpha values must be > 0.")

        rho_true = self._rho_true()
        G_true = self.K @ rho_true
        G_noisy = G_true * self._noise_pattern()

        # reconstructions
        recons: Dict[float, Dict[str, Any]] = {}
        rhos: List[np.ndarray] = []
        fit_errors: List[float] = []

        for alpha in alphas:
            rho_hat = self._solve_tikhonov_nonneg(G_noisy, float(alpha))
            G_hat = self.K @ rho_hat
            err = self._rel_fit_error(G_hat, G_noisy)

            rhos.append(rho_hat)
            fit_errors.append(err)

            # simple peak diagnostics: top-3 maxima locations
            peaks = []
            rho_c = rho_hat.copy()
            for _ in range(3):
                j = int(np.argmax(rho_c))
                peaks.append({"omega": float(self.w_grid[j]), "rho": float(rho_hat[j])})
                # suppress neighborhood
                lo = max(0, j - 5)
                hi = min(self.n_w, j + 6)
                rho_c[lo:hi] = 0.0

            recons[float(alpha)] = {
                "alpha": float(alpha),
                "rel_fit_error_to_G_noisy": finite_or_none(err),
                "rho_L1": finite_or_none(float(np.sum(rho_hat) * self.dw)),
                "rho_L2": finite_or_none(float(np.linalg.norm(rho_hat))),
                "top_peaks": peaks,
            }

        # variability across alphas
        # pairwise L2 distances between reconstructed spectra
        pairwise: List[Dict[str, Any]] = []
        for i in range(len(alphas)):
            for j in range(i + 1, len(alphas)):
                di = float(np.linalg.norm(rhos[i] - rhos[j]))
                pairwise.append({
                    "alpha_i": float(alphas[i]),
                    "alpha_j": float(alphas[j]),
                    "rho_L2_distance": finite_or_none(di),
                })

        # record a few sample points over alpha as canonical schema sample_points
        sample_points: List[Dict[str, Any]] = []
        for alpha in alphas:
            info = recons[float(alpha)]
            sample_points.append({
                "coordinates": {"alpha": float(alpha)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Inverse problem in Euclidean QFT; no spacetime curvature.",
                },
                "local_observables": {
                    "rel_fit_error_to_G_noisy": info["rel_fit_error_to_G_noisy"],
                    "rho_L1": info["rho_L1"],
                    "rho_L2": info["rho_L2"],
                    "top_peaks": info["top_peaks"],
                },
                "causal_structure": {
                    "note": (
                        "Multiple distinct spectra fit the same noisy Euclidean data well; "
                        "analytic continuation/reconstruction is ill-posed and prior-dependent."
                    ),
                },
            })

        # overall summary stats
        best_err = min(fit_errors) if fit_errors else None
        worst_err = max(fit_errors) if fit_errors else None
        variability = None
        if pairwise:
            variability = max(p["rho_L2_distance"] for p in pairwise if p["rho_L2_distance"] is not None)

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): Källén–Lehmann reconstruction ill-posedness under noisy Euclidean data",
            "spacetime": "Euclidean time correlator (Laplace transform inversion proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "t_max": self.t_max,
                "n_t": self.n_t,
                "w_max": self.w_max,
                "n_w": self.n_w,
                "eta_noise_level": self.eta,
                "noise_phase": self.noise_phase,
                "alpha_samples": alphas,
                "projection_iters": self.n_proj_iters,
            },
            "notes": {
                "pressure_point": (
                    "Spectral reconstruction from Euclidean correlators is ill-posed: many different ρ(ω) can fit "
                    "finite/noisy G(t) comparably well. Results depend strongly on the regularization/prior (α)."
                ),
                "representation": "G(t) = ∫ ρ(ω) e^{-ω t} dω  (discretized: G≈Kρ).",
                "regularization": "Tikhonov with smoothness prior α||Lρ||^2 and nonnegativity projection.",
            },
            "sample_points": sample_points,
            "observables": {
                "reconstructions_by_alpha": recons,
                "pairwise_rho_distances": pairwise,
                "summary": {
                    "best_rel_fit_error": finite_or_none(best_err) if best_err is not None else None,
                    "worst_rel_fit_error": finite_or_none(worst_err) if worst_err is not None else None,
                    "max_pairwise_rho_L2_distance": finite_or_none(variability) if variability is not None else None,
                    "interpretation": "Small changes in prior (alpha) produce large changes in reconstructed spectrum.",
                },
            },
        }

    def export_json(self, alphas: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(alphas=alphas)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 091: Källén–Lehmann reconstruction ill-posedness (deterministic).")
    ap.add_argument("--t_max", type=float, default=6.0, help="Max Euclidean time")
    ap.add_argument("--n_t", type=int, default=60, help="Number of time samples")
    ap.add_argument("--w_max", type=float, default=10.0, help="Max omega")
    ap.add_argument("--n_w", type=int, default=200, help="Number of omega bins")
    ap.add_argument("--eta", type=float, default=0.01, help="Deterministic noise level")
    ap.add_argument("--noise_phase", type=float, default=0.7, help="Noise phase")
    ap.add_argument("--alphas", type=str, default="1e-6,1e-4,1e-2,1e0,1e2",
                    help="Comma-separated regularization strengths alpha")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy091KallenLehmannReconstructionIllPosed(
        t_max=float(args.t_max),
        n_t=int(args.n_t),
        w_max=float(args.w_max),
        n_w=int(args.n_w),
        eta=float(args.eta),
        noise_phase=float(args.noise_phase),
    )

    alphas = parse_csv_floats(args.alphas)
    out_path = args.out.strip() or None
    json_path = toy.export_json(alphas=alphas, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
