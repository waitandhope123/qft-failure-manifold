#!/usr/bin/env python3
"""
Toy 087 — Metastable positive vacuum energy (false de Sitter proxy)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
"""

from __future__ import annotations

import json, math, os
from typing import Any, Dict, List, Optional

def py_to_json_name(p: str) -> str:
    return os.path.splitext(os.path.basename(p))[0] + ".json"

def finite_or_none(x: Any) -> Optional[float]:
    try:
        x = float(x)
        return x if math.isfinite(x) else None
    except Exception:
        return None

class Toy087MetastableVacuumEnergy:
    toy_id = "087"

    def potential(self, phi: float) -> float:
        return (phi**2 - 1.0)**2 + 0.2 * phi

    def build_payload(self, phi_values: List[float]) -> Dict[str, Any]:
        sample_points = []
        min_found = None

        for phi in phi_values:
            V = self.potential(phi)
            if min_found is None or V < min_found:
                min_found = V

            sample_points.append({
                "coordinates": {"phi": phi},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Scalar EFT proxy.",
                },
                "local_observables": {
                    "vacuum_energy": finite_or_none(V),
                },
                "causal_structure": {
                    "note": "Local minimum can be positive but unstable.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "QFT: metastable positive vacuum energy",
            "spacetime": "Scalar EFT",
            "units": {"G": 1, "c": 1},
            "parameters": {"phi_samples": phi_values},
            "notes": {
                "pressure_point": "Positive vacuum energy does not imply stability.",
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "global_minimum_energy": finite_or_none(min_found),
                    "metastable": True,
                }
            },
        }

    def export_json(self, phi_values: List[float]) -> str:
        out = py_to_json_name(__file__)
        with open(out, "w") as f:
            json.dump(self.build_payload(phi_values), f, indent=2, sort_keys=True)
        return out

def main() -> None:
    phis = [-2 + 0.02*i for i in range(200)]
    Toy087MetastableVacuumEnergy().export_json(phis)
    print("Wrote", py_to_json_name(__file__))

if __name__ == "__main__":
    main()
