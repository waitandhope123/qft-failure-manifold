#!/usr/bin/env python3
"""
Toy 042 — Tracing out degrees of freedom (open-system non-unitarity)

Pressure point:
- Reduced dynamics of subsystems are not unitary.
- There is no invariant Hamiltonian evolution for subsystems once degrees
  of freedom are traced out.

Model:
- Two coupled harmonic oscillators (A,B).
- Global unitary evolution.
- Reduced density matrix for A shows entropy growth and decoherence.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def von_neumann_entropy(rho: np.ndarray) -> float:
    vals = np.linalg.eigvalsh(rho)
    vals = [v for v in vals if v > 1e-12]
    return float(-sum(v * math.log(v) for v in vals))


class Toy042OpenSystemNonUnitarity:
    toy_id = "042"

    def __init__(
        self,
        *,
        omega: float = 1.0,
        g: float = 0.2,
        dt: float = 0.05,
        steps: int = 200,
    ) -> None:
        require(omega > 0.0, "omega>0")
        require(dt > 0.0 and steps >= 1, "dt>0, steps>=1")
        self.omega = float(omega)
        self.g = float(g)
        self.dt = float(dt)
        self.steps = int(steps)

        # basis: |00>, |01>, |10>, |11>
        self.dim = 4

        # Hamiltonian (two coupled oscillators truncated to 0/1 quanta)
        a = np.array([[0, 1], [0, 0]], dtype=complex)
        adag = a.T.conj()
        I = np.eye(2)

        H_A = self.omega * np.kron(adag @ a, I)
        H_B = self.omega * np.kron(I, adag @ a)
        H_int = self.g * np.kron(adag + a, adag + a)

        self.H = H_A + H_B + H_int

    def evolve(self) -> Dict[str, Any]:
        # initial product vacuum
        psi = np.zeros((self.dim,), dtype=complex)
        psi[0] = 1.0

        sample_points: List[Dict[str, Any]] = []

        for step in range(self.steps + 1):
            t = step * self.dt

            rho = np.outer(psi, psi.conj())

            # trace out B
            rho_A = np.zeros((2, 2), dtype=complex)
            for i in range(2):
                for j in range(2):
                    rho_A[i, j] = rho[2 * i + 0, 2 * j + 0] + rho[2 * i + 1, 2 * j + 1]

            S_A = von_neumann_entropy(rho_A)

            sample_points.append({
                "coordinates": {"t": t},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "entropy_subsystem_A": S_A,
                    "purity_subsystem_A": float(np.real(np.trace(rho_A @ rho_A))),
                },
                "causal_structure": {
                    "note": "Reduced dynamics is non-unitary"
                },
            })

            # global unitary step
            if step < self.steps:
                U = np.eye(self.dim) - 1j * self.H * self.dt
                psi = U @ psi
                psi = psi / np.linalg.norm(psi)

        return sample_points

    def build_payload(self) -> Dict[str, Any]:
        sample_points = self.evolve()
        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (open-system proxy)",
            "spacetime": "Coupled quantum oscillators",
            "units": {"hbar": 1},
            "parameters": {
                "omega": self.omega,
                "coupling_g": self.g,
                "dt": self.dt,
                "steps": self.steps,
            },
            "notes": {
                "pressure_point": (
                    "Subsystem dynamics is not unitary once degrees of freedom "
                    "are traced out; no invariant local Hamiltonian exists."
                ),
                "approximation": "Finite-dimensional truncation",
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "final_entropy_A": sample_points[-1]["local_observables"]["entropy_subsystem_A"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy042OpenSystemNonUnitarity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
