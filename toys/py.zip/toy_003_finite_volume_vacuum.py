#!/usr/bin/env python3
"""
Toy 003 — Free scalar QFT in finite volume: boundary / IR sensitivity

Pressure point:
- QFT observables depend on global boundary conditions.
- Vacuum correlators change with box size even in flat spacetime.
- No strictly local notion of the vacuum exists.

Model:
- Free real scalar field in 1+1D
- Periodic spatial box of length L
- Vacuum state
- Compare correlator at fixed separation for different L

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 003
# ----------------------------

class Toy003FiniteVolumeQFT:
    toy_id = "003"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        box_lengths: List[float] = [10.0, 20.0, 40.0],
        k_max: int = 200,
    ) -> None:
        require(mass >= 0.0, "mass must be >= 0")
        self.m = float(mass)
        self.box_lengths = [float(L) for L in box_lengths]
        self.k_max = int(k_max)

    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def correlator(self, x: float, L: float) -> float:
        """
        Equal-time vacuum correlator in finite volume:
        G(x) = sum_k 1/(2L ω_k) cos(k x)
        k = 2π n / L
        """
        s = 0.0
        for n in range(-self.k_max, self.k_max + 1):
            k = 2.0 * math.pi * n / L
            w = self.omega(k)
            s += math.cos(k * x) / (2.0 * L * w)
        return s

    def build_payload(self) -> Dict[str, Any]:
        x_probe = 1.0
        sample_points: List[Dict[str, Any]] = []

        for L in self.box_lengths:
            G = self.correlator(x_probe, L)

            sample_points.append({
                "coordinates": {
                    "x": x_probe,
                    "box_length_L": L,
                },
                "curvature_invariants": {
                    "infrared_scale_1_over_L": 1.0 / L,
                    "mode_cutoff_n_max": self.k_max,
                },
                "local_observables": {
                    "equal_time_correlator_G": G,
                },
                "causal_structure": {
                    "boundary_conditions": "periodic",
                    "global_topology": "S1",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D, compact spatial dimension)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "box_lengths": self.box_lengths,
                "mode_cutoff_n_max": self.k_max,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Periodic boundary conditions",
                    "Vacuum state defined by finite-volume modes",
                ],
                "pressure_point": (
                    "Vacuum correlations depend on global boundary conditions. "
                    "There is no strictly local definition of the vacuum independent of IR structure."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "comparison": "Correlator value varies with box size L at fixed separation x."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy003FiniteVolumeQFT()
    toy.export_json()


if __name__ == "__main__":
    main()
