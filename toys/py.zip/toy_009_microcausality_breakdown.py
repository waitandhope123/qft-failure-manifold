#!/usr/bin/env python3
"""
Toy 009 — Microcausality breakdown under regulator deformation

Pressure point:
- Microcausality (field commutators vanish at spacelike separation)
  is exact only in the continuum, Lorentz-invariant theory.
- Certain regulators or deformations spoil strict microcausality.
- Causality is not automatic once the theory is modified.

Model:
- Free scalar field in 1+1D
- Compare standard dispersion vs deformed (Lorentz-violating) dispersion
- Evaluate Pauli–Jordan commutator at spacelike separation

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


# ----------------------------
# Toy 009
# ----------------------------

class Toy009MicrocausalityBreakdown:
    toy_id = "009"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        cutoff: float = 20.0,
        dk: float = 0.02,
        deformation_eps: float = 0.2,
    ) -> None:
        self.m = float(mass)
        self.Lambda = float(cutoff)
        self.dk = float(dk)
        self.eps = float(deformation_eps)

    def omega_standard(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def omega_deformed(self, k: float) -> float:
        # Lorentz-violating deformation
        return math.sqrt(k * k + self.m * self.m) * (1.0 + self.eps * (k / self.Lambda) ** 2)

    def commutator(self, t: float, x: float, deformed: bool) -> float:
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega_deformed(k) if deformed else self.omega_standard(k)
            s += math.sin(w * t) * math.sin(k * x) / (2.0 * math.pi * w)
            k += self.dk
        return s * self.dk

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        # Fixed spacelike separation
        t = 0.5
        x = 2.0
        interval = t * t - x * x

        Delta_std = self.commutator(t, x, deformed=False)
        Delta_def = self.commutator(t, x, deformed=True)

        sample_points.append({
            "coordinates": {
                "t": t,
                "x": x,
            },
            "curvature_invariants": {
                "cutoff_Lambda": self.Lambda,
                "deformation_eps": self.eps,
            },
            "local_observables": {
                "commutator_standard": Delta_std,
                "commutator_deformed": Delta_def,
            },
            "causal_structure": {
                "interval_t2_minus_x2": interval,
                "spacelike": interval < 0.0,
                "microcausality_standard": abs(Delta_std) < abs(Delta_def),
            },
        })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D, deformed dispersion)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "cutoff_Lambda": self.Lambda,
                "dk": self.dk,
                "deformation_eps": self.eps,
            },
            "notes": {
                "assumptions": [
                    "Free scalar field",
                    "Hard momentum cutoff",
                    "Lorentz-violating dispersion deformation",
                ],
                "pressure_point": (
                    "Microcausality relies on exact Lorentz invariance. "
                    "Regulator or dispersion deformations can introduce spacelike signal leakage."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "comparison": "Deformed theory shows larger spacelike commutator magnitude."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy009MicrocausalityBreakdown()
    toy.export_json()


if __name__ == "__main__":
    main()
