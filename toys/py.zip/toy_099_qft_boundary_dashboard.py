#!/usr/bin/env python3
"""
Toy 099 — QFT boundary dashboard (meta-toy: ingests Toy 090–098 JSONs)

What it probes (pressure point):
- Not a new physics pathology: a closure/reporting tool.
- Reads outputs from boundary toys (090–098) and produces a single “dashboard” JSON:
  * per-toy boundary signals (normalized severities)
  * a boundary ordering (“what fails first”)
  * robustness notes (missing fields, schema drift)
  * compact summary suitable for your lab writeup

Inputs:
- JSON files produced by toy_090 ... toy_098 (any subset is allowed)

Outputs:
- A single JSON report:
  * per_file extraction
  * derived boundary severities
  * ordering and overall “control score”

Determinism:
- Deterministic parsing + heuristic scoring.

Usage:
  python toy_099_qft_boundary_dashboard.py --inputs toy_090_*.json,toy_091_*.json --out toy_099_qft_boundary_dashboard.json

If --inputs is omitted:
- auto-globs for toy_090*.json ... toy_098*.json in the current directory.
"""

from __future__ import annotations

import argparse
import glob
import json
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)

def read_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def write_json(path: str, payload: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)

def safe_list(x: Any) -> List[Any]:
    return x if isinstance(x, list) else []

def safe_dict(x: Any) -> Dict[str, Any]:
    return x if isinstance(x, dict) else {}

def as_str(x: Any) -> str:
    return "" if x is None else str(x)

def lower(x: Any) -> str:
    return as_str(x).lower()

def parse_inputs_arg(items: List[str]) -> List[str]:
    out: List[str] = []
    for s in items:
        for part in s.split(","):
            p = part.strip()
            if p:
                out.append(p)
    return out

def auto_find_inputs() -> List[str]:
    paths: List[str] = []
    for tid in range(90, 99):
        paths.extend(sorted(glob.glob(f"toy_{tid:03d}*.json")))
    # de-dup preserving order
    seen = set()
    uniq = []
    for p in paths:
        if p not in seen:
            uniq.append(p)
            seen.add(p)
    return uniq

def health_checks(doc: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    if "toy_id" not in doc:
        issues.append("missing toy_id")
    if "theory" not in doc:
        issues.append("missing theory")
    sp = safe_list(doc.get("sample_points"))
    if not sp:
        issues.append("empty_or_missing sample_points")
    obs = safe_dict(doc.get("observables"))
    if not obs:
        issues.append("empty_or_missing observables")
    return {"ok": (len(issues) == 0), "issues": issues, "n_sample_points": len(sp)}

def clamp01(x: Optional[float]) -> Optional[float]:
    if x is None:
        return None
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x


# ----------------------------
# Boundary signals taxonomy
# ----------------------------

BOUNDARY_SIGNALS = [
    "uv_completability_positivity",
    "analytic_continuation_ill_posed",
    "gauge_ward_identity_scheme_dependence",
    "inequivalent_representations_haag_proxy",
    "rg_scheme_dependence_global_portrait",
    "microcausality_leakage",
    "operator_algebra_reconstruction_nonuniqueness",
    "thermalization_ambiguity_eth_vs_integrable",
    "eft_breakdown_vs_unitarity_proxy",
]

TOY_TO_SIGNAL = {
    "090": ["eft_breakdown_vs_unitarity_proxy", "uv_completability_positivity"],
    "091": ["analytic_continuation_ill_posed"],
    "092": ["gauge_ward_identity_scheme_dependence"],
    "093": ["inequivalent_representations_haag_proxy"],
    "094": ["rg_scheme_dependence_global_portrait"],
    "095": ["microcausality_leakage"],
    "096": ["uv_completability_positivity"],
    "097": ["operator_algebra_reconstruction_nonuniqueness"],
    "098": ["thermalization_ambiguity_eth_vs_integrable"],
}


# ----------------------------
# Extractors: produce normalized severities in [0,1] where higher = "more boundary pressure"
# ----------------------------

def extract_090(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    fr = safe_dict(safe_dict(summ.get("fractions")))
    # More allowed/ok means less severe. Severity = 1 - ok_fraction
    pos_ok = fr.get("positivity_ok")
    pos_unit = fr.get("positivity_ok_and_unitarity_ok_at_EEFT")
    sev_pos = None if pos_ok is None else clamp01(1.0 - float(pos_ok))
    sev_unit = None if pos_unit is None else clamp01(1.0 - float(pos_unit))
    return {
        "eft_breakdown_vs_unitarity_proxy": sev_unit,
        "uv_completability_positivity": sev_pos,
        "raw": {"fractions": fr, "summary": summ},
    }

def extract_091(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    # If max_pairwise distance is large while best fit error is small -> ill-posed.
    best = summ.get("best_rel_fit_error")
    worst = summ.get("worst_rel_fit_error")
    var = summ.get("max_pairwise_rho_L2_distance")
    # heuristic: severity increases with var and decreases with fit error
    sev = None
    if var is not None and best is not None:
        v = float(var)
        b = float(best)
        sev = clamp01(v / (v + 1.0) * (1.0 - min(1.0, b / 0.05)))
    return {"analytic_continuation_ill_posed": sev, "raw": {"summary": summ, "best": best, "worst": worst, "var": var}}

def extract_092(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    w_cut = summ.get("max_ward_residual_hard_cutoff")
    w_dim = summ.get("max_ward_residual_dimreg_proxy")
    sev = None
    if w_cut is not None and w_dim is not None:
        wc = float(w_cut)
        wd = float(w_dim)
        # severity: how much worse hard cutoff is than dimreg proxy, normalized
        sev = clamp01((wc - wd) / (abs(wc) + abs(wd) + 1e-30))
    elif w_cut is not None:
        sev = clamp01(float(w_cut) / (float(w_cut) + 1.0))
    return {"gauge_ward_identity_scheme_dependence": sev, "raw": {"summary": summ}}

def extract_093(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    thresh = safe_dict(summ.get("first_N_where_overlap_below_threshold_by_g"))
    # severity: how quickly overlap collapses (smaller N threshold => higher severity)
    # Convert thresholds to a score in [0,1] by mapping N in [10,800] roughly.
    sev_vals: List[float] = []
    for _, N in thresh.items():
        if N is None:
            continue
        n = float(N)
        # smaller n => closer to 1
        sev_vals.append(clamp01((800.0 - n) / 800.0) or 0.0)
    sev = None if not sev_vals else max(sev_vals)
    return {"inequivalent_representations_haag_proxy": sev, "raw": {"thresholds": thresh}}

def extract_094(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    frac = summ.get("fraction_disagree")
    sev = None if frac is None else clamp01(float(frac))
    return {"rg_scheme_dependence_global_portrait": sev, "raw": {"summary": summ}}

def extract_095(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    mx = summ.get("max_leakage_ratio_observed")
    sev = None
    if mx is not None:
        m = float(mx)
        # normalize leakage_ratio to [0,1] using m/(1+m)
        sev = clamp01(m / (1.0 + m))
    return {"microcausality_leakage": sev, "raw": {"summary": summ}}

def extract_096(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    fr = safe_dict(summ.get("fractions"))
    allowed = fr.get("allowed")
    sev = None if allowed is None else clamp01(1.0 - float(allowed))
    return {"uv_completability_positivity": sev, "raw": {"summary": summ}}

def extract_097(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    match = summ.get("marginals_match_within_numerical_norm")
    # severity: if marginals match but global diagnostics differ -> high. We infer from sample_points.
    sps = safe_list(doc.get("sample_points"))
    # read purity differences between GHZ and mixture
    purities = {}
    for sp in sps:
        case = safe_dict(sp.get("coordinates")).get("case")
        loc = safe_dict(sp.get("local_observables"))
        pur = loc.get("purity_Tr_rho2")
        if case and pur is not None:
            purities[str(case)] = float(pur)
    sev = None
    if match is True:
        p1 = purities.get("true_state_ghz_pure")
        p2 = purities.get("true_state_classical_mixture")
        if p1 is not None and p2 is not None:
            sev = clamp01(min(1.0, abs(p1 - p2)))  # difference is O(1) here
        else:
            sev = 1.0
    return {"operator_algebra_reconstruction_nonuniqueness": sev, "raw": {"summary": summ, "purities": purities}}

def extract_098(doc: Dict[str, Any]) -> Dict[str, Any]:
    summ = safe_dict(safe_dict(doc.get("observables")).get("summary"))
    # severity: if ETH proxy is not supported => higher ambiguity boundary pressure
    ok = summ.get("thermalization_proxy_supports_ETH")
    sev = None
    if ok is True:
        sev = 0.2  # still a boundary: finite size/time window; not zero
    elif ok is False:
        sev = 0.9
    return {"thermalization_ambiguity_eth_vs_integrable": sev, "raw": {"summary": summ}}

EXTRACTORS = {
    "090": extract_090,
    "091": extract_091,
    "092": extract_092,
    "093": extract_093,
    "094": extract_094,
    "095": extract_095,
    "096": extract_096,
    "097": extract_097,
    "098": extract_098,
}


# ----------------------------
# Dashboard assembly
# ----------------------------

def merge_severities(base: Dict[str, Optional[float]], update: Dict[str, Optional[float]]) -> Dict[str, Optional[float]]:
    out = dict(base)
    for k, v in update.items():
        if k == "raw":
            continue
        # combine by max severity if duplicate signal appears
        if k in out and out[k] is not None and v is not None:
            out[k] = max(out[k], v)
        else:
            out[k] = v
    return out

def boundary_order(severities: Dict[str, Optional[float]]) -> List[Dict[str, Any]]:
    items = []
    for sig in BOUNDARY_SIGNALS:
        v = severities.get(sig)
        if v is None:
            continue
        items.append((sig, float(v)))
    items.sort(key=lambda x: x[1], reverse=True)
    return [{"signal": s, "severity": v} for (s, v) in items]

def control_score(severities: Dict[str, Optional[float]]) -> Optional[float]:
    vals = [v for v in severities.values() if v is not None]
    if not vals:
        return None
    # control score = 1 - mean(severity)
    mean = sum(vals) / len(vals)
    return max(0.0, min(1.0, 1.0 - mean))


def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 099: QFT boundary dashboard (ingests Toy 090–098 JSONs).")
    ap.add_argument("--inputs", action="append", default=[],
                    help="Comma-separated list of input JSON files (repeatable). If omitted, auto-detect toy_090..098 JSONs.")
    ap.add_argument("--out", type=str, default="toy_099_qft_boundary_dashboard.json", help="Output JSON path")
    args = ap.parse_args()

    input_paths = parse_inputs_arg(args.inputs)
    if not input_paths:
        input_paths = auto_find_inputs()

    require(len(input_paths) >= 1, "No inputs found. Provide --inputs or place toy_090..098 JSONs in this directory.")

    per_file: List[Dict[str, Any]] = []
    aggregated: Dict[str, Optional[float]] = {k: None for k in BOUNDARY_SIGNALS}

    missing_extractors: List[str] = []
    used_toys: List[str] = []

    for path in input_paths:
        doc = read_json(path)
        tid = as_str(doc.get("toy_id")).zfill(3) if doc.get("toy_id") is not None else ""
        hc = health_checks(doc)

        extracted = {"raw": {}}
        if tid in EXTRACTORS:
            extracted = EXTRACTORS[tid](doc)
            used_toys.append(tid)
            aggregated = merge_severities(aggregated, extracted)
        else:
            missing_extractors.append(tid or "(unknown)")

        per_file.append({
            "file": path,
            "toy_id": doc.get("toy_id"),
            "theory": doc.get("theory"),
            "health": hc,
            "signals_expected": TOY_TO_SIGNAL.get(tid, []),
            "signals_extracted": {k: v for k, v in extracted.items() if k != "raw"},
            "raw_extract": safe_dict(extracted.get("raw")),
        })

    order = boundary_order(aggregated)
    score = control_score(aggregated)

    payload: Dict[str, Any] = {
        "toy_id": "099",
        "theory": "Meta: QFT boundary dashboard (Toy 090–098 aggregator)",
        "parameters": {
            "n_inputs": len(input_paths),
            "inputs": input_paths,
            "signals": BOUNDARY_SIGNALS,
            "used_toy_ids": sorted(list(set(used_toys))),
        },
        "observables": {
            "per_file": per_file,
            "boundary_severities": aggregated,
            "boundary_ordering": order,
            "control_score_0_to_1": score,
            "notes_on_missing_extractors": missing_extractors,
        },
        "notes": {
            "pressure_point": (
                "Closure tool: aggregates boundary signals from toys 090–098, ranks the dominant QFT boundaries, "
                "and produces a single dashboard summary."
            ),
            "interpretation": (
                "Severity near 1 indicates strong boundary pressure (hard to maintain locality/unitarity/uniqueness/control). "
                "Control score near 1 indicates overall good control across the included diagnostics."
            ),
        },
        "sample_points": [],  # meta-toy: primary content is observables/per_file
    }

    write_json(args.out, payload)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
