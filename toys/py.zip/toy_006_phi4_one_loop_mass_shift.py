#!/usr/bin/env python3
"""
Toy 006 — Perturbative breakdown in interacting QFT (φ^4 one-loop self-energy)

Pressure point:
- Perturbation theory produces divergent corrections.
- Renormalization scale and cutoff choices affect intermediate results.
- “Small coupling” does not prevent UV sensitivity.

Model:
- Real scalar field with λ φ^4 interaction in 1+1D
- One-loop self-energy (mass correction) with hard cutoff
- Compare correction vs cutoff

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 006
# ----------------------------

class Toy006Phi4OneLoop:
    toy_id = "006"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        coupling: float = 0.1,
        cutoffs: List[float] = [5.0, 10.0, 20.0, 40.0],
        dk: float = 0.01,
    ) -> None:
        require(mass > 0.0, "mass must be > 0")
        require(coupling >= 0.0, "coupling must be >= 0")

        self.m = float(mass)
        self.lam = float(coupling)
        self.cutoffs = [float(L) for L in cutoffs]
        self.dk = float(dk)

    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def one_loop_mass_shift(self, Lambda: float) -> float:
        """
        δm^2 ≈ (λ/2) ∫ dk / (2π) 1/ω_k
        """
        s = 0.0
        k = -Lambda
        while k <= Lambda:
            s += 1.0 / self.omega(k)
            k += self.dk
        return 0.5 * self.lam * s * self.dk / (2.0 * math.pi)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for Lambda in self.cutoffs:
            dm2 = self.one_loop_mass_shift(Lambda)

            sample_points.append({
                "coordinates": {
                    "momentum_cutoff_Lambda": Lambda,
                },
                "curvature_invariants": {
                    "uv_scale_Lambda": Lambda,
                },
                "local_observables": {
                    "one_loop_mass_shift_delta_m2": dm2,
                    "effective_mass_squared": self.m**2 + dm2,
                },
                "causal_structure": {
                    "lorentz_invariant": False,
                    "note": "Hard cutoff breaks Lorentz invariance.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "bare_mass": self.m,
                "coupling_lambda": self.lam,
                "cutoffs": self.cutoffs,
                "dk": self.dk,
            },
            "notes": {
                "assumptions": [
                    "Weakly coupled φ^4 theory",
                    "One-loop perturbation theory",
                    "Hard momentum cutoff",
                ],
                "pressure_point": (
                    "Perturbative corrections diverge and depend on regulator choice. "
                    "Renormalization is required even at lowest nontrivial order."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "trend": "δm^2 grows logarithmically with cutoff in 1+1D",
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy006Phi4OneLoop()
    toy.export_json()


if __name__ == "__main__":
    main()
