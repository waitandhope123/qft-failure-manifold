#!/usr/bin/env python3
"""
Toy 069 — Semiclassical gravity: stress-tensor noise drives metric instability (stochastic source proxy)

What it probes (pressure point):
- Semiclassical gravity uses G_ab = 8π ⟨T_ab⟩ as a mean-field equation.
- But quantum fields have stress-tensor *fluctuations* (noise) not captured by ⟨T⟩.
- Treating fluctuations as a stochastic source (Einstein–Langevin / stochastic gravity) shows that
  metric perturbations acquire variance that can grow and spoil predictivity of the mean-field solution.

Model (controlled proxy; 1D linear response):
- Consider a single scalar metric perturbation h(t) governed by linear response:
    h¨ + 2γ h˙ + ω0^2 h = κ [ ⟨T⟩ + ξ(t) ]
  where ξ(t) is zero-mean noise with variance σ^2 and correlation time τc.
- We focus on variance growth of h due to ξ(t).

Noise model (Ornstein–Uhlenbeck, analytic variance evolution):
- ξ(t) is OU with ⟨ξ⟩=0, ⟨ξ(t)ξ(t')⟩ = σ^2 exp(-|t-t'|/τc)
- For simplicity and robustness, we discretize time and evolve h(t) deterministically for ⟨T⟩
  plus a second-moment estimate using linear filter approximation:
    Var[h] ≈ ∫_0^t ds ∫_0^t ds' G(t-s)G(t-s') ⟨ξ(s)ξ(s')⟩
  where G is the retarded Green's function of the damped oscillator.

Implementation:
- Compute G(u) analytically (underdamped) or with stable fallback.
- Numerically evaluate the double integral on a time grid (deterministic).
- Output Var[h](t) and compare to mean response h_mean(t) (driven by ⟨T⟩).

Diagnostics:
- For each t:
  * h_mean(t) (for constant ⟨T⟩)
  * Var[h](t)
  * signal-to-noise ratio SNR = |h_mean| / sqrt(Var[h]) (if Var>0)
- Identify when SNR drops below 1 (noise dominates): predictivity loss.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No RNG; computes variance from correlation function.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


# ----------------------------
# Toy 069
# ----------------------------

class Toy069SemiclassicalGravityNoiseInstability:
    toy_id = "069"

    def __init__(self, *, omega0: float = 1.0, gamma: float = 0.05, kappa: float = 1.0,
                 T_mean: float = 1.0, sigma: float = 0.5, tau_c: float = 0.5) -> None:
        require(omega0 > 0.0, "omega0 must be > 0.")
        require(gamma >= 0.0, "gamma must be >= 0.")
        require(kappa >= 0.0, "kappa must be >= 0.")
        require(tau_c > 0.0, "tau_c must be > 0.")
        require(sigma >= 0.0, "sigma must be >= 0.")
        self.omega0 = float(omega0)
        self.gamma = float(gamma)
        self.kappa = float(kappa)
        self.T_mean = float(T_mean)
        self.sigma = float(sigma)
        self.tau_c = float(tau_c)

    def green_retarded(self, u: float) -> float:
        """
        Retarded Green's function for h¨ + 2γ h˙ + ω0^2 h = δ(t):
        Underdamped (γ < ω0): G(u)= (1/ωd) e^{-γ u} sin(ωd u) for u>=0
        Crit/overdamped: use stable sinh form.
        """
        if u < 0.0:
            return 0.0
        w0 = self.omega0
        g = self.gamma
        if g < w0:
            wd = math.sqrt(w0 * w0 - g * g)
            return math.exp(-g * u) * math.sin(wd * u) / wd
        elif g == w0:
            # critical: G(u)=u e^{-ω0 u}
            return u * math.exp(-w0 * u)
        else:
            # overdamped: roots g ± sqrt(g^2-w0^2)
            a = math.sqrt(g * g - w0 * w0)
            # G(u) = (1/(2a)) (e^{-(g-a)u} - e^{-(g+a)u})
            return 0.5 / a * (math.exp(-(g - a) * u) - math.exp(-(g + a) * u))

    def h_mean(self, t: float) -> float:
        """
        Mean response to constant forcing κ T_mean with zero initial conditions:
          h_mean(t) = κ T_mean ∫_0^t G(u) du
        Compute by simple quadrature on a fine grid.
        """
        if t <= 0.0 or self.kappa == 0.0 or self.T_mean == 0.0:
            return 0.0

        # deterministic composite Simpson
        n = 2000
        if n % 2 == 1:
            n += 1
        a = 0.0
        b = t
        h = (b - a) / n

        def f(u: float) -> float:
            return self.green_retarded(u)

        s = f(a) + f(b)
        for i in range(1, n):
            u = a + i * h
            s += (4.0 if i % 2 == 1 else 2.0) * f(u)
        integ = s * (h / 3.0)

        return self.kappa * self.T_mean * integ

    def corr_xi(self, dt: float) -> float:
        # ⟨ξ(t)ξ(t')⟩ = σ^2 e^{-|dt|/τc}
        return (self.sigma ** 2) * math.exp(-abs(dt) / self.tau_c)

    def var_h(self, t: float, dt: float) -> float:
        """
        Var[h](t) = κ^2 ∫_0^t ds ∫_0^t ds' G(t-s) G(t-s') C(s-s')
        Compute with O(N^2) deterministic sum on grid; keep N moderate.
        """
        if t <= 0.0 or self.kappa == 0.0 or self.sigma == 0.0:
            return 0.0

        N = max(10, int(round(t / dt)))
        # Use points s_i = i*dt, i=0..N
        times = [i * dt for i in range(N + 1)]
        Gvals = [self.green_retarded(t - s) for s in times]

        acc = 0.0
        for i, si in enumerate(times):
            Gi = Gvals[i]
            for j, sj in enumerate(times):
                Gj = Gvals[j]
                acc += Gi * Gj * self.corr_xi(si - sj)

        # Riemann sum weight dt^2
        return (self.kappa ** 2) * acc * (dt ** 2)

    def build_payload(self, t_values: List[float], dt_var: float) -> Dict[str, Any]:
        require(len(t_values) >= 1, "Need at least one time sample.")
        require(all(t >= 0.0 for t in t_values), "All t must be >= 0.")
        require(dt_var > 0.0, "dt_var must be > 0.")

        sample_points: List[Dict[str, Any]] = []

        first_snr_below_1 = None

        for t in t_values:
            hm = self.h_mean(float(t))
            vh = self.var_h(float(t), dt=float(dt_var))
            snr = None
            if vh > 0.0:
                snr = abs(hm) / math.sqrt(vh)

            if first_snr_below_1 is None and snr is not None and snr < 1.0:
                first_snr_below_1 = float(t)

            sample_points.append({
                "coordinates": {"t": float(t)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Semiclassical-gravity proxy; metric perturbation treated as 1D linear mode.",
                },
                "local_observables": {
                    "mean_field": {
                        "T_mean": self.T_mean,
                        "h_mean": finite_or_none(hm),
                    },
                    "fluctuations": {
                        "sigma": self.sigma,
                        "tau_c": self.tau_c,
                        "Var_h": finite_or_none(vh),
                        "SNR_abs_h_mean_over_sqrt_Var": finite_or_none(snr) if snr is not None else None,
                    },
                },
                "causal_structure": {
                    "note": "Predictivity fails when stress-tensor noise dominates mean response (SNR<1).",
                },
            })

        max_var = max((sp["local_observables"]["fluctuations"]["Var_h"] or 0.0) for sp in sample_points)

        return {
            "toy_id": self.toy_id,
            "theory": "Semiclassical gravity (toy): Einstein–Langevin / stress-tensor noise proxy",
            "spacetime": "N/A (single perturbation mode)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "omega0": self.omega0,
                "gamma": self.gamma,
                "kappa": self.kappa,
                "T_mean": self.T_mean,
                "sigma": self.sigma,
                "tau_c": self.tau_c,
                "t_samples": t_values,
                "dt_for_variance_quadrature": dt_var,
            },
            "notes": {
                "pressure_point": (
                    "Semiclassical mean-field evolution ignores stress-tensor fluctuations. "
                    "Treating fluctuations as noise yields growing metric variance; when SNR<1, "
                    "mean-field predictivity is lost."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_Var_h_over_samples": finite_or_none(max_var),
                    "first_time_SNR_below_1": finite_or_none(first_snr_below_1) if first_snr_below_1 is not None else None,
                }
            },
        }

    def export_json(self, t_values: List[float], dt_var: float, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_values=t_values, dt_var=dt_var)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 069: semiclassical gravity noise-driven instability proxy.")
    ap.add_argument("--omega0", type=float, default=1.0, help="Natural frequency")
    ap.add_argument("--gamma", type=float, default=0.05, help="Damping")
    ap.add_argument("--kappa", type=float, default=1.0, help="Coupling to stress tensor")
    ap.add_argument("--T_mean", type=float, default=1.0, help="Mean stress tensor forcing")
    ap.add_argument("--sigma", type=float, default=0.5, help="Noise amplitude (std)")
    ap.add_argument("--tau_c", type=float, default=0.5, help="Noise correlation time")
    ap.add_argument("--t", type=str, default="0,0.5,1,1.5,2,3,4,5,6,8,10", help="Comma-separated times")
    ap.add_argument("--dt_var", type=float, default=0.05, help="Time step for variance quadrature")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy069SemiclassicalGravityNoiseInstability(
        omega0=float(args.omega0),
        gamma=float(args.gamma),
        kappa=float(args.kappa),
        T_mean=float(args.T_mean),
        sigma=float(args.sigma),
        tau_c=float(args.tau_c),
    )
    t_values = parse_csv_floats(args.t)

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, dt_var=float(args.dt_var), out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
