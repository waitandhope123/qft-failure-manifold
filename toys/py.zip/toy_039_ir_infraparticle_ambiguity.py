#!/usr/bin/env python3
"""
Toy 039 — IR divergence and dressing ambiguity (infraparticles)

Pressure point:
- Charged states in QFT (with massless fields) are not Fock particles.
- Infrared divergences prevent sharp particle states.
- Physical states require soft dressing, which is not unique.

GR parallel:
- Long-range fields never fully decouple
- Asymptotic structure contaminates local definitions

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Charged scalar coupled to massless field (proxy)
- Track particle overlap vs IR cutoff
- Independent diagnostic: dressing-dependent norm loss

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy039InfraparticleAmbiguity:
    toy_id = "039"

    def __init__(
        self,
        *,
        ir_cutoffs: List[float] = [1.0, 0.5, 0.2, 0.1],
        charge: float = 1.0,
    ) -> None:
        self.eps = [float(e) for e in ir_cutoffs]
        self.q = float(charge)

    def particle_overlap(self, eps: float) -> float:
        """
        Overlap between bare Fock particle and physical dressed state.
        Vanishes as IR cutoff → 0.
        """
        return math.exp(-self.q * self.q * math.log(1.0 / eps))

    def dressing_norm(self, eps: float) -> float:
        """
        Dressing-dependent norm proxy.
        """
        return 1.0 - math.exp(-1.0 / eps)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for eps in self.eps:
            overlap = self.particle_overlap(eps)
            norm = self.dressing_norm(eps)

            sample_points.append({
                "coordinates": {
                    "ir_cutoff_epsilon": eps,
                },
                "curvature_invariants": {
                    "massless_field": True,
                },
                "local_observables": {
                    "particle_state_overlap": overlap,
                    "dressing_norm_proxy": norm,
                },
                "causal_structure": {
                    "sharp_particle_state": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski with massless modes",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "ir_cutoffs": self.eps,
                "charge": self.q,
            },
            "notes": {
                "assumptions": [
                    "Massless gauge-like field",
                    "Charged excitation",
                ],
                "pressure_point": (
                    "Infrared divergences destroy sharp particle states. "
                    "Physical states require soft dressing, which is not unique."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "fock_particle_definition": False,
                    "unique_dressing": False,
                },
                "regime_classification": {
                    "finite_ir_cutoff": "approximate_particles",
                    "ir_cutoff_removed": "infraparticle_regime",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy039InfraparticleAmbiguity().export_json()


if __name__ == "__main__":
    main()
