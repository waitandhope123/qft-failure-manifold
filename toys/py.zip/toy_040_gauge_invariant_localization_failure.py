#!/usr/bin/env python3
"""
Toy 040 — Gauge invariance vs local operators (no strictly local charged observables)

Pressure point:
- Gauge-invariant observables carrying charge cannot be strictly local.
- Any charged operator must be nonlocal (dressed) and extend to infinity or a boundary.
- Locality and gauge invariance are in tension.

GR parallel:
- Diffeomorphism invariance vs local observables
- Gravitational dressing and nonlocality

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy040GaugeInvariantLocalizationFailure:
    toy_id = "040"

    def __init__(
        self,
        *,
        dressing_lengths: List[float] = [0.5, 1.0, 2.0, 5.0],
        charge: float = 1.0,
    ) -> None:
        self.Ls = [float(L) for L in dressing_lengths]
        self.q = float(charge)

    def naive_local_operator_valid(self) -> bool:
        """
        Local charged operators are not gauge invariant.
        """
        return False

    def dressed_operator_nonlocality(self, L: float) -> float:
        """
        Proxy for spatial extent of gauge dressing.
        Increases with dressing length.
        """
        return self.q * math.log(1.0 + L)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        local_ok = self.naive_local_operator_valid()

        for L in self.Ls:
            nonlocality = self.dressed_operator_nonlocality(L)

            sample_points.append({
                "coordinates": {
                    "dressing_length": L,
                },
                "curvature_invariants": {
                    "gauge_symmetry": "U(1)",
                },
                "local_observables": {
                    "naive_local_charged_operator_valid": local_ok,
                    "dressed_operator_nonlocality_proxy": nonlocality,
                },
                "causal_structure": {
                    "strict_local_charged_observable": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (gauge theory)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "dressing_lengths": self.Ls,
                "charge": self.q,
            },
            "notes": {
                "assumptions": [
                    "Exact gauge invariance",
                    "Charged excitations require dressing",
                ],
                "pressure_point": (
                    "Gauge invariance forbids strictly local charged observables. "
                    "Physical operators must be nonlocal, with unavoidable dressing."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "local_charged_operator": False,
                    "locality_gauge_compatibility": False,
                },
                "regime_classification": {
                    "short_dressing": "approximately_local",
                    "long_dressing": "manifestly_nonlocal",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy040GaugeInvariantLocalizationFailure().export_json()


if __name__ == "__main__":
    main()
