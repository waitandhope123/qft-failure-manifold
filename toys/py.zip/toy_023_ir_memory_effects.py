#!/usr/bin/env python3
"""
Toy 023 — IR divergences and memory effects (soft modes obstruction)

Pressure point:
- Infrared (soft) modes prevent a clean Fock-space description.
- Scattering states depend on infinitely many soft excitations.
- Memory effects encode global information inaccessible to local operators.

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Massless scalar field in 1+1D (proxy for soft sector)
- Track IR divergence of soft occupation number
- Independent diagnostic: memory observable sensitivity to IR cutoff

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy023IRMemoryEffects:
    toy_id = "023"

    def __init__(
        self,
        *,
        ir_cutoffs: List[float] = [1.0, 0.5, 0.25, 0.125],
        uv_cutoff: float = 20.0,
        dk: float = 0.02,
    ) -> None:
        self.ir = [float(eps) for eps in ir_cutoffs]
        self.Lambda = float(uv_cutoff)
        self.dk = float(dk)

    def soft_occupation_number(self, ir_cutoff: float) -> float:
        """
        N_soft ~ ∫_{ε}^{Λ} dk / k  → log(Λ / ε)
        """
        if ir_cutoff <= 0:
            return float("inf")
        return math.log(self.Lambda / ir_cutoff)

    def memory_effect_proxy(self, ir_cutoff: float) -> float:
        """
        Independent diagnostic:
        memory observable depends logarithmically on IR cutoff.
        """
        return self.soft_occupation_number(ir_cutoff)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for eps in self.ir:
            N = self.soft_occupation_number(eps)
            M = self.memory_effect_proxy(eps)

            sample_points.append({
                "coordinates": {
                    "ir_cutoff_epsilon": eps,
                },
                "curvature_invariants": {
                    "uv_cutoff_Lambda": self.Lambda,
                },
                "local_observables": {
                    "soft_mode_occupation": N,
                    "memory_effect_proxy": M,
                },
                "causal_structure": {
                    "asymptotic_state_well_defined": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D, massless sector)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "ir_cutoffs": self.ir,
                "uv_cutoff_Lambda": self.Lambda,
            },
            "notes": {
                "assumptions": [
                    "Massless scalar field",
                    "Soft sector treated explicitly",
                    "IR cutoff introduced as regulator",
                ],
                "pressure_point": (
                    "Infrared divergences obstruct a clean particle picture. "
                    "Soft modes and memory effects encode global information."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "fock_space_asymptotic_states": False,
                    "ir_finite_scattering": False,
                },
                "regime_classification": {
                    "finite_ir_cutoff": "regulated",
                    "ir_cutoff_to_zero": "divergent",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy023IRMemoryEffects().export_json()


if __name__ == "__main__":
    main()
