#!/usr/bin/env python3
"""
Toy 093 — Inequivalent vacua via Bogoliubov transform (Haag/representation boundary proxy)

What it probes (pressure point):
- In infinite volume / continuum limits, Bogoliubov-related vacua can become orthogonal
  (vanishing overlap), signaling inequivalent Hilbert-space representations.
- This is a concrete, computable proxy for the boundary behind Haag-type obstructions:
  "interacting" and "free" fields cannot always live in the same Fock space.

Model (deterministic, discrete modes):
- Consider N harmonic-oscillator modes labeled by k=1..N with base frequencies ω_k.
- Define a Bogoliubov squeeze parameter r_k that depends on a control strength g and UV cutoff:
    r_k = g / (1 + (k/k0)^2)
  (strongest in IR, suppressed in UV)

- Vacuum overlap between two squeezed vacua (or free vs squeezed) factorizes:
    |⟨0 | 0_g⟩| = ∏_k 1 / sqrt(cosh r_k)
  and log-overlap:
    log |⟨0 | 0_g⟩| = -1/2 ∑_k log(cosh r_k)

- Scan N (volume/cutoff proxy) and g (interaction strength proxy) and show overlap→0 as N grows.

Outputs:
- For each (N, g):
  * overlap magnitude
  * log overlap
  * "inequivalent" flag if overlap < overlap_min

Determinism:
- Fully deterministic; no randomness.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 093
# ----------------------------

class Toy093BogoliubovInequivalentVacuaOverlap:
    toy_id = "093"

    def __init__(
        self,
        *,
        k0: float = 20.0,
        overlap_min: float = 1e-6,
    ) -> None:
        require(k0 > 0.0, "k0 must be > 0.")
        require(overlap_min > 0.0, "overlap_min must be > 0.")
        self.k0 = float(k0)
        self.overlap_min = float(overlap_min)

    def r_k(self, k: int, g: float) -> float:
        x = float(k) / self.k0
        return float(g) / (1.0 + x * x)

    def log_overlap(self, N: int, g: float) -> float:
        # log |<0|0_g>| = -1/2 sum log(cosh r_k)
        s = 0.0
        for k in range(1, N + 1):
            r = self.r_k(k, g)
            s += math.log(math.cosh(r))
        return -0.5 * s

    def overlap(self, N: int, g: float) -> float:
        lo = self.log_overlap(N, g)
        # prevent underflow: cap at exp(-745) ~ 5e-324 for double
        if lo < -740.0:
            return 0.0
        return math.exp(lo)

    def build_payload(self, N_values: List[int], g_values: List[float]) -> Dict[str, Any]:
        require(len(N_values) >= 2, "Need multiple N samples.")
        require(len(g_values) >= 2, "Need multiple g samples.")
        require(all(N >= 1 for N in N_values), "N must be >= 1.")

        sample_points: List[Dict[str, Any]] = []

        # summary: for each g, smallest N where overlap drops below overlap_min
        thresholds: Dict[str, Optional[int]] = {}

        for g in g_values:
            first_N = None
            for N in sorted(N_values):
                ov = self.overlap(N, g)
                if ov < self.overlap_min and first_N is None:
                    first_N = N
            thresholds[str(g)] = first_N

        for N in N_values:
            for g in g_values:
                lo = self.log_overlap(N, g)
                ov = self.overlap(N, g)
                inequivalent = (ov < self.overlap_min)

                sample_points.append({
                    "coordinates": {"N_modes": int(N), "g_strength": float(g)},
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "Fock-space representation proxy; no spacetime curvature.",
                    },
                    "local_observables": {
                        "log_overlap": finite_or_none(lo),
                        "overlap": finite_or_none(ov),
                        "overlap_min_threshold": self.overlap_min,
                        "inequivalent_representation_proxy": inequivalent,
                        "k0_suppression_scale": self.k0,
                    },
                    "causal_structure": {
                        "note": (
                            "As N increases (continuum/volume limit), overlap can vanish for fixed g, "
                            "indicating inequivalent vacua/representations (Haag-type boundary)."
                        ),
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): inequivalent vacua via Bogoliubov overlap collapse",
            "spacetime": "Mode space (Fock representation proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "k0_suppression_scale": self.k0,
                "overlap_min": self.overlap_min,
                "N_samples": N_values,
                "g_samples": g_values,
                "r_k_definition": "r_k = g / (1 + (k/k0)^2)",
                "overlap_definition": "|<0|0_g>| = Π_k 1/sqrt(cosh r_k)",
            },
            "notes": {
                "pressure_point": (
                    "In the continuum/large-volume limit, Bogoliubov-related vacua can become orthogonal, "
                    "signaling inequivalent Hilbert-space representations and the boundary behind Haag-type obstructions."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "first_N_where_overlap_below_threshold_by_g": thresholds,
                }
            },
        }

    def export_json(self, N_values: List[int], g_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(N_values=N_values, g_values=g_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 093: Bogoliubov overlap collapse (inequivalent vacua proxy).")
    ap.add_argument("--k0", type=float, default=20.0, help="Suppression scale for r_k")
    ap.add_argument("--overlap_min", type=float, default=1e-6, help="Threshold for inequivalent flag")
    ap.add_argument("--N", type=str, default="10,25,50,100,200,400,800", help="Comma-separated N samples")
    ap.add_argument("--g", type=str, default="0.1,0.2,0.4,0.8,1.2", help="Comma-separated g samples")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    N_values = parse_csv_ints(args.N)
    g_values = parse_csv_floats(args.g)

    toy = Toy093BogoliubovInequivalentVacuaOverlap(k0=float(args.k0), overlap_min=float(args.overlap_min))
    out_path = args.out.strip() or None
    json_path = toy.export_json(N_values=N_values, g_values=g_values, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
