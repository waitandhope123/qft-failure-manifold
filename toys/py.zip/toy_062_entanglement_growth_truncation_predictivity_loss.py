#!/usr/bin/env python3
"""
Toy 062 — Entanglement growth causes truncation-induced predictivity loss (two-mode Gaussian model)

What it probes (pressure point):
- Even with exact unitary dynamics, entanglement growth between modes causes any
  reduced/truncated description to lose predictivity over time.
- This mirrors GR constraint/backreaction failures: evolution remains well-defined
  only in the full system.
- Here, two coupled harmonic oscillators evolve unitarily; truncating the local
  Fock space induces norm leakage and cutoff-dependent observables.

Model (analytic, controlled):
- Two identical bosonic modes (a,b) with Hamiltonian:
    H = ω(a†a + b†b) + g (a†b† + ab)   (two-mode squeezing)
- Exact evolution from |0,0> generates entanglement with squeezing parameter r(t)=g t.
- Reduced state of mode a has thermal spectrum with mean n̄ = sinh^2 r.

Truncation:
- Keep local Fock states |n> with n<=Nmax for mode a (trace out b exactly).
- Compute retained probability Z, truncated mean occupation, and entropy error.

Determinism:
- Analytic probabilities; no randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


# ----------------------------
# Toy 062
# ----------------------------

class Toy062EntanglementGrowthTruncationPredictivityLoss:
    toy_id = "062"

    def __init__(self, g: float = 0.4) -> None:
        require(g > 0.0, "g must be > 0.")
        self.g = float(g)

    def r_of_t(self, t: float) -> float:
        return self.g * float(t)

    def thermal_prob(self, r: float, n: int) -> float:
        """
        Thermal distribution for reduced single mode of two-mode squeezed vacuum:
          P(n) = (1 - q) q^n ,  q = tanh^2 r
        """
        require(n >= 0, "n must be >= 0")
        if r == 0.0:
            return 1.0 if n == 0 else 0.0
        q = math.tanh(r) ** 2
        return (1.0 - q) * (q ** n)

    def exact_mean_n(self, r: float) -> float:
        return math.sinh(r) ** 2

    def exact_entropy(self, r: float) -> float:
        """
        Von Neumann entropy of thermal bosonic mode with mean n̄:
          S = (n̄+1)ln(n̄+1) - n̄ ln n̄
        """
        nbar = self.exact_mean_n(r)
        if nbar <= 0.0:
            return 0.0
        return (nbar + 1.0) * math.log(nbar + 1.0) - nbar * math.log(nbar)

    def truncation_stats(self, r: float, Nmax: int) -> Dict[str, Any]:
        require(Nmax >= 0, "Nmax must be >= 0")

        Z = 0.0
        n_raw = 0.0
        S_trunc = 0.0

        for n in range(0, Nmax + 1):
            p = self.thermal_prob(r, n)
            Z += p
            n_raw += n * p
            if p > 0.0:
                S_trunc -= p * math.log(p)

        leaked = 1.0 - Z
        n_exact = self.exact_mean_n(r)
        S_exact = self.exact_entropy(r)

        n_cond = None if Z <= 0.0 else (n_raw / Z)

        rel_err_n = None
        if n_exact != 0.0:
            rel_err_n = (n_cond - n_exact) / n_exact if n_cond is not None else None

        rel_err_S = None
        if S_exact != 0.0:
            rel_err_S = (S_trunc - S_exact) / S_exact

        return {
            "retained_probability_Z": finite_or_none(Z),
            "leakage_1_minus_Z": finite_or_none(leaked),
            "mean_occupation_exact": finite_or_none(n_exact),
            "mean_occupation_truncated_conditioned": finite_or_none(n_cond),
            "entropy_exact": finite_or_none(S_exact),
            "entropy_truncated_raw": finite_or_none(S_trunc),
            "relative_error_mean_n": finite_or_none(rel_err_n) if rel_err_n is not None else None,
            "relative_error_entropy": finite_or_none(rel_err_S),
        }

    def build_payload(self, t_values: List[float], Nmax_values: List[int]) -> Dict[str, Any]:
        require(len(t_values) >= 1, "Need t samples.")
        require(len(Nmax_values) >= 1, "Need Nmax samples.")

        sample_points: List[Dict[str, Any]] = []

        for t in t_values:
            r = self.r_of_t(t)
            for Nmax in Nmax_values:
                stats = self.truncation_stats(r=r, Nmax=Nmax)

                sample_points.append({
                    "coordinates": {
                        "t": float(t),
                        "r_entanglement": finite_or_none(r),
                        "Nmax_local_truncation": int(Nmax),
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "QFT toy; no spacetime curvature.",
                    },
                    "local_observables": {
                        "model": {
                            "type": "two_mode_squeezing",
                            "r_of_t": "r(t)=g*t",
                            "g": self.g,
                        },
                        "truncation_effects": {
                            **stats,
                            "interpretation": (
                                "Entanglement growth drives probability outside any finite local truncation. "
                                "Predictivity fails as observables become cutoff-dependent."
                            ),
                        },
                    },
                    "causal_structure": {
                        "note": "Failure is informational/predictive, not causal.",
                    },
                })

        max_leak = max(
            (sp["local_observables"]["truncation_effects"]["leakage_1_minus_Z"] or 0.0)
            for sp in sample_points
        )

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): entanglement growth vs truncation",
            "spacetime": "N/A",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "g": self.g,
                "t_samples": t_values,
                "Nmax_samples": Nmax_values,
            },
            "notes": {
                "pressure_point": (
                    "Entanglement growth alone suffices to destroy predictivity of truncated descriptions. "
                    "Full-system unitarity does not rescue reduced or approximate dynamics."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_leakage_over_grid": finite_or_none(max_leak),
                }
            },
        }

    def export_json(self, t_values: List[float], Nmax_values: List[int], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_values=t_values, Nmax_values=Nmax_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 062: entanglement growth causes truncation-induced predictivity loss.")
    ap.add_argument("--g", type=float, default=0.4, help="Entanglement growth rate g")
    ap.add_argument("--t", type=str, default="0,0.5,1,1.5,2,3,4", help="Comma-separated times")
    ap.add_argument("--Nmax", type=str, default="2,4,8,16,32", help="Comma-separated truncation cutoffs")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy062EntanglementGrowthTruncationPredictivityLoss(g=float(args.g))
    t_values = parse_csv_floats(args.t)
    Nmax_values = parse_csv_ints(args.Nmax)

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, Nmax_values=Nmax_values, out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
