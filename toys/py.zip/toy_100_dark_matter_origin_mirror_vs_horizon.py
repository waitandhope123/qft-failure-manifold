#!/usr/bin/env python3
"""
Toy 100 — Dark matter origin “mirror sector remnants” vs “horizon radiation” (UCSC 2025 ideas, proxy-comparator)

What it probes (pressure point):
- Two speculative, “self-contained” DM origin mechanisms can be stress-tested at the level of:
  * parameter sensitivity (fine-tuning vs broad regions)
  * scaling laws (how relic abundance depends on early-universe knobs)
  * internal consistency proxies (collapse threshold / horizon production suppression)
- This is NOT a literal cosmology code; it is a deterministic boundary-toy that turns the
  article’s qualitative claims into quantitative knobs and outputs a “where does it work” map.

Mechanisms (toy proxies):
(A) Mirror-sector dark-QCD → dense dark baryons → gravitational collapse → Planck-scale remnants
    - Dark confinement scale: Lambda_d
    - Dark baryon mass proxy: mB = Nc * Lambda_d
    - Dark asymmetry proxy: eta_d (sets comoving number density)
    - Collapse threshold modeled by comparing dark-sector energy density to a horizon/Jeans proxy:
        rho_d(T) = eta_d * s(T) * mB
        rho_crit(T) = alpha_c * Mpl^2 / t(T)^2
      with radiation-era t(T) ~ 0.301 Mpl / (sqrt(g*) T^2)
    - Collapse fraction: f_c = sigmoid( log(rho_d/rho_crit) / width )
    - Remnant mass: Mrem = xi * Mpl
    - Relic abundance proxy: Omega_mirror ∝ (eta_d * mB) * f_c  (normalized to a target)

(B) Horizon radiation after inflation (accelerated expansion phase) → gravitational production
    - Production like Gibbons–Hawking thermal:
        n_prod ~ H^3 * exp(-2π m/H)
    - Comoving abundance boosted by duration N (e-fold proxy):
        n_eff ~ n_prod * (1 - exp(-3N))   (saturates for large N)
    - Relic proxy: Omega_horizon ∝ m * n_eff  (normalized to a target)

Outputs:
- A single JSON containing:
  * per-gridpoint diagnostics for both mechanisms
  * “match-to-target” masks and summary fractions
  * a simple “robustness score” = fraction of scanned parameter volume matching target

Determinism:
- Fully deterministic; no randomness.

Usage:
  python toy_100_dark_matter_origin_mirror_vs_horizon.py
  python toy_100_dark_matter_origin_mirror_vs_horizon.py --out toy_100.json
  python toy_100_dark_matter_origin_mirror_vs_horizon.py --mirror_eta 1e-12,1e-10,1e-8 --Lambda_d 1e-3,1e-2,1e-1
  python toy_100_dark_matter_origin_mirror_vs_horizon.py --m_over_H 0.2,0.5,1,2,5 --N 0.5,1,2,4,8

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file unless --out is provided.
- JSON follows the canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)

def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None

def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]

def sigmoid(z: float) -> float:
    # numerically stable-ish
    if z >= 0:
        ez = math.exp(-z)
        return 1.0 / (1.0 + ez)
    ez = math.exp(z)
    return ez / (1.0 + ez)

def clamp01(x: float) -> float:
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x


# ----------------------------
# Toy 100
# ----------------------------

class Toy100DarkMatterOriginMirrorVsHorizon:
    toy_id = "100"

    def __init__(
        self,
        *,
        # universal knobs
        target_log10_Omega: float = 0.0,   # target abundance in arbitrary units (we normalize to 1 => log10=0)
        match_tolerance_dex: float = 0.5,  # within factor 10^tol
        # mirror sector knobs
        Nc: float = 3.0,
        gstar: float = 100.0,
        T_probe: float = 1.0,             # probe temperature scale (arbitrary units)
        alpha_c: float = 0.25,            # collapse threshold coefficient
        collapse_width: float = 0.7,      # softness of collapse sigmoid in log-space
        xi_Mpl: float = 2.0,              # remnant mass in units of Mpl
        # horizon production knobs
        H_ref: float = 1.0,               # reference H (arbitrary units); we scan m/H instead
    ) -> None:
        require(match_tolerance_dex > 0.0, "match_tolerance_dex must be > 0.")
        require(Nc > 0.0, "Nc must be > 0.")
        require(gstar > 0.0, "gstar must be > 0.")
        require(T_probe > 0.0, "T_probe must be > 0.")
        require(alpha_c > 0.0, "alpha_c must be > 0.")
        require(collapse_width > 0.0, "collapse_width must be > 0.")
        require(xi_Mpl > 0.0, "xi_Mpl must be > 0.")
        require(H_ref > 0.0, "H_ref must be > 0.")

        self.target_log10_Omega = float(target_log10_Omega)
        self.match_tolerance_dex = float(match_tolerance_dex)

        self.Nc = float(Nc)
        self.gstar = float(gstar)
        self.T_probe = float(T_probe)
        self.alpha_c = float(alpha_c)
        self.collapse_width = float(collapse_width)
        self.xi_Mpl = float(xi_Mpl)

        self.H_ref = float(H_ref)

        # Natural units proxy (set Mpl=1 for toy)
        self.Mpl = 1.0

    # --- basic thermo proxies ---

    def entropy_density(self, T: float) -> float:
        # s ~ (2π^2/45) g* T^3
        return (2.0 * math.pi**2 / 45.0) * self.gstar * (T**3)

    def time_radiation_era(self, T: float) -> float:
        # t ~ 0.301 Mpl / (sqrt(g*) T^2)
        return 0.301 * self.Mpl / (math.sqrt(self.gstar) * (T**2))

    # --- mechanism A: mirror remnants ---

    def mirror_baryon_mass(self, Lambda_d: float) -> float:
        return self.Nc * float(Lambda_d)

    def mirror_collapse_fraction(self, eta_d: float, Lambda_d: float) -> Dict[str, Any]:
        T = self.T_probe
        mB = self.mirror_baryon_mass(Lambda_d)
        rho_d = float(eta_d) * self.entropy_density(T) * mB

        t = self.time_radiation_era(T)
        rho_crit = self.alpha_c * (self.Mpl**2) / (t**2)

        ratio = rho_d / (rho_crit + 1e-300)
        z = math.log(ratio + 1e-300) / self.collapse_width
        f_c = sigmoid(z)

        return {
            "mB": mB,
            "rho_d": rho_d,
            "rho_crit": rho_crit,
            "rho_ratio": ratio,
            "collapse_fraction": f_c,
        }

    def omega_mirror_proxy(self, eta_d: float, Lambda_d: float) -> Dict[str, Any]:
        # Omega ∝ (eta_d * mB) * f_c * (Mrem/mB)??  We model remnants capturing the mass budget:
        # if collapse happens, energy becomes Mrem per collapsed baryon-lump; scale with xi.
        diag = self.mirror_collapse_fraction(eta_d, Lambda_d)
        mB = diag["mB"]
        f_c = diag["collapse_fraction"]

        Mrem = self.xi_Mpl * self.Mpl
        # Proxy abundance:
        # baseline energy per comoving entropy: eta_d*mB ; if collapses, replace mB with Mrem for fraction f_c
        # => eta_d*( (1-f_c)*mB + f_c*Mrem )
        omega = float(eta_d) * ((1.0 - f_c) * mB + f_c * Mrem)

        return {
            "Omega_proxy": omega,
            "Mrem": Mrem,
            **diag,
        }

    # --- mechanism B: horizon production ---

    def horizon_number_density_proxy(self, m_over_H: float, N: float) -> Dict[str, Any]:
        H = self.H_ref
        m = float(m_over_H) * H

        # n_prod ~ H^3 exp(-2π m/H)
        suppress = math.exp(-2.0 * math.pi * float(m_over_H))
        n_prod = (H**3) * suppress

        # duration factor saturating with N
        dur = 1.0 - math.exp(-3.0 * float(N))
        n_eff = n_prod * dur

        return {
            "H": H,
            "m": m,
            "suppression": suppress,
            "duration_factor": dur,
            "n_eff": n_eff,
        }

    def omega_horizon_proxy(self, m_over_H: float, N: float) -> Dict[str, Any]:
        diag = self.horizon_number_density_proxy(m_over_H, N)
        omega = diag["m"] * diag["n_eff"]
        return {"Omega_proxy": omega, **diag}

    # --- matching / scoring ---

    def match_to_target(self, omega: float) -> Dict[str, Any]:
        # Compare log10 Omega to target
        if omega <= 0.0:
            return {"match": False, "log10_Omega": None, "delta_dex": None}
        logO = math.log10(omega)
        delta = abs(logO - self.target_log10_Omega)
        return {
            "match": (delta <= self.match_tolerance_dex),
            "log10_Omega": logO,
            "delta_dex": delta,
        }

    def build_payload(
        self,
        *,
        mirror_eta_values: List[float],
        mirror_Lambda_values: List[float],
        horizon_m_over_H_values: List[float],
        horizon_N_values: List[float],
    ) -> Dict[str, Any]:
        require(len(mirror_eta_values) >= 2 and len(mirror_Lambda_values) >= 2, "Need mirror grids.")
        require(len(horizon_m_over_H_values) >= 2 and len(horizon_N_values) >= 2, "Need horizon grids.")

        sample_points: List[Dict[str, Any]] = []

        # summaries
        mirror_total = 0
        mirror_match = 0
        horizon_total = 0
        horizon_match = 0

        # Mechanism A grid
        for eta in mirror_eta_values:
            for Lam in mirror_Lambda_values:
                mirror_total += 1
                diag = self.omega_mirror_proxy(eta, Lam)
                mt = self.match_to_target(diag["Omega_proxy"])
                if mt["match"]:
                    mirror_match += 1

                sample_points.append({
                    "coordinates": {
                        "mechanism": "mirror_remnants",
                        "eta_d": float(eta),
                        "Lambda_d": float(Lam),
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "Early-universe density threshold proxy; no spacetime curvature computed.",
                    },
                    "local_observables": {
                        "Omega_proxy": finite_or_none(diag["Omega_proxy"]),
                        "log10_Omega_proxy": finite_or_none(mt["log10_Omega"]),
                        "match_target": mt["match"],
                        "delta_dex": finite_or_none(mt["delta_dex"]),
                        "mB": finite_or_none(diag["mB"]),
                        "Mrem": finite_or_none(diag["Mrem"]),
                        "rho_d": finite_or_none(diag["rho_d"]),
                        "rho_crit": finite_or_none(diag["rho_crit"]),
                        "rho_ratio": finite_or_none(diag["rho_ratio"]),
                        "collapse_fraction": finite_or_none(diag["collapse_fraction"]),
                    },
                    "causal_structure": {
                        "note": "Mirror-sector density vs horizon/Jeans proxy determines collapse fraction into Planck-scale remnants.",
                    },
                })

        # Mechanism B grid
        for x in horizon_m_over_H_values:
            for N in horizon_N_values:
                horizon_total += 1
                diag = self.omega_horizon_proxy(x, N)
                mt = self.match_to_target(diag["Omega_proxy"])
                if mt["match"]:
                    horizon_match += 1

                sample_points.append({
                    "coordinates": {
                        "mechanism": "horizon_radiation",
                        "m_over_H": float(x),
                        "N_duration": float(N),
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "Horizon production proxy (Gibbons–Hawking-like); no curvature computed.",
                    },
                    "local_observables": {
                        "Omega_proxy": finite_or_none(diag["Omega_proxy"]),
                        "log10_Omega_proxy": finite_or_none(mt["log10_Omega"]),
                        "match_target": mt["match"],
                        "delta_dex": finite_or_none(mt["delta_dex"]),
                        "H_ref": finite_or_none(diag["H"]),
                        "m": finite_or_none(diag["m"]),
                        "suppression": finite_or_none(diag["suppression"]),
                        "duration_factor": finite_or_none(diag["duration_factor"]),
                        "n_eff": finite_or_none(diag["n_eff"]),
                    },
                    "causal_structure": {
                        "note": "Horizon thermal suppression exp(-2π m/H) competes with duration; abundance is highly sensitive to m/H.",
                    },
                })

        mirror_frac = None if mirror_total == 0 else mirror_match / mirror_total
        horizon_frac = None if horizon_total == 0 else horizon_match / horizon_total

        # A playful “robustness score”: average of match fractions (higher = broader viable region)
        rob = None
        if mirror_frac is not None and horizon_frac is not None:
            rob = 0.5 * (mirror_frac + horizon_frac)

        return {
            "toy_id": self.toy_id,
            "theory": "Cosmology/QFT (toy): dark matter origin proxy-comparator (mirror remnants vs horizon radiation)",
            "spacetime": "Early-universe parametric proxy space (not a full FRW simulation)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "target_log10_Omega_proxy": self.target_log10_Omega,
                "match_tolerance_dex": self.match_tolerance_dex,
                "mirror": {
                    "Nc": self.Nc,
                    "gstar": self.gstar,
                    "T_probe": self.T_probe,
                    "alpha_collapse_threshold": self.alpha_c,
                    "collapse_width_logspace": self.collapse_width,
                    "xi_Mpl_remnant_mass": self.xi_Mpl,
                    "eta_d_samples": mirror_eta_values,
                    "Lambda_d_samples": mirror_Lambda_values,
                    "notes": "Omega_proxy ~ eta_d*((1-fc)*mB + fc*Mrem) with fc = sigmoid(log(rho_d/rho_crit)/width).",
                },
                "horizon": {
                    "H_ref": self.H_ref,
                    "m_over_H_samples": horizon_m_over_H_values,
                    "N_duration_samples": horizon_N_values,
                    "notes": "Omega_proxy ~ m * (H^3 * exp(-2π m/H)) * (1-exp(-3N)).",
                },
            },
            "notes": {
                "pressure_point": (
                    "Turns qualitative origin mechanisms into quantitative scalings and asks: "
                    "are viable regions broad (robust) or narrow (fine-tuned) under simple consistency proxies?"
                ),
                "warning": (
                    "This is an intentionally stripped-down proxy. It does not model reheating, "
                    "detailed Boltzmann evolution, structure constraints, or observational likelihoods."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "mirror_match_fraction": finite_or_none(mirror_frac) if mirror_frac is not None else None,
                    "horizon_match_fraction": finite_or_none(horizon_frac) if horizon_frac is not None else None,
                    "robustness_score_avg": finite_or_none(rob) if rob is not None else None,
                    "counts": {
                        "mirror_total": mirror_total,
                        "mirror_match": mirror_match,
                        "horizon_total": horizon_total,
                        "horizon_match": horizon_match,
                    },
                }
            },
        }

    def export_json(self, payload: Dict[str, Any], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 100: DM origin proxy-comparator (mirror remnants vs horizon radiation).")
    ap.add_argument("--out", type=str, default="", help="Optional output JSON path")

    ap.add_argument("--target_log10_Omega", type=float, default=0.0, help="Target log10 Omega_proxy (default 0 => Omega=1)")
    ap.add_argument("--tol_dex", type=float, default=0.5, help="Match tolerance in dex (default 0.5 ~ factor 3.16)")

    # mirror grids
    ap.add_argument("--mirror_eta", type=str, default="1e-14,1e-12,1e-10,1e-8",
                    help="Comma-separated eta_d samples")
    ap.add_argument("--Lambda_d", type=str, default="1e-4,1e-3,1e-2,1e-1,1.0",
                    help="Comma-separated Lambda_d samples")

    ap.add_argument("--Nc", type=float, default=3.0)
    ap.add_argument("--gstar", type=float, default=100.0)
    ap.add_argument("--T_probe", type=float, default=1.0)
    ap.add_argument("--alpha_c", type=float, default=0.25)
    ap.add_argument("--collapse_width", type=float, default=0.7)
    ap.add_argument("--xi_Mpl", type=float, default=2.0)

    # horizon grids
    ap.add_argument("--m_over_H", type=str, default="0.1,0.2,0.5,1,2,5,10",
                    help="Comma-separated m/H samples")
    ap.add_argument("--N", type=str, default="0.2,0.5,1,2,4,8",
                    help="Comma-separated duration N samples")
    ap.add_argument("--H_ref", type=float, default=1.0)

    args = ap.parse_args()

    toy = Toy100DarkMatterOriginMirrorVsHorizon(
        target_log10_Omega=float(args.target_log10_Omega),
        match_tolerance_dex=float(args.tol_dex),
        Nc=float(args.Nc),
        gstar=float(args.gstar),
        T_probe=float(args.T_probe),
        alpha_c=float(args.alpha_c),
        collapse_width=float(args.collapse_width),
        xi_Mpl=float(args.xi_Mpl),
        H_ref=float(args.H_ref),
    )

    payload = toy.build_payload(
        mirror_eta_values=parse_csv_floats(args.mirror_eta),
        mirror_Lambda_values=parse_csv_floats(args.Lambda_d),
        horizon_m_over_H_values=parse_csv_floats(args.m_over_H),
        horizon_N_values=parse_csv_floats(args.N),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(payload, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
