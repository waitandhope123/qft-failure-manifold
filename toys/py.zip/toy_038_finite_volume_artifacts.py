#!/usr/bin/env python3
"""
Toy 038 — Finite-volume artifacts (thermodynamic limit non-uniformity)

Pressure point:
- Many QFT statements assume the infinite-volume limit.
- Finite volume can qualitatively change spectra, entanglement, and symmetry behavior.
- The thermodynamic limit is subtle and non-uniform.

GR parallel:
- Finite box vs asymptotically flat spacetime
- Global structure matters even when local physics looks the same

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free scalar field on a circle of length L (proxy)
- Compare mode spacing and vacuum energy density as L increases
- Independent diagnostic: approach (or failure to approach) continuum behavior

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy038FiniteVolumeArtifacts:
    toy_id = "038"

    def __init__(
        self,
        *,
        lengths: List[float] = [5.0, 10.0, 20.0, 50.0],
        mass: float = 1.0,
    ) -> None:
        self.Ls = [float(L) for L in lengths]
        self.m = float(mass)

    def mode_spacing(self, L: float) -> float:
        """
        Δk = 2π / L
        """
        return 2.0 * math.pi / L

    def vacuum_energy_density_proxy(self, L: float) -> float:
        """
        Proxy for vacuum energy density with finite-size corrections.
        Approaches continuum value slowly as L → ∞.
        """
        return -1.0 / L + self.m * self.m

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for L in self.Ls:
            spacing = self.mode_spacing(L)
            rho = self.vacuum_energy_density_proxy(L)

            sample_points.append({
                "coordinates": {
                    "box_length_L": L,
                },
                "curvature_invariants": {
                    "spatial_topology": "circle",
                },
                "local_observables": {
                    "mode_spacing": spacing,
                    "vacuum_energy_density_proxy": rho,
                },
                "causal_structure": {
                    "continuum_limit_reached": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski × S¹ (finite volume)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "lengths": self.Ls,
                "mass": self.m,
            },
            "notes": {
                "assumptions": [
                    "Periodic spatial boundary conditions",
                    "Finite-volume quantization",
                ],
                "pressure_point": (
                    "Finite volume effects can qualitatively alter QFT behavior. "
                    "The thermodynamic limit is subtle and non-uniform."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "infinite_volume_assumption": False,
                    "uniform_limit": False,
                },
                "regime_classification": {
                    "small_L": "discrete_spectrum_dominant",
                    "large_L": "slow_approach_to_continuum",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy038FiniteVolumeArtifacts().export_json()


if __name__ == "__main__":
    main()
