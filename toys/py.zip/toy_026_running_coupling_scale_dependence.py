#!/usr/bin/env python3
"""
Toy 026 — Running coupling vs scale (loss of scale separation)

Pressure point:
- Couplings are not constants; they run with energy scale.
- “Weakly coupled” at one scale does not imply weakly coupled at another.
- Effective descriptions have limited domains of validity.

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Asymptotically free–like running (proxy beta function)
- Track coupling g(μ) across scales
- Independent diagnostic: breakdown of perturbativity threshold

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy026RunningCoupling:
    toy_id = "026"

    def __init__(
        self,
        *,
        g0: float = 0.5,
        mu0: float = 1.0,
        scales_mu: List[float] = [0.5, 1.0, 2.0, 5.0, 10.0],
        beta0: float = 0.2,
        perturbative_threshold: float = 1.0,
    ) -> None:
        self.g0 = float(g0)
        self.mu0 = float(mu0)
        self.mus = [float(mu) for mu in scales_mu]
        self.beta0 = float(beta0)
        self.g_crit = float(perturbative_threshold)

    def running_coupling(self, mu: float) -> float:
        """
        One-loop running (proxy):
        g(μ)^2 = g0^2 / (1 + 2 β0 g0^2 ln(μ/μ0))
        """
        denom = 1.0 + 2.0 * self.beta0 * self.g0 * self.g0 * math.log(mu / self.mu0)
        if denom <= 0.0:
            return float("inf")
        return self.g0 / math.sqrt(denom)

    def perturbative_valid(self, g: float) -> bool:
        return g < self.g_crit

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for mu in self.mus:
            g = self.running_coupling(mu)
            valid = self.perturbative_valid(g)

            sample_points.append({
                "coordinates": {
                    "scale_mu": mu,
                },
                "curvature_invariants": {
                    "reference_scale_mu0": self.mu0,
                },
                "local_observables": {
                    "running_coupling_g": g,
                    "perturbative_regime": valid,
                },
                "causal_structure": {
                    "single_scale_description_valid": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (scale space)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "g0": self.g0,
                "mu0": self.mu0,
                "beta0": self.beta0,
                "scales_mu": self.mus,
                "perturbative_threshold": self.g_crit,
            },
            "notes": {
                "assumptions": [
                    "One-loop beta function proxy",
                    "Single coupling",
                    "Logarithmic running captured",
                ],
                "pressure_point": (
                    "Coupling strength depends on scale. "
                    "Effective field theories have bounded domains of validity."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "scale_independent_coupling": False,
                    "global_perturbativity": False,
                },
                "regime_classification": {
                    "low_scale": "weakly_coupled",
                    "high_scale": "strong_coupling_or_breakdown",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy026RunningCoupling().export_json()


if __name__ == "__main__":
    main()
