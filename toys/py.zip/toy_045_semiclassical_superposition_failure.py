#!/usr/bin/env python3
"""
Toy 045 — Superposition of semiclassical geometries (state-dependent expectation clash)

Pressure point:
- Expectation values used as “classical sources” are state-dependent.
- Superpositions of states do not correspond to superpositions of classical sources.
- Semiclassical reasoning breaks under coherent superposition.

Model:
- Single quantum degree of freedom with two energy eigenstates.
- Define an operator O whose expectation value is interpreted as a classical source.
- Compare:
    ⟨O⟩(superposition) vs weighted average of ⟨O⟩(eigenstates).

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


class Toy045SemiclassicalSuperpositionFailure:
    toy_id = "045"

    def __init__(
        self,
        *,
        delta: float = 2.0,
    ) -> None:
        require(delta > 0.0, "delta > 0")
        self.delta = float(delta)

        # Two-level system
        self.H = np.array([[0.0, 0.0], [0.0, self.delta]])
        self.O = np.array([[1.0, 0.0], [0.0, -1.0]])  # "source" operator

    def expectation(self, psi: np.ndarray) -> float:
        return float(np.real(np.vdot(psi, self.O @ psi)))

    def build_payload(self) -> Dict[str, Any]:
        # eigenstates
        e0 = np.array([1.0, 0.0], dtype=complex)
        e1 = np.array([0.0, 1.0], dtype=complex)

        # superposition
        psi = (e0 + e1) / math.sqrt(2.0)

        exp_e0 = self.expectation(e0)
        exp_e1 = self.expectation(e1)
        exp_sup = self.expectation(psi)

        classical_mix = 0.5 * exp_e0 + 0.5 * exp_e1

        sample_points = [{
            "coordinates": {"state": "comparison"},
            "curvature_invariants": {
                "analogy": None
            },
            "local_observables": {
                "expectation_eigenstate_0": exp_e0,
                "expectation_eigenstate_1": exp_e1,
                "expectation_superposition": exp_sup,
                "expectation_classical_mixture": classical_mix,
                "interference_term": exp_sup - classical_mix,
            },
            "causal_structure": {
                "note": "Superpositions do not source classical fields linearly"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (semiclassical source proxy)",
            "spacetime": "Two-level system",
            "units": {"hbar": 1},
            "parameters": {
                "energy_gap": self.delta,
            },
            "notes": {
                "pressure_point": (
                    "Expectation values in superposition states do not correspond "
                    "to classical mixtures. Semiclassical sourcing fails for coherent states."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "interference_term": sample_points[0]["local_observables"]["interference_term"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy045SemiclassicalSuperpositionFailure()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
