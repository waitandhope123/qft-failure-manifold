#!/usr/bin/env python3
"""
Toy 033 — Non-commuting limits (UV removal vs long-time evolution)

Pressure point:
- Limits in QFT do not generally commute.
- Removing regulators before taking long-time limits can change results.
- Physical conclusions depend on the order of idealizations.

GR parallel:
- Taking late-time limits before removing cutoffs
- Order-of-limits issues near horizons and singularities

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free scalar field mode (proxy)
- Compare two procedures:
    (A) Remove UV cutoff, then evolve long time
    (B) Evolve long time, then remove UV cutoff
- Track observable difference

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy033NonCommutingLimits:
    toy_id = "033"

    def __init__(
        self,
        *,
        uv_cutoffs: List[float] = [5.0, 10.0, 20.0],
        times: List[float] = [1.0, 5.0, 10.0, 20.0],
    ) -> None:
        self.Ls = [float(L) for L in uv_cutoffs]
        self.ts = [float(t) for t in times]

    def observable_with_cutoff(self, Lambda: float, t: float) -> float:
        """
        Proxy observable depending on cutoff and time.
        """
        return math.exp(-t / Lambda)

    def limit_order_A(self, t: float) -> float:
        """
        Remove cutoff first (Λ → ∞), then evolve.
        """
        return math.exp(-t / 1e6)

    def limit_order_B(self, Lambda: float) -> float:
        """
        Evolve first, then remove cutoff.
        """
        return self.observable_with_cutoff(Lambda, t=20.0)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for L in self.Ls:
            for t in self.ts:
                obs = self.observable_with_cutoff(L, t)
                A = self.limit_order_A(t)
                B = self.limit_order_B(L)

                sample_points.append({
                    "coordinates": {
                        "uv_cutoff_Lambda": L,
                        "time_t": t,
                    },
                    "curvature_invariants": {
                        "limit_order": "ambiguous",
                    },
                    "local_observables": {
                        "observable_direct": obs,
                        "limit_A_remove_cutoff_first": A,
                        "limit_B_long_time_first": B,
                    },
                    "causal_structure": {
                        "limit_order_independent": False,
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Abstract mode evolution",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "uv_cutoffs": self.Ls,
                "times": self.ts,
            },
            "notes": {
                "assumptions": [
                    "Free scalar mode",
                    "UV cutoff required",
                    "Long-time evolution considered",
                ],
                "pressure_point": (
                    "Taking limits in different orders yields different physical answers. "
                    "Idealizations in QFT are not interchangeable."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "commuting_limits": False,
                    "unique_idealization": False,
                },
                "regime_classification": {
                    "finite_cutoff_finite_time": "well_defined",
                    "idealized_limits": "order_dependent",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy033NonCommutingLimits().export_json()


if __name__ == "__main__":
    main()
