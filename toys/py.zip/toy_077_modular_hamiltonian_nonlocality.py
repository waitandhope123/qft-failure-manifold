#!/usr/bin/env python3
"""
Toy 077 — Modular Hamiltonian is generically nonlocal (local thermality failure proxy)

What it probes (pressure point):
- Reduced states in QFT are thermal with respect to the modular Hamiltonian K_A:
    ρ_A ∝ exp(-K_A)
- Except in special cases (Rindler wedge / CFT interval), K_A is highly nonlocal.
- This undermines naive "local temperature / local Gibbs state" intuition and mirrors GR
  observer-dependent thermality and entanglement wedges.

Model (controlled, deterministic):
- Free fermion chain (1D tight-binding) ground state is Gaussian.
- For a region A, the reduced density matrix is fully determined by the correlation matrix C_A.
- The modular Hamiltonian for Gaussian fermions is quadratic:
    K_A = Σ_{ij in A} h_{ij} c_i^† c_j
  where h = log((I - C_A) / C_A).
- Locality diagnostic: compare weight on near-diagonal vs far-off-diagonal entries of h.

Diagnostics:
- For a block A of size nA in a chain of size N:
  * compute h_{ij}
  * compute fraction of |h_{ij}| weight at distance d=|i-j|:
      w(d) = Σ_{|i-j|=d} |h_{ij}|
  * report nonlocality measures:
      - tail_fraction = Σ_{d>d0} w(d) / Σ_{d>=0} w(d)
      - mean_distance = Σ d w(d) / Σ w(d)

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 077
# ----------------------------

class Toy077ModularHamiltonianNonlocality:
    toy_id = "077"

    def __init__(self, *, N: int = 200, nA: int = 50, mu: float = 0.0) -> None:
        require(N >= 20, "N must be >= 20.")
        require(2 <= nA < N, "Need 2 <= nA < N.")
        self.N = int(N)
        self.nA = int(nA)
        self.mu = float(mu)

    def correlation_matrix_ground_state(self) -> np.ndarray:
        """
        Free fermion chain with periodic boundary conditions:
          H = - Σ (c_i^† c_{i+1} + h.c.) - μ Σ n_i
        Single-particle energies: ε_k = -2 cos(k) - μ
        Fill ε_k < 0 (T=0).
        Compute C_{ij} = <c_i^† c_j> from occupied modes.
        """
        N = self.N
        ks = 2.0 * math.pi * np.arange(N) / N
        eps = -2.0 * np.cos(ks) - self.mu
        occ = (eps < 0.0).astype(float)

        # C_{ij} = (1/N) Σ_k occ_k e^{ik(i-j)}
        idx = np.arange(N)
        diff = (idx[:, None] - idx[None, :]) % N
        # Fourier coefficients c[d] = (1/N) Σ_k occ_k e^{ik d}
        c_d = np.fft.ifft(occ).astype(complex)  # yields c[d] for d=0..N-1 with 1/N factor built-in
        C = c_d[diff]
        return C.real  # should be real-symmetric in this model

    def modular_hamiltonian_matrix(self, CA: np.ndarray) -> np.ndarray:
        """
        For Gaussian fermions:
          h = log((I - C_A) / C_A)
        Compute in eigenbasis of C_A.
        """
        # diagonalize C_A
        w, U = np.linalg.eigh(CA)
        # clamp eigenvalues to (0,1)
        w = np.clip(w, 1e-12, 1.0 - 1e-12)
        hw = np.log((1.0 - w) / w)
        h = (U * hw) @ U.T
        # symmetrize
        return 0.5 * (h + h.T)

    def nonlocality_profile(self, h: np.ndarray) -> Dict[str, Any]:
        nA = h.shape[0]
        w_by_d = [0.0 for _ in range(nA)]
        total = 0.0
        for i in range(nA):
            for j in range(nA):
                d = abs(i - j)
                val = abs(float(h[i, j]))
                w_by_d[d] += val
                total += val

        if total == 0.0:
            return {
                "total_abs_weight": 0.0,
                "tail_fraction_d_gt_2": None,
                "mean_distance": None,
                "w_by_distance": w_by_d,
            }

        d0 = 2  # "local" window
        tail = sum(w_by_d[d] for d in range(d0 + 1, nA)) / total
        mean_d = sum(d * w_by_d[d] for d in range(nA)) / total

        return {
            "total_abs_weight": finite_or_none(total),
            "tail_fraction_d_gt_2": finite_or_none(tail),
            "mean_distance": finite_or_none(mean_d),
            "w_by_distance": [finite_or_none(x) for x in w_by_d],
            "locality_cutoff_d0": d0,
        }

    def build_payload(self) -> Dict[str, Any]:
        C = self.correlation_matrix_ground_state()
        CA = C[: self.nA, : self.nA]
        h = self.modular_hamiltonian_matrix(CA)
        prof = self.nonlocality_profile(h)

        sample_points: List[Dict[str, Any]] = []

        # Provide a few representative entries of h as "samples"
        # (diagonal, nearest-neighbor, far)
        def hij(i: int, j: int) -> float:
            return float(h[i, j])

        pairs = [
            (0, 0),
            (0, 1),
            (0, 2),
            (0, min(10, self.nA - 1)),
            (0, self.nA - 1),
            (self.nA // 2, self.nA // 2 + 1 if self.nA // 2 + 1 < self.nA else self.nA // 2),
        ]

        for (i, j) in pairs:
            sample_points.append({
                "coordinates": {"i": int(i), "j": int(j), "distance": int(abs(i - j))},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "h_ij": finite_or_none(hij(i, j)),
                    "abs_h_ij": finite_or_none(abs(hij(i, j))),
                },
                "causal_structure": {
                    "note": "Nonlocal modular couplings reflect entanglement structure, not signal propagation.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): modular Hamiltonian nonlocality (Gaussian fermions)",
            "spacetime": "1D lattice regulator",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "N_total": self.N,
                "nA_region": self.nA,
                "mu_chemical_potential": self.mu,
            },
            "notes": {
                "pressure_point": (
                    "Reduced states are thermal with respect to the modular Hamiltonian K_A, "
                    "but K_A is generically nonlocal. This defeats naive local-Gibbs intuition "
                    "and highlights that entanglement thermality is not equivalent to local temperature."
                ),
                "formula": "h = log((I - C_A)/C_A) for Gaussian fermions, with K_A = Σ_{ij} h_{ij} c_i† c_j",
            },
            "sample_points": sample_points,
            "observables": {
                "nonlocality_profile": prof,
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 077: modular Hamiltonian nonlocality in free fermion chain.")
    ap.add_argument("--N", type=int, default=200, help="Total chain size")
    ap.add_argument("--nA", type=int, default=50, help="Subsystem size")
    ap.add_argument("--mu", type=float, default=0.0, help="Chemical potential")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy077ModularHamiltonianNonlocality(N=int(args.N), nA=int(args.nA), mu=float(args.mu))
    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
