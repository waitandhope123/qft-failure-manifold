#!/usr/bin/env python3
"""
Toy 043 — Loschmidt echo (instability under Hamiltonian perturbations)

Pressure point:
- QFT (and QM) dynamics are extremely sensitive to small changes in the Hamiltonian.
- Even when two Hamiltonians differ infinitesimally, evolved states can rapidly become
  operationally orthogonal.
- There is no invariant notion of “the same dynamics” beyond exact specification.

Model:
- Finite-dimensional quantum system (spin chain proxy).
- Evolve the same initial state with two nearly identical Hamiltonians.
- Measure Loschmidt echo:
      L(t) = |⟨ψ(t)|ψ_ε(t)⟩|²

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


class Toy043LoschmidtEcho:
    toy_id = "043"

    def __init__(
        self,
        *,
        omega: float = 1.0,
        epsilon: float = 1e-2,
        dt: float = 0.05,
        steps: int = 300,
    ) -> None:
        require(omega > 0.0, "omega>0")
        require(dt > 0.0 and steps >= 1, "dt>0, steps>=1")

        self.omega = float(omega)
        self.epsilon = float(epsilon)
        self.dt = float(dt)
        self.steps = int(steps)

        # Pauli matrices
        sx = np.array([[0, 1], [1, 0]], dtype=complex)
        sz = np.array([[1, 0], [0, -1]], dtype=complex)

        # Base Hamiltonian
        self.H = self.omega * sz

        # Slightly perturbed Hamiltonian
        self.H_eps = self.omega * sz + self.epsilon * sx

    def evolve(self) -> List[Dict[str, Any]]:
        # initial superposition state
        psi0 = np.array([1.0, 1.0], dtype=complex)
        psi0 /= np.linalg.norm(psi0)

        psi = psi0.copy()
        psi_eps = psi0.copy()

        sample_points: List[Dict[str, Any]] = []

        for step in range(self.steps + 1):
            t = step * self.dt

            overlap = abs(np.vdot(psi, psi_eps)) ** 2

            sample_points.append({
                "coordinates": {"t": t},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "loschmidt_echo": overlap,
                    "fidelity_decay": 1.0 - overlap,
                },
                "causal_structure": {
                    "note": "Exponential sensitivity to Hamiltonian perturbations"
                },
            })

            if step < self.steps:
                U = np.eye(2) - 1j * self.H * self.dt
                Ue = np.eye(2) - 1j * self.H_eps * self.dt
                psi = U @ psi
                psi_eps = Ue @ psi_eps
                psi /= np.linalg.norm(psi)
                psi_eps /= np.linalg.norm(psi_eps)

        return sample_points

    def build_payload(self) -> Dict[str, Any]:
        sps = self.evolve()
        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (dynamical sensitivity proxy)",
            "spacetime": "Two-level system",
            "units": {"hbar": 1},
            "parameters": {
                "omega": self.omega,
                "epsilon": self.epsilon,
                "dt": self.dt,
                "steps": self.steps,
            },
            "notes": {
                "pressure_point": (
                    "Infinitesimal changes in the Hamiltonian can produce "
                    "macroscopically distinct evolved states. "
                    "Dynamics are not structurally stable."
                ),
                "diagnostic": "Loschmidt echo / fidelity decay",
            },
            "sample_points": sps,
            "observables": {
                "summary": {
                    "final_echo": sps[-1]["local_observables"]["loschmidt_echo"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy043LoschmidtEcho()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
