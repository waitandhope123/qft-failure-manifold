#!/usr/bin/env python3
"""
Toy 024 — Finite-time Unruh detector ambiguity (thermality as an asymptotic limit)

Pressure point:
- The Unruh effect is not an instantaneous or sharply defined phenomenon.
- Finite-time detectors do not see an exact thermal spectrum.
- Thermality emerges only asymptotically in detector runtime.

This mirrors GR horizon behavior:
- Horizons are defined asymptotically
- Finite observers see only approximations

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Unruh–DeWitt detector in flat spacetime
- Uniform acceleration
- Compare detector response for increasing interaction times τ_max
- Diagnose convergence toward thermal detailed balance

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy024FiniteTimeUnruh:
    toy_id = "024"

    def __init__(
        self,
        *,
        gap: float = 1.0,
        acceleration: float = 1.0,
        tau_max_values: List[float] = [2.0, 4.0, 6.0, 10.0],
    ) -> None:
        self.Omega = float(gap)
        self.a = float(acceleration)
        self.taus = [float(t) for t in tau_max_values]

    def unruh_temperature(self) -> float:
        if self.a == 0.0:
            return 0.0
        return self.a / (2.0 * math.pi)

    def response_proxy(self, tau_max: float) -> float:
        """
        Proxy for detector excitation probability.
        Finite-time response approaches thermal rate exponentially slowly.
        """
        if self.a == 0.0:
            return 0.0
        T = self.unruh_temperature()
        thermal_rate = 1.0 / (math.exp(self.Omega / T) - 1.0)
        return thermal_rate * (1.0 - math.exp(-tau_max / (1.0 / self.a)))

    def detailed_balance_ratio(self, tau_max: float) -> float:
        """
        Independent diagnostic:
        Ratio of excitation to de-excitation probabilities.
        Approaches exp(-Ω / T) asymptotically.
        """
        if self.a == 0.0:
            return 0.0
        T = self.unruh_temperature()
        target = math.exp(-self.Omega / T)
        return target * (1.0 - math.exp(-tau_max * self.a))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for tau in self.taus:
            resp = self.response_proxy(tau)
            ratio = self.detailed_balance_ratio(tau)

            sample_points.append({
                "coordinates": {
                    "tau_max": tau,
                },
                "curvature_invariants": {
                    "acceleration": self.a,
                },
                "local_observables": {
                    "excitation_probability_proxy": resp,
                    "detailed_balance_ratio": ratio,
                },
                "causal_structure": {
                    "exact_thermality": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (accelerated observer)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "gap": self.Omega,
                "acceleration": self.a,
                "tau_max_values": self.taus,
            },
            "notes": {
                "assumptions": [
                    "Unruh–DeWitt detector",
                    "Uniform acceleration",
                    "Finite-time interaction",
                ],
                "pressure_point": (
                    "The Unruh effect is asymptotic in detector runtime. "
                    "Finite-time detectors do not observe exact thermality."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "instantaneous_thermality": False,
                    "observer_independent_particles": False,
                },
                "regime_classification": {
                    "tau_less_than_1_over_a": "nonthermal",
                    "tau_approx_1_over_a": "transient",
                    "tau_much_greater_than_1_over_a": "quasi_thermal",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy024FiniteTimeUnruh().export_json()


if __name__ == "__main__":
    main()
