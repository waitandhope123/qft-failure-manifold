#!/usr/bin/env python3
"""
Toy 071 — Analytic continuation is ill-posed (Euclidean -> real-time / spectral inversion proxy)

What it probes (pressure point):
- Many QFT predictions are computed in Euclidean signature (imaginary time) and then analytically
  continued to real time. Operationally, this often reduces to inverting a Laplace transform:
      G_E(t) = ∫_0^∞ dω  ρ(ω) e^{-ω t}
- Recovering ρ(ω) from finitely sampled G_E(t) is ill-posed: many distinct ρ produce nearly
  identical Euclidean correlators on a finite grid, but imply very different real-time behavior.

Model (controlled, deterministic):
- Choose a "true" nonnegative spectral density ρ_true(ω) as a sum of Gaussians on ω>=0.
- Generate Euclidean correlator samples G_E(t_i) via quadrature on an ω grid.
- Reconstruct ρ via Tikhonov regularized least squares with two different λ values:
      ρ_λ = argmin ||K ρ - G||^2 + λ ||ρ||^2
  where K_{i,j} = e^{-ω_j t_i} Δω.
- Even when K ρ_λ matches G very well for a range of λ, the reconstructed ρ_λ can differ strongly.

Diagnostics:
- Condition number of K^T K (proxy for ill-posedness severity).
- Fit residuals ||Kρ-G|| and pairwise differences between reconstructions.
- Impact on real-time correlator proxy:
      G_R(t) ~ ∫ dω ρ(ω) sin(ω t)    (simplified; shows sensitivity to high-ω structure)

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def gaussian(omega: np.ndarray, mu: float, sig: float) -> np.ndarray:
    return np.exp(-0.5 * ((omega - mu) / sig) ** 2) / (sig * math.sqrt(2.0 * math.pi))


# ----------------------------
# Toy 071
# ----------------------------

class Toy071AnalyticContinuationIllPosedness:
    toy_id = "071"

    def __init__(
        self,
        *,
        omega_max: float = 20.0,
        n_omega: int = 400,
        t_min: float = 0.05,
        t_max: float = 2.0,
        n_t: int = 30,
    ) -> None:
        require(omega_max > 0.0, "omega_max must be > 0.")
        require(n_omega >= 50, "n_omega must be >= 50.")
        require(t_min > 0.0 and t_max > t_min, "Require 0 < t_min < t_max.")
        require(n_t >= 10, "n_t must be >= 10.")
        self.omega_max = float(omega_max)
        self.n_omega = int(n_omega)
        self.t_min = float(t_min)
        self.t_max = float(t_max)
        self.n_t = int(n_t)

        self.omega = np.linspace(0.0, self.omega_max, self.n_omega)
        self.domega = self.omega[1] - self.omega[0]
        self.t = np.linspace(self.t_min, self.t_max, self.n_t)

    def rho_true(self) -> np.ndarray:
        # Nonnegative "true" spectral density: mixture of Gaussians (normalized to unit area roughly)
        rho = (
            0.75 * gaussian(self.omega, mu=2.5, sig=0.35) +
            0.20 * gaussian(self.omega, mu=6.0, sig=0.55) +
            0.05 * gaussian(self.omega, mu=12.0, sig=1.10)
        )
        # Ensure ω>=0 only (already), and keep strictly nonnegative
        return np.maximum(rho, 0.0)

    def build_kernel(self) -> np.ndarray:
        # K_{i,j} = e^{-ω_j t_i} Δω
        # Shape: (n_t, n_omega)
        return np.exp(-np.outer(self.t, self.omega)) * self.domega

    def euclidean_correlator(self, rho: np.ndarray, K: np.ndarray) -> np.ndarray:
        return K @ rho

    def tikhonov_solve(self, K: np.ndarray, G: np.ndarray, lam: float) -> np.ndarray:
        require(lam >= 0.0, "lam must be >= 0.")
        # Solve (K^T K + lam I) rho = K^T G
        KT = K.T
        A = KT @ K
        b = KT @ G
        A_reg = A + lam * np.eye(A.shape[0])
        rho = np.linalg.solve(A_reg, b)
        return rho

    def real_time_proxy(self, rho: np.ndarray, t_rt: np.ndarray) -> np.ndarray:
        # Simple sensitivity diagnostic (not a full retarded correlator):
        # G_rt(t) = ∫ dω ρ(ω) sin(ω t)
        # computed by quadrature
        sin_mat = np.sin(np.outer(t_rt, self.omega)) * self.domega
        return sin_mat @ rho

    def build_payload(self, lambdas: List[float], t_rt_values: List[float]) -> Dict[str, Any]:
        require(len(lambdas) >= 2, "Provide at least two lambda values.")
        require(all(l >= 0.0 for l in lambdas), "All lambdas must be >= 0.")
        require(len(t_rt_values) >= 3, "Provide at least three real-time proxy sample points.")
        require(all(t >= 0.0 for t in t_rt_values), "All real-time proxy t must be >= 0.")

        rho0 = self.rho_true()
        K = self.build_kernel()
        G = self.euclidean_correlator(rho0, K)

        # Ill-posedness severity: cond(K^T K)
        A = K.T @ K
        # Use SVD-based condition estimate (stable)
        s = np.linalg.svd(A, compute_uv=False)
        cond_A = float(s[0] / s[-1]) if s[-1] > 0 else float("inf")

        # Reconstructions
        rhos: Dict[str, np.ndarray] = {}
        fits: Dict[str, Dict[str, float]] = {}
        for lam in lambdas:
            rho_lam = self.tikhonov_solve(K, G, lam=lam)
            rhos[str(lam)] = rho_lam
            resid = K @ rho_lam - G
            fits[str(lam)] = {
                "lambda": float(lam),
                "residual_L2": float(np.linalg.norm(resid)),
                "rho_norm_L2": float(np.linalg.norm(rho_lam)),
                "min_rho": float(np.min(rho_lam)),
                "max_rho": float(np.max(rho_lam)),
            }

        # Pairwise differences (show non-uniqueness)
        # Compare first two lambdas for simplicity
        lam_a = float(lambdas[0])
        lam_b = float(lambdas[1])
        ra = rhos[str(lam_a)]
        rb = rhos[str(lam_b)]

        rho_diff_L2 = float(np.linalg.norm(ra - rb))
        rho_true_vs_a = float(np.linalg.norm(rho0 - ra))
        rho_true_vs_b = float(np.linalg.norm(rho0 - rb))

        # Euclidean fit differences on the sampled grid
        Ga = K @ ra
        Gb = K @ rb
        euclid_diff_L2 = float(np.linalg.norm(Ga - Gb))
        euclid_true_err_a = float(np.linalg.norm(Ga - G))
        euclid_true_err_b = float(np.linalg.norm(Gb - G))

        # Real-time proxy sensitivity
        t_rt = np.array(t_rt_values, dtype=float)
        Grt_true = self.real_time_proxy(rho0, t_rt)
        Grt_a = self.real_time_proxy(ra, t_rt)
        Grt_b = self.real_time_proxy(rb, t_rt)

        # Sample points: Euclidean time samples
        sample_points: List[Dict[str, Any]] = []
        for i, ti in enumerate(self.t.tolist()):
            entry = {
                "coordinates": {"t_euclidean": float(ti)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "G_E_true": finite_or_none(float(G[i])),
                    f"G_E_recon_lambda_{lam_a}": finite_or_none(float(Ga[i])),
                    f"G_E_recon_lambda_{lam_b}": finite_or_none(float(Gb[i])),
                    "abs_diff_recons": finite_or_none(float(abs(Ga[i] - Gb[i]))),
                },
                "causal_structure": {
                    "note": "Analytic continuation/spectral inversion is ill-posed; Euclidean data underdetermines real-time behavior.",
                },
            }
            sample_points.append(entry)

        # Add real-time proxy samples as extra entries (still under sample_points schema)
        # Use a second block identified by coordinate key
        for j, tj in enumerate(t_rt.tolist()):
            sample_points.append({
                "coordinates": {"t_real_time_proxy": float(tj)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "G_rt_proxy_true": finite_or_none(float(Grt_true[j])),
                    f"G_rt_proxy_lambda_{lam_a}": finite_or_none(float(Grt_a[j])),
                    f"G_rt_proxy_lambda_{lam_b}": finite_or_none(float(Grt_b[j])),
                    "abs_diff_recons": finite_or_none(float(abs(Grt_a[j] - Grt_b[j]))),
                },
                "causal_structure": {
                    "note": "Real-time proxy highlights amplified sensitivity to spectral reconstruction choices.",
                },
            })

        # Store compact spectral snapshots (downsample to keep JSON reasonable)
        stride = max(1, self.n_omega // 120)
        omega_ds = self.omega[::stride]
        rho_true_ds = rho0[::stride]
        rho_a_ds = ra[::stride]
        rho_b_ds = rb[::stride]

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): analytic continuation / spectral inversion ill-posedness",
            "spacetime": "Euclidean correlator sampling (imaginary time) with real-time proxy",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "omega_grid": {"omega_max": self.omega_max, "n_omega": self.n_omega},
                "t_euclidean_grid": {"t_min": self.t_min, "t_max": self.t_max, "n_t": self.n_t},
                "lambdas": lambdas,
                "t_real_time_proxy": t_rt_values,
                "rho_true_components": [
                    {"weight": 0.75, "mu": 2.5, "sigma": 0.35},
                    {"weight": 0.20, "mu": 6.0, "sigma": 0.55},
                    {"weight": 0.05, "mu": 12.0, "sigma": 1.10},
                ],
            },
            "notes": {
                "pressure_point": (
                    "Finite Euclidean data underdetermines spectral density; analytic continuation is ill-posed. "
                    "Regularization choices (λ) can yield near-identical Euclidean fits but significantly different spectra "
                    "and real-time proxies."
                ),
                "key_formulas": {
                    "euclidean": "G_E(t)=∫_0^∞ dω ρ(ω) e^{-ω t}",
                    "tikhonov": "ρ_λ = argmin ||Kρ-G||^2 + λ||ρ||^2",
                    "real_time_proxy": "G_rt(t)≈∫ dω ρ(ω) sin(ω t)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "ill_posedness": {
                    "cond_KtK": finite_or_none(cond_A) if math.isfinite(cond_A) else None,
                    "note": "Large condition number indicates severe ill-posedness."
                },
                "fits": fits,
                "comparisons": {
                    "lambda_a": lam_a,
                    "lambda_b": lam_b,
                    "rho_diff_L2_between_recons": finite_or_none(rho_diff_L2),
                    "rho_true_minus_a_L2": finite_or_none(rho_true_vs_a),
                    "rho_true_minus_b_L2": finite_or_none(rho_true_vs_b),
                    "euclidean_diff_L2_between_recons": finite_or_none(euclid_diff_L2),
                    "euclidean_fit_error_L2_a": finite_or_none(euclid_true_err_a),
                    "euclidean_fit_error_L2_b": finite_or_none(euclid_true_err_b),
                },
                "spectral_snapshots_downsampled": {
                    "omega": omega_ds.tolist(),
                    "rho_true": rho_true_ds.tolist(),
                    f"rho_lambda_{lam_a}": rho_a_ds.tolist(),
                    f"rho_lambda_{lam_b}": rho_b_ds.tolist(),
                    "note": "Downsampled spectra (may include small negative regions due to unconstrained linear inversion).",
                },
            },
        }
        return payload

    def export_json(self, lambdas: List[float], t_rt_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(lambdas=lambdas, t_rt_values=t_rt_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 071: analytic continuation / spectral inversion ill-posedness proxy.")
    ap.add_argument("--omega_max", type=float, default=20.0, help="Max omega for quadrature grid")
    ap.add_argument("--n_omega", type=int, default=400, help="Number of omega points")
    ap.add_argument("--t_min", type=float, default=0.05, help="Min Euclidean time sample")
    ap.add_argument("--t_max", type=float, default=2.0, help="Max Euclidean time sample")
    ap.add_argument("--n_t", type=int, default=30, help="Number of Euclidean time samples")
    ap.add_argument("--lambdas", type=str, default="1e-8,1e-3,1e-1",
                    help="Comma-separated Tikhonov lambdas (>=0). First two are compared prominently.")
    ap.add_argument("--t_rt", type=str, default="0,0.25,0.5,0.75,1.0,1.5,2.0,3.0",
                    help="Comma-separated real-time proxy sample points (>=0)")
    ap.add_argument("--out", type=str, default="", help="Optional output path; default is <script>.json")
    args = ap.parse_args()

    toy = Toy071AnalyticContinuationIllPosedness(
        omega_max=float(args.omega_max),
        n_omega=int(args.n_omega),
        t_min=float(args.t_min),
        t_max=float(args.t_max),
        n_t=int(args.n_t),
    )
    lambdas = parse_csv_floats(args.lambdas)
    t_rt = parse_csv_floats(args.t_rt)

    out_path = args.out.strip() or None
    json_path = toy.export_json(lambdas=lambdas, t_rt_values=t_rt, out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
