#!/usr/bin/env python3
"""
Toy 060 — Canonical vs path-integral mismatch (discretization / measure proxy)

Pressure point:
- “Same theory” computed in different formalisms can disagree unless measure,
  discretization, and normalization are specified.
- The path integral is not a single object; choices of measure and regulator
  matter.
- Formal equivalence hides operational dependence.

Model:
- 1D quantum harmonic oscillator partition function Z(β).
- Compare:
    (A) canonical exact Z_can = 1/(2 sinh(β ω / 2))
    (B) Euclidean path-integral discrete approximation with N slices
- Report relative error vs N.

Units: ℏ = k_B = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


class Toy060CanonicalVsPathIntegral:
    toy_id = "060"

    def __init__(
        self,
        *,
        omega: float = 1.0,
        beta: float = 2.0,
        Nslices: List[int] | None = None,
    ) -> None:
        require(omega > 0.0, "omega>0")
        require(beta > 0.0, "beta>0")
        self.omega = float(omega)
        self.beta = float(beta)
        self.Nslices = Nslices or [5, 10, 20, 50, 100, 200]

    def Z_canonical(self) -> float:
        return 1.0 / (2.0 * math.sinh(self.beta * self.omega / 2.0))

    def Z_path_integral_discrete(self, N: int) -> float:
        """
        Very coarse discretization proxy:
        For harmonic oscillator, discrete approximation error ~ O(1/N^2).
        We model this by:
            Z_N = Z_exact * (1 + c/N^2)
        This keeps the toy minimal while capturing the dependence on discretization.
        """
        Z = self.Z_canonical()
        c = 1.0
        return Z * (1.0 + c / (N * N))

    def build_payload(self) -> Dict[str, Any]:
        Z_exact = self.Z_canonical()
        sample_points = []

        for N in self.Nslices:
            ZN = self.Z_path_integral_discrete(int(N))
            rel_err = (ZN - Z_exact) / Z_exact if Z_exact != 0.0 else None

            sample_points.append({
                "coordinates": {"N_slices": int(N)},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "Z_canonical": Z_exact,
                    "Z_path_integral_discrete": ZN,
                    "relative_error": rel_err,
                },
                "causal_structure": {
                    "note": "Formalism equivalence depends on discretization/measure"
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (formalism dependence proxy)",
            "spacetime": "Euclidean time circle",
            "units": {"hbar": 1, "kB": 1},
            "parameters": {
                "omega": self.omega,
                "beta": self.beta,
                "N_slices": self.Nslices,
            },
            "notes": {
                "pressure_point": (
                    "Canonical and path-integral computations agree only once discretization "
                    "and measure choices are fixed. Operational outputs can depend on the chosen formalism."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "Z_canonical": Z_exact,
                    "max_abs_relative_error": max(
                        abs(sp["local_observables"]["relative_error"])
                        for sp in sample_points
                        if sp["local_observables"]["relative_error"] is not None
                    ),
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy060CanonicalVsPathIntegral()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
