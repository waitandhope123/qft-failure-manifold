#!/usr/bin/env python3
"""
Toy 037 — Failure of global time evolution (no preferred Hamiltonian)

Pressure point:
- QFT does not provide a unique, preferred Hamiltonian globally.
- Time evolution depends on the choice of time slicing.
- “The Hamiltonian” is not an invariant object.

GR parallel:
- No preferred global time in curved spacetime
- Hamiltonian constraint vs true evolution

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free scalar field (mode-space proxy)
- Two inequivalent choices of time generator
- Compare energy spectra and vacuum stability

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy037NoPreferredHamiltonian:
    toy_id = "037"

    def __init__(
        self,
        *,
        frequencies: List[float] = [0.5, 1.0, 2.0, 5.0],
        slicing_parameter: float = 1.0,
    ) -> None:
        self.ws = [float(w) for w in frequencies]
        self.alpha = float(slicing_parameter)

    # --- Two inequivalent generators ---

    def energy_standard(self, w: float) -> float:
        """
        Standard inertial Hamiltonian.
        """
        return w

    def energy_alternative(self, w: float) -> float:
        """
        Alternative time slicing generator.
        """
        return self.alpha * w * w

    def vacuum_stable(self, energies: List[float]) -> bool:
        """
        Vacuum stability proxy:
        bounded-below spectrum required.
        """
        return all(e >= 0.0 for e in energies)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        energies_std = [self.energy_standard(w) for w in self.ws]
        energies_alt = [self.energy_alternative(w) for w in self.ws]

        stable_std = self.vacuum_stable(energies_std)
        stable_alt = self.vacuum_stable(energies_alt)

        for i, w in enumerate(self.ws):
            sample_points.append({
                "coordinates": {
                    "mode_frequency": w,
                },
                "curvature_invariants": {
                    "time_slicing": "choice_dependent",
                },
                "local_observables": {
                    "energy_standard_hamiltonian": energies_std[i],
                    "energy_alternative_hamiltonian": energies_alt[i],
                },
                "causal_structure": {
                    "unique_time_evolution": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (mode-space time choices)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "frequencies": self.ws,
                "slicing_parameter": self.alpha,
            },
            "notes": {
                "assumptions": [
                    "Free scalar field",
                    "Multiple admissible time generators",
                ],
                "pressure_point": (
                    "There is no unique, preferred Hamiltonian in QFT. "
                    "Time evolution depends on the choice of time slicing."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "preferred_hamiltonian": False,
                    "unique_time_evolution": False,
                },
                "regime_classification": {
                    "standard_time": "stable_vacuum",
                    "alternative_time": (
                        "stable" if stable_alt else "potential_instability"
                    ),
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy037NoPreferredHamiltonian().export_json()


if __name__ == "__main__":
    main()
