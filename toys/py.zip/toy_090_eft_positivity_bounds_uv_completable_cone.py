#!/usr/bin/env python3
"""
Toy 090 — EFT breakdown & positivity/UV-completability proxy (dispersion/positivity cone)

What it probes (pressure point):
- Not every EFT coefficient choice is compatible with a unitary, analytic, causal UV completion.
- Positivity bounds (dispersion relations) carve out a constrained cone in Wilson-coefficient space.
- Even if low-energy amplitudes look perturbatively fine, UV-completability can already fail.

Model (controlled, deterministic):
- Forward 2→2 scattering EFT proxy with low-energy expansion:
    A(s, t=0) = a2 * s^2 + a3 * s^3 + a4 * s^4
  (shifted so lower terms vanish; typical of EFT after subtractions)

- Positivity/analyticity proxy constraints (toy):
    a2 >= 0
    a4 >= 0
    and "curvature" constraint: a3^2 <= kappa * a2 * a4
  where kappa sets how tight the UV-completability cone is.

- EFT breakdown proxy at energy scale E:
    |a3| E^3 / (a2 E^2) = |a3| E / a2      (relative size of next term)
    |a4| E^4 / (a2 E^2) = |a4| E^2 / a2
  We define E_EFT as the smallest E where either ratio exceeds r_max.

Outputs:
- Grid scan over (a2, a3, a4). For each point:
  * positivity_ok flag
  * estimated EFT breakdown scale E_EFT
  * partial-wave unitarity proxy at E_EFT: |A(E_EFT)| <= u_max

Determinism:
- Fully deterministic; no randomness.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def linspace(a: float, b: float, n: int) -> List[float]:
    require(n >= 2, "linspace requires n>=2")
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


# ----------------------------
# Toy 090
# ----------------------------

class Toy090EFTPositivityBoundsUVCompletableCone:
    toy_id = "090"

    def __init__(
        self,
        *,
        kappa: float = 4.0,
        r_max: float = 0.5,
        u_max: float = 1.0,
        E_max: float = 10.0,
    ) -> None:
        require(kappa > 0.0, "kappa must be > 0.")
        require(r_max > 0.0, "r_max must be > 0.")
        require(u_max > 0.0, "u_max must be > 0.")
        require(E_max > 0.0, "E_max must be > 0.")
        self.kappa = float(kappa)
        self.r_max = float(r_max)
        self.u_max = float(u_max)
        self.E_max = float(E_max)

    def amplitude(self, E: float, a2: float, a3: float, a4: float) -> float:
        s = E * E
        return a2 * (s ** 2) + a3 * (s ** 3) + a4 * (s ** 4)

    def positivity_ok(self, a2: float, a3: float, a4: float) -> bool:
        if a2 < 0.0 or a4 < 0.0:
            return False
        # cone/curvature bound
        return (a3 * a3) <= (self.kappa * a2 * a4 + 1e-30)

    def eft_breakdown_scale(self, a2: float, a3: float, a4: float) -> Optional[float]:
        """
        Smallest E where either:
          |a3| E / a2 > r_max   or   |a4| E^2 / a2 > r_max
        If a2<=0, undefined. If never within E_max, return None.
        """
        if a2 <= 0.0:
            return None

        # E from cubic ratio
        E3 = None
        if a3 != 0.0:
            E3 = (self.r_max * a2) / abs(a3)

        # E from quartic ratio
        E4 = None
        if a4 > 0.0:
            E4 = math.sqrt((self.r_max * a2) / a4)

        candidates = [x for x in [E3, E4] if x is not None and x > 0.0]
        if not candidates:
            return None

        E = min(candidates)
        if E > self.E_max:
            return None
        return E

    def unitarity_ok_at(self, E: float, a2: float, a3: float, a4: float) -> Optional[bool]:
        if E is None:
            return None
        A = abs(self.amplitude(E, a2, a3, a4))
        return A <= self.u_max

    def build_payload(
        self,
        a2_values: List[float],
        a3_values: List[float],
        a4_values: List[float],
    ) -> Dict[str, Any]:
        require(len(a2_values) >= 2 and len(a3_values) >= 2 and len(a4_values) >= 2, "Need grid samples.")
        sample_points: List[Dict[str, Any]] = []

        n_total = 0
        n_pos = 0
        n_pos_and_unitary = 0
        n_pos_and_has_Eeft = 0

        for a2 in a2_values:
            for a3 in a3_values:
                for a4 in a4_values:
                    n_total += 1
                    pos_ok = self.positivity_ok(a2, a3, a4)
                    if pos_ok:
                        n_pos += 1

                    Eeft = self.eft_breakdown_scale(a2, a3, a4)
                    if pos_ok and Eeft is not None:
                        n_pos_and_has_Eeft += 1

                    unit_ok = None
                    if Eeft is not None:
                        unit_ok = self.unitarity_ok_at(Eeft, a2, a3, a4)

                    if pos_ok and unit_ok is True:
                        n_pos_and_unitary += 1

                    # diagnostics at Eeft (if defined)
                    A_at = None
                    if Eeft is not None:
                        A_at = abs(self.amplitude(Eeft, a2, a3, a4))

                    sample_points.append({
                        "coordinates": {"a2": float(a2), "a3": float(a3), "a4": float(a4)},
                        "curvature_invariants": {
                            "ricci_scalar": None,
                            "kretschmann": None,
                            "note": "Scattering/EFT coefficient space; no spacetime curvature.",
                        },
                        "local_observables": {
                            "positivity_ok": pos_ok,
                            "cone_constraint": {
                                "a2_nonnegative": (a2 >= 0.0),
                                "a4_nonnegative": (a4 >= 0.0),
                                "a3_squared": finite_or_none(a3 * a3),
                                "kappa_a2_a4": finite_or_none(self.kappa * a2 * a4),
                                "a3_squared_le_kappa_a2_a4": (a3 * a3 <= self.kappa * a2 * a4 + 1e-30),
                            },
                            "E_EFT_breakdown": finite_or_none(Eeft) if Eeft is not None else None,
                            "amplitude_abs_at_EEFT": finite_or_none(A_at) if A_at is not None else None,
                            "unitarity_proxy_ok_at_EEFT": unit_ok,
                            "thresholds": {
                                "r_max": self.r_max,
                                "u_max": self.u_max,
                                "E_max": self.E_max,
                            },
                        },
                        "causal_structure": {
                            "note": (
                                "Positivity/analyticity bounds restrict EFT coefficients; "
                                "EFT breakdown can occur before any naive inconsistency, "
                                "and UV-completability is a stronger constraint than perturbative control."
                            ),
                        },
                    })

        frac = lambda k: None if n_total == 0 else (k / n_total)

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): positivity bounds / UV-completability cone for EFT coefficients",
            "spacetime": "Coefficient space (forward scattering EFT proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "kappa_cone": self.kappa,
                "r_max_eft_breakdown_ratio": self.r_max,
                "u_max_unitarity_proxy": self.u_max,
                "E_max_scan": self.E_max,
                "a2_samples": a2_values,
                "a3_samples": a3_values,
                "a4_samples": a4_values,
            },
            "notes": {
                "pressure_point": (
                    "UV consistency (analyticity/causality/unitarity) imposes positivity bounds on EFT coefficients. "
                    "Many apparently sensible EFTs are not UV-completable; the allowed region is a constrained cone."
                ),
                "toy_constraints": {
                    "positivity": "a2>=0, a4>=0",
                    "cone": "a3^2 <= kappa * a2 * a4",
                    "eft_breakdown": "E_EFT = min_E where |a3|E/a2>r_max or a4 E^2/a2>r_max",
                    "unitarity_proxy": "|A(E_EFT)| <= u_max",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_total": n_total,
                    "n_positivity_ok": n_pos,
                    "n_positivity_ok_and_has_EEFT": n_pos_and_has_Eeft,
                    "n_positivity_ok_and_unitarity_ok_at_EEFT": n_pos_and_unitary,
                    "fractions": {
                        "positivity_ok": finite_or_none(frac(n_pos)),
                        "positivity_ok_and_has_EEFT": finite_or_none(frac(n_pos_and_has_Eeft)),
                        "positivity_ok_and_unitarity_ok_at_EEFT": finite_or_none(frac(n_pos_and_unitary)),
                    },
                }
            },
        }

    def export_json(self, payload: Dict[str, Any], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 090: positivity bounds / UV-completability cone (EFT proxy).")
    ap.add_argument("--kappa", type=float, default=4.0, help="Cone tightness parameter kappa>0")
    ap.add_argument("--r_max", type=float, default=0.5, help="EFT breakdown ratio threshold")
    ap.add_argument("--u_max", type=float, default=1.0, help="Unitarity proxy threshold")
    ap.add_argument("--E_max", type=float, default=10.0, help="Maximum energy scale to report")
    ap.add_argument("--a2", type=str, default="0.0,0.25,0.5,0.75,1.0", help="Comma-separated a2 samples")
    ap.add_argument("--a3", type=str, default="-1.0,-0.5,0.0,0.5,1.0", help="Comma-separated a3 samples")
    ap.add_argument("--a4", type=str, default="0.0,0.25,0.5,0.75,1.0", help="Comma-separated a4 samples")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy090EFTPositivityBoundsUVCompletableCone(
        kappa=float(args.kappa),
        r_max=float(args.r_max),
        u_max=float(args.u_max),
        E_max=float(args.E_max),
    )

    a2_values = [float(x.strip()) for x in args.a2.split(",") if x.strip()]
    a3_values = [float(x.strip()) for x in args.a3.split(",") if x.strip()]
    a4_values = [float(x.strip()) for x in args.a4.split(",") if x.strip()]

    payload = toy.build_payload(a2_values=a2_values, a3_values=a3_values, a4_values=a4_values)
    out_path = args.out.strip() or None
    json_path = toy.export_json(payload, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
