#!/usr/bin/env python3
"""
Toy 047 — Failure of instantaneous ground state (time-dependent Hamiltonian)

Pressure point:
- In QFT with time-dependent backgrounds or couplings, there is no well-defined
  instantaneous vacuum or ground state.
- Adiabatic intuition fails when the notion of energy itself is time-dependent.

Model:
- Single harmonic oscillator with time-dependent frequency ω(t).
- Track instantaneous ground energy vs actual state energy.
- Show particle production / excitation even under slow variation.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


class Toy047NoInstantaneousVacuum:
    toy_id = "047"

    def __init__(
        self,
        *,
        omega0: float = 1.0,
        epsilon: float = 0.5,
        dt: float = 0.05,
        steps: int = 300,
    ) -> None:
        require(omega0 > 0.0, "omega0 > 0")
        require(dt > 0.0 and steps >= 1, "dt>0, steps>=1")

        self.omega0 = float(omega0)
        self.epsilon = float(epsilon)
        self.dt = float(dt)
        self.steps = int(steps)

    def omega(self, t: float) -> float:
        return self.omega0 * (1.0 + self.epsilon * math.sin(t))

    def evolve(self) -> List[Dict[str, Any]]:
        # start in ground state of omega0
        n = 0.0  # occupation number proxy
        sample_points: List[Dict[str, Any]] = []

        for step in range(self.steps + 1):
            t = step * self.dt
            w = self.omega(t)

            # instantaneous ground energy
            E0 = 0.5 * w

            # actual energy proxy
            E = (n + 0.5) * w

            sample_points.append({
                "coordinates": {"t": t},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "instantaneous_ground_energy": E0,
                    "state_energy": E,
                    "excitation_above_ground": E - E0,
                },
                "causal_structure": {
                    "note": "No invariant instantaneous vacuum"
                },
            })

            # crude particle production proxy
            if step < self.steps:
                n += (self.epsilon * self.dt * abs(math.cos(t))) ** 2

        return sample_points

    def build_payload(self) -> Dict[str, Any]:
        sps = self.evolve()
        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (time-dependent background proxy)",
            "spacetime": "Time-dependent harmonic oscillator",
            "units": {"hbar": 1},
            "parameters": {
                "omega0": self.omega0,
                "epsilon": self.epsilon,
                "dt": self.dt,
                "steps": self.steps,
            },
            "notes": {
                "pressure_point": (
                    "In time-dependent systems there is no invariant instantaneous "
                    "ground state. Particle content and energy are observer- and history-dependent."
                ),
            },
            "sample_points": sps,
            "observables": {
                "summary": {
                    "final_excitation": sps[-1]["local_observables"]["excitation_above_ground"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy047NoInstantaneousVacuum()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
