#!/usr/bin/env python3
"""
Toy 086 — Casimir-induced vacuum energy sign ambiguity (compactification proxy)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
"""

from __future__ import annotations

import json, math, os
from typing import Any, Dict, List, Optional

def py_to_json_name(p: str) -> str:
    return os.path.splitext(os.path.basename(p))[0] + ".json"

def finite_or_none(x: Any) -> Optional[float]:
    try:
        x = float(x)
        return x if math.isfinite(x) else None
    except Exception:
        return None

class Toy086CasimirVacuumSignAmbiguity:
    toy_id = "086"

    def casimir_energy(self, L: float, bc: str) -> float:
        # simple 1D Casimir proxy
        if bc == "periodic":
            return -1.0 / L
        if bc == "antiperiodic":
            return +0.5 / L
        return 0.0

    def build_payload(self, L_values: List[float]) -> Dict[str, Any]:
        sample_points = []

        for L in L_values:
            Ep = self.casimir_energy(L, "periodic")
            Ea = self.casimir_energy(L, "antiperiodic")

            sample_points.append({
                "coordinates": {"compact_length": L},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Flat-space Casimir proxy.",
                },
                "local_observables": {
                    "energy_periodic": finite_or_none(Ep),
                    "energy_antiperiodic": finite_or_none(Ea),
                    "sign_flip": (Ep * Ea < 0),
                },
                "causal_structure": {
                    "note": "Vacuum energy sign depends on boundary conditions.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "QFT: Casimir vacuum energy sign ambiguity",
            "spacetime": "Compactified flat space",
            "units": {"G": 1, "c": 1},
            "parameters": {"L_samples": L_values},
            "notes": {
                "pressure_point": "Casimir-like contributions do not have a fixed sign; positivity is not generic.",
            },
            "sample_points": sample_points,
        }

    def export_json(self, L_values: List[float]) -> str:
        out = py_to_json_name(__file__)
        with open(out, "w") as f:
            json.dump(self.build_payload(L_values), f, indent=2, sort_keys=True)
        return out

def main() -> None:
    Ls = [0.5 + 0.1*i for i in range(20)]
    Toy086CasimirVacuumSignAmbiguity().export_json(Ls)
    print("Wrote", py_to_json_name(__file__))

if __name__ == "__main__":
    main()
