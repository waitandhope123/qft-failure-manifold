#!/usr/bin/env python3
"""
Toy 028 — Microcausality vs smearing (lightcone leakage)

Pressure point:
- Exact microcausality holds only for perfectly local operators.
- Any physically realizable (smeared) operator introduces spacelike leakage.
- Causality becomes resolution-dependent, not absolute.

GR parallel:
- Sharp lightcones vs effective causal cones
- Finite-resolution observers see causal blurring

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free scalar field in 1+1D
- Gaussian-smeared field operators
- Compute spacelike commutator leakage as function of smearing width

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy028MicrocausalityLeakage:
    toy_id = "028"

    def __init__(
        self,
        *,
        separation_x: float = 3.0,
        smearings: List[float] = [0.2, 0.5, 1.0, 2.0],
        cutoff: float = 25.0,
        dk: float = 0.05,
    ) -> None:
        self.x = float(separation_x)
        self.sigmas = [float(s) for s in smearings]
        self.Lambda = float(cutoff)
        self.dk = float(dk)

    def spacelike_commutator_leakage(self, sigma: float) -> float:
        """
        Proxy for |[φ_f(x), φ_f(0)]| at spacelike separation.
        Vanishes only in the sharp limit sigma → 0.
        """
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            weight = math.exp(-sigma * sigma * k * k)
            s += math.sin(k * self.x) * weight
            k += self.dk
        return abs(s * self.dk)

    def sharp_limit_commutator(self) -> float:
        """
        Exact microcausality: sharp local operators commute at spacelike separation.
        """
        return 0.0

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        sharp = self.sharp_limit_commutator()

        for sigma in self.sigmas:
            leak = self.spacelike_commutator_leakage(sigma)

            sample_points.append({
                "coordinates": {
                    "separation_x": self.x,
                    "smearing_width_sigma": sigma,
                },
                "curvature_invariants": {
                    "sharp_limit_commutator": sharp,
                },
                "local_observables": {
                    "spacelike_commutator_leakage": leak,
                },
                "causal_structure": {
                    "exact_microcausality": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "separation_x": self.x,
                "smearings": self.sigmas,
                "cutoff_Lambda": self.Lambda,
            },
            "notes": {
                "assumptions": [
                    "Free scalar field",
                    "Gaussian smearing of local operators",
                    "Finite UV cutoff regulator",
                ],
                "pressure_point": (
                    "Exact microcausality applies only to idealized local operators. "
                    "Physical smearing introduces resolution-dependent causal leakage."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "absolute_causal_sharpness": False,
                    "resolution_independent_lightcone": False,
                },
                "regime_classification": {
                    "sigma_to_zero": "exact_microcausality",
                    "finite_sigma": "approximate_causality",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy028MicrocausalityLeakage().export_json()


if __name__ == "__main__":
    main()
