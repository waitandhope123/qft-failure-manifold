#!/usr/bin/env python3
"""
Toy 013 — Vacuum fluctuations vs measurement resolution (operational locality limit)

Pressure point:
- Local field fluctuations diverge as resolution → 0.
- “Local observables” require smearing; pointlike measurements are ill-defined.
- What counts as a measurable quantity depends on detector resolution.

Model:
- Free real scalar field in 1+1D
- Gaussian-smeared field operator φ_f = ∫ dx f_σ(x) φ(x)
- Compute variance ⟨φ_f^2⟩ as function of smearing width σ

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


# ----------------------------
# Toy 013
# ----------------------------

class Toy013SmearingResolution:
    toy_id = "013"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        sigmas: List[float] = [1.0, 0.5, 0.25, 0.125],
        cutoff: float = 30.0,
        dk: float = 0.02,
    ) -> None:
        self.m = float(mass)
        self.sigmas = [float(s) for s in sigmas]
        self.Lambda = float(cutoff)
        self.dk = float(dk)

    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def smeared_variance(self, sigma: float) -> float:
        """
        ⟨φ_f^2⟩ = ∫ dk / (4π ω_k) |f̃_σ(k)|^2
        with f̃_σ(k) = exp(-σ^2 k^2 / 2)
        """
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega(k)
            weight = math.exp(-sigma * sigma * k * k)
            s += weight / (4.0 * math.pi * w)
            k += self.dk
        return s * self.dk

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for sigma in self.sigmas:
            var = self.smeared_variance(sigma)

            sample_points.append({
                "coordinates": {
                    "smearing_width_sigma": sigma,
                },
                "curvature_invariants": {
                    "uv_cutoff_Lambda": self.Lambda,
                },
                "local_observables": {
                    "smeared_field_variance": var,
                    "pointlike_limit_defined": False,
                },
                "causal_structure": {
                    "operational_locality": (
                        "defined_only_for_finite_sigma"
                    ),
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "sigmas": self.sigmas,
                "cutoff_Lambda": self.Lambda,
                "dk": self.dk,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Gaussian smearing of field operator",
                    "Momentum cutoff regulator",
                ],
                "pressure_point": (
                    "Local field fluctuations diverge as measurement resolution improves. "
                    "Strictly local observables do not exist without smearing."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "trend": "Variance grows as smearing width σ → 0."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    Toy013SmearingResolution().export_json()


if __name__ == "__main__":
    main()
