#!/usr/bin/env python3
"""
Toy 067 — Path-integral contour choice & Stokes jumps (0D QFT / Airy-style proxy)

What it probes (pressure point):
- Even in "toy QFT" (0-dimensional field theory), the path integral can be ambiguous:
  different steepest-descent contours (Lefschetz thimbles) give different answers.
- As parameters vary, dominant saddle contributions can switch discontinuously (Stokes phenomenon).
- This is a clean operational mirror of "no preferred vacuum / no preferred Hamiltonian":
  the same formal integral needs extra contour data to become a number.

Model (0D polynomial action):
- Partition function:
    Z(g) = ∫_C dφ exp( - S(φ) ),  S(φ) = (1/2) φ^2 + (g/4) φ^4
- For g > 0, the real-line contour converges and is "canonical".
- For g < 0, the real-line integral diverges; one must choose a complex contour.
  Different admissible contours (rotated lines) produce different values.

Implementation:
- Evaluate Z along straight-line contours φ = e^{iθ} x, x in [-L, L], with L large,
  approximating:
    Z_θ(g) ≈ e^{iθ} ∫_{-L}^{L} dx exp( - (1/2) e^{2iθ} x^2 - (g/4) e^{4iθ} x^4 )
- Choose a set of θ values that are convergent for given g:
  Convergence requires Re(g e^{4iθ}) > 0 (quartic term damped at large |x|).
- Track how Z_θ depends on θ and g; Stokes-like jumps appear when moving between
  different convergent sectors.

Diagnostics:
- For each g and each allowed θ:
  * complex Z_θ (real, imag, abs, arg)
  * sensitivity across θ (spread)
  * "canonical" real-axis result for g>0 as reference

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import cmath
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


def simpson_complex(f, a: float, b: float, n: int) -> complex:
    require(n >= 2 and n % 2 == 0, "n must be even and >=2")
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        x = a + i * h
        s += (4.0 if i % 2 == 1 else 2.0) * f(x)
    return s * (h / 3.0)


# ----------------------------
# Toy 067
# ----------------------------

class Toy067PathIntegralContourChoiceStokesJump:
    toy_id = "067"

    def __init__(self, *, L: float = 10.0, n_int: int = 20000) -> None:
        require(L > 0.0, "L must be > 0.")
        require(n_int >= 200 and n_int % 2 == 0, "n_int must be even and reasonably large.")
        self.L = float(L)
        self.n_int = int(n_int)

    def convergent(self, g: float, theta: float) -> bool:
        # Need Re(g e^{4 i theta}) > 0 for quartic damping at infinity along this ray
        val = (g * cmath.exp(4j * theta)).real
        return val > 0.0

    def Z_theta(self, g: float, theta: float) -> Optional[complex]:
        if not self.convergent(g, theta):
            return None

        eitheta = cmath.exp(1j * theta)
        e2 = cmath.exp(2j * theta)
        e4 = cmath.exp(4j * theta)

        def integrand(x: float) -> complex:
            # φ = e^{iθ} x, dφ = e^{iθ} dx
            # exp( - 1/2 φ^2 - g/4 φ^4 )
            return cmath.exp(-0.5 * e2 * (x * x) - 0.25 * g * e4 * (x ** 4))

        I = simpson_complex(integrand, -self.L, self.L, self.n_int)
        return eitheta * I

    def build_payload(self, g_values: List[float], theta_values: List[float]) -> Dict[str, Any]:
        require(len(g_values) >= 1, "Need g samples.")
        require(len(theta_values) >= 1, "Need theta samples.")

        sample_points: List[Dict[str, Any]] = []

        # For summaries
        max_spread_abs = 0.0

        for g in g_values:
            # compute Z for each theta
            Zs: Dict[str, Optional[complex]] = {}
            abs_vals: List[float] = []
            for th in theta_values:
                Z = self.Z_theta(float(g), float(th))
                Zs[str(th)] = Z
                if Z is not None:
                    abs_vals.append(abs(Z))

            spread_abs = None
            if abs_vals:
                spread_abs = max(abs_vals) - min(abs_vals)
                max_spread_abs = max(max_spread_abs, spread_abs)

            # canonical reference for g>0 on theta=0
            Z_real_axis = self.Z_theta(float(g), 0.0) if g > 0.0 else None

            for th in theta_values:
                Z = Zs[str(th)]
                if Z is None:
                    Z_re = None
                    Z_im = None
                    Z_abs = None
                    Z_arg = None
                    converges = False
                else:
                    Z_re = float(Z.real)
                    Z_im = float(Z.imag)
                    Z_abs = float(abs(Z))
                    Z_arg = float(cmath.phase(Z))
                    converges = True

                # compare to canonical when defined
                rel_to_real = None
                if Z is not None and Z_real_axis is not None and abs(Z_real_axis) > 0.0:
                    rel_to_real = abs(Z - Z_real_axis) / abs(Z_real_axis)

                sample_points.append({
                    "coordinates": {
                        "g": float(g),
                        "theta": float(th),
                        "contour": "phi = exp(i*theta) * x, x in [-L, L]",
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "0D QFT toy; no spacetime curvature.",
                    },
                    "local_observables": {
                        "convergent_for_g_theta": converges,
                        "Z_theta": {
                            "real": finite_or_none(Z_re),
                            "imag": finite_or_none(Z_im),
                            "abs": finite_or_none(Z_abs),
                            "arg": finite_or_none(Z_arg),
                        },
                        "reference_real_axis_Z_for_g_gt_0": {
                            "defined": (Z_real_axis is not None),
                            "real": finite_or_none(float(Z_real_axis.real)) if Z_real_axis is not None else None,
                            "imag": finite_or_none(float(Z_real_axis.imag)) if Z_real_axis is not None else None,
                            "abs": finite_or_none(float(abs(Z_real_axis))) if Z_real_axis is not None else None,
                        },
                        "relative_difference_to_real_axis_reference": finite_or_none(rel_to_real) if rel_to_real is not None else None,
                        "theta_family_abs_spread_for_this_g": finite_or_none(spread_abs) if spread_abs is not None else None,
                    },
                    "causal_structure": {
                        "note": "Contour choice is extra data; without it, the formal path integral is not a number.",
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): 0D path integral + contour ambiguity (Lefschetz/Stokes proxy)",
            "spacetime": "0D (no spacetime), complexified integration contour",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "g_samples": g_values,
                "theta_samples": theta_values,
                "integration": {"L_cutoff": self.L, "n_int_simpson": self.n_int},
                "convergence_condition": "Re(g e^{4 i theta}) > 0",
            },
            "notes": {
                "pressure_point": (
                    "For g<0 the real-line path integral diverges; one must choose a complex contour. "
                    "Different admissible contours produce different Z, and dominance can switch across Stokes lines."
                ),
                "key_formulas": {
                    "Z": "Z(g)=∫_C dφ exp(-(1/2)φ^2-(g/4)φ^4)",
                    "contour": "φ=e^{iθ}x, dφ=e^{iθ}dx",
                    "convergence": "Re(g e^{4 i θ})>0",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_abs_spread_over_theta_families": finite_or_none(max_spread_abs),
                    "note": "Large spread indicates strong contour dependence / Stokes sensitivity.",
                }
            },
        }

    def export_json(self, g_values: List[float], theta_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(g_values=g_values, theta_values=theta_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 067: 0D path-integral contour choice and Stokes-like jumps.")
    ap.add_argument("--g", type=str, default="1.0,0.5,0.2,-0.2,-0.5,-1.0", help="Comma-separated quartic couplings g")
    ap.add_argument("--theta", type=str,
                    default="0.0,0.3926990817,0.7853981634,1.1780972451,1.5707963268,-0.3926990817,-0.7853981634",
                    help="Comma-separated contour angles theta (radians)")
    ap.add_argument("--L", type=float, default=10.0, help="Integration cutoff |x|<=L")
    ap.add_argument("--n_int", type=int, default=20000, help="Even Simpson panel count")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy067PathIntegralContourChoiceStokesJump(L=float(args.L), n_int=int(args.n_int))
    g_values = parse_csv_floats(args.g)
    theta_values = parse_csv_floats(args.theta)

    out_path = args.out.strip() or None
    json_path = toy.export_json(g_values=g_values, theta_values=theta_values, out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
