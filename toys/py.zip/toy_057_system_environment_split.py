#!/usr/bin/env python3
"""
Toy 057 — No invariant split between system and environment

Pressure point:
- In QFT, the division between “system” and “environment” is not invariant.
- Different factorizations of the same Hilbert space lead to different
  reduced dynamics and entanglement structure.
- Open-system behavior depends on how the split is chosen.

Model:
- Three-qubit pure state.
- Compare reduced dynamics when:
    (A) system = A, environment = {B,C}
    (B) system = {A,B}, environment = C
- Show different entropies and interpretations.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import os
import math
import numpy as np
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def von_neumann_entropy(rho: np.ndarray) -> float:
    vals = np.linalg.eigvalsh(rho)
    vals = vals[vals > 1e-12]
    return float(-np.sum(vals * np.log(vals)))


def partial_trace(rho: np.ndarray, keep: List[int], n_qubits: int) -> np.ndarray:
    dims = [2] * n_qubits
    rho = rho.reshape(dims + dims)

    trace_out = sorted(
        [i for i in range(n_qubits) if i not in keep],
        reverse=True
    )

    current_n = n_qubits
    for i in trace_out:
        rho = np.trace(rho, axis1=i, axis2=i + current_n)
        current_n -= 1

    dim = 2 ** len(keep)
    return rho.reshape((dim, dim))


class Toy057SystemEnvironmentSplit:
    toy_id = "057"

    def build_payload(self) -> Dict[str, Any]:
        zero = np.array([1, 0], dtype=complex)
        one = np.array([0, 1], dtype=complex)

        psi = (np.kron(np.kron(zero, zero), zero) +
               np.kron(np.kron(one, one), one)) / math.sqrt(2.0)
        rho = np.outer(psi, psi.conj())

        rho_A = partial_trace(rho, keep=[0], n_qubits=3)
        rho_AB = partial_trace(rho, keep=[0, 1], n_qubits=3)

        S_A = von_neumann_entropy(rho_A)
        S_AB = von_neumann_entropy(rho_AB)

        sample_points = [{
            "coordinates": {"split": "comparison"},
            "curvature_invariants": {"analogy": None},
            "local_observables": {
                "entropy_system_A": S_A,
                "entropy_system_AB": S_AB,
                "difference": S_A - S_AB,
            },
            "causal_structure": {
                "note": "System–environment split is not invariant"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (open-system ambiguity)",
            "spacetime": "Three-qubit system",
            "units": {"hbar": 1},
            "parameters": {},
            "notes": {},
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "split_dependence_gap":
                        sample_points[0]["local_observables"]["difference"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy057SystemEnvironmentSplit()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
