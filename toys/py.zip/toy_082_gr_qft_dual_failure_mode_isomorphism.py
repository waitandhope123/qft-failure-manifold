#!/usr/bin/env python3
"""
Toy 082 — GR–QFT dual failure-mode non-isomorphism (cross-theory comparator)

What it probes (pressure point):
- Tests whether GR-style and QFT-style breakdown diagnostics admit a shared,
  order-preserving or threshold-preserving mapping.
- Uses paired proxy diagnostics driven by a common control parameter and checks
  failure ordering, simultaneity, and correlation.
- Demonstrates absence of a canonical GR↔QFT failure-mode isomorphism.

Determinism:
- Fully deterministic; no randomness.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
- Undefined quantities are exported as null.
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 082
# ----------------------------

class Toy082GRQFTDualFailureModeNonIsomorphism:
    toy_id = "082"

    def __init__(
        self,
        *,
        gr_threshold: float = 0.22,
        qft_threshold: float = 0.17,
        gr_exponent: float = 2.0,
        qft_exponent: float = 1.0,
    ) -> None:
        require(gr_threshold > 0.0, "gr_threshold must be > 0.")
        require(qft_threshold > 0.0, "qft_threshold must be > 0.")
        self.gr_threshold = float(gr_threshold)
        self.qft_threshold = float(qft_threshold)
        self.gr_exponent = float(gr_exponent)
        self.qft_exponent = float(qft_exponent)

    # GR-like diagnostic: constraint / backreaction proxy
    def gr_metric(self, lam: float) -> float:
        return lam ** self.gr_exponent

    # QFT-like diagnostic: unitarity / regulator proxy
    def qft_metric(self, lam: float) -> float:
        return lam ** self.qft_exponent

    def build_payload(self, lambda_values: List[float]) -> Dict[str, Any]:
        require(len(lambda_values) >= 5, "Need multiple lambda samples.")
        require(all(lam >= 0.0 for lam in lambda_values), "lambda must be >= 0.")

        sample_points: List[Dict[str, Any]] = []

        gr_first_fail = None
        qft_first_fail = None

        for lam in lambda_values:
            lam = float(lam)

            gr_val = self.gr_metric(lam)
            qft_val = self.qft_metric(lam)

            gr_fail = gr_val >= self.gr_threshold
            qft_fail = qft_val >= self.qft_threshold

            if gr_fail and gr_first_fail is None:
                gr_first_fail = lam
            if qft_fail and qft_first_fail is None:
                qft_first_fail = lam

            sample_points.append({
                "coordinates": {
                    "lambda": lam,
                },
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Cross-theory comparator; no spacetime curvature.",
                },
                "local_observables": {
                    "gr_metric": finite_or_none(gr_val),
                    "qft_metric": finite_or_none(qft_val),
                    "gr_threshold": self.gr_threshold,
                    "qft_threshold": self.qft_threshold,
                    "gr_failed": gr_fail,
                    "qft_failed": qft_fail,
                },
                "causal_structure": {
                    "note": (
                        "Shared control parameter produces non-aligned GR/QFT failure responses."
                    ),
                },
            })

        ordering = None
        if gr_first_fail is not None and qft_first_fail is not None:
            if gr_first_fail < qft_first_fail:
                ordering = "GR_fails_first"
            elif qft_first_fail < gr_first_fail:
                ordering = "QFT_fails_first"
            else:
                ordering = "simultaneous"

        return {
            "toy_id": self.toy_id,
            "theory": "Cross-theory comparator (GR vs QFT failure diagnostics)",
            "spacetime": "Abstract control-parameter space",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "gr_threshold": self.gr_threshold,
                "qft_threshold": self.qft_threshold,
                "gr_exponent": self.gr_exponent,
                "qft_exponent": self.qft_exponent,
                "lambda_samples": lambda_values,
            },
            "notes": {
                "pressure_point": (
                    "Even when driven by a shared approximation parameter, GR-style and QFT-style "
                    "breakdown diagnostics do not admit a canonical isomorphism: thresholds and "
                    "failure ordering generically disagree."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "gr_first_failure_lambda": finite_or_none(gr_first_fail),
                    "qft_first_failure_lambda": finite_or_none(qft_first_fail),
                    "failure_ordering": ordering,
                    "isomorphic_mapping_exists": False,
                }
            },
        }

    def export_json(self, lambda_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(lambda_values=lambda_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    lambda_values = [i / 200.0 for i in range(0, 201)]

    toy = Toy082GRQFTDualFailureModeNonIsomorphism()
    json_path = toy.export_json(lambda_values=lambda_values)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
