#!/usr/bin/env python3
"""
Toy 014 — Entropy production vs unitarity: coarse-graining in unitary QFT

Pressure point:
- Fundamental QFT evolution is unitary, but coarse-grained observables show entropy increase.
- Irreversibility emerges from tracing out degrees of freedom, not from dynamics.
- Entropy growth depends on how the system/environment split is chosen.

Model:
- Free scalar field modes (1+1D proxy)
- Bipartition into observed vs unobserved momentum modes
- Track von Neumann entropy of reduced density matrix under unitary evolution

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


# ----------------------------
# Toy 014
# ----------------------------

class Toy014CoarseGrainedEntropy:
    toy_id = "014"

    def __init__(
        self,
        *,
        mode_count: int = 20,
        observed_fraction: float = 0.5,
        coupling_eps: float = 0.05,
        times: List[float] = [0.0, 1.0, 2.0, 5.0, 10.0],
    ) -> None:
        self.N = int(mode_count)
        self.f_obs = float(observed_fraction)
        self.eps = float(coupling_eps)
        self.times = [float(t) for t in times]

        self.N_obs = max(1, int(self.f_obs * self.N))

    def reduced_entropy_proxy(self, t: float) -> float:
        """
        Proxy entropy growth:
        S(t) ~ S_max * (1 - exp(-eps * t))
        capturing monotonic entropy increase under coarse-graining.
        """
        S_max = math.log(self.N_obs)
        return S_max * (1.0 - math.exp(-self.eps * t))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for t in self.times:
            S = self.reduced_entropy_proxy(t)

            sample_points.append({
                "coordinates": {
                    "time_t": t,
                },
                "curvature_invariants": {
                    "total_modes": self.N,
                },
                "local_observables": {
                    "reduced_entropy": S,
                    "entropy_monotonic": True,
                },
                "causal_structure": {
                    "global_unitarity_preserved": True,
                    "local_irreversibility": True,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (mode space, coarse-grained)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "total_modes": self.N,
                "observed_modes": self.N_obs,
                "coupling_eps": self.eps,
                "time_samples": self.times,
            },
            "notes": {
                "assumptions": [
                    "Unitary global evolution",
                    "Fixed bipartition into observed/unobserved modes",
                    "Entropy computed after tracing out unobserved modes (proxy)",
                ],
                "pressure_point": (
                    "Entropy increase in QFT is observer- and coarse-graining-dependent. "
                    "Irreversibility is not fundamental but emergent."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "statement": "Local entropy grows despite exact global unitarity."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    Toy014CoarseGrainedEntropy().export_json()


if __name__ == "__main__":
    main()
