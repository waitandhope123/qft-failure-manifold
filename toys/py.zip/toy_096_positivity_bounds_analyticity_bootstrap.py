#!/usr/bin/env python3
"""
Toy 096 — Positivity bounds / analyticity bootstrap (UV-completability boundary)

What it probes (pressure point):
- Forward-limit dispersion/positivity bounds impose sharp constraints on EFT Wilson coefficients.
- Most naive EFT coefficient choices violate positivity and therefore cannot arise from a
  unitary, causal, analytic UV completion.
- Demonstrates how the allowed region is a narrow cone/polytope, not a generic volume.

Model (deterministic, EFT proxy):
- Consider forward elastic scattering with low-energy expansion:
    A(s) = c2 s^2 + c4 s^4 + c6 s^6
  (odd powers removed by crossing/analyticity assumptions).

- Positivity / analyticity bounds (toy but faithful in structure):
    c2 >= 0
    c4 >= 0
    c6 >= 0
    and convexity constraints from twice-subtracted dispersion:
        c4^2 <= beta * c2 * c6
  where beta encodes how strong the UV assumptions are.

- Scan coefficient space and classify:
    * positivity_ok
    * strictly_inside_cone
    * boundary_saturated

Diagnostics:
- Fraction of parameter space allowed
- Which bounds fail first
- Sensitivity to beta (tight vs loose UV assumptions)

Determinism:
- Fully deterministic grid scan.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)

def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None

def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 096
# ----------------------------

class Toy096PositivityBoundsAnalyticityBootstrap:
    toy_id = "096"

    def __init__(self, *, beta: float = 4.0, eps: float = 1e-12) -> None:
        require(beta > 0.0, "beta must be > 0.")
        self.beta = float(beta)
        self.eps = float(eps)

    def positivity_ok(self, c2: float, c4: float, c6: float) -> bool:
        if c2 < 0.0 or c4 < 0.0 or c6 < 0.0:
            return False
        return (c4 * c4) <= (self.beta * c2 * c6 + self.eps)

    def classification(self, c2: float, c4: float, c6: float) -> str:
        if c2 < 0 or c4 < 0 or c6 < 0:
            return "violates_basic_positivity"
        lhs = c4 * c4
        rhs = self.beta * c2 * c6
        if lhs > rhs + self.eps:
            return "violates_dispersion_bound"
        if abs(lhs - rhs) <= self.eps:
            return "boundary_saturated"
        return "strictly_inside_cone"

    def build_payload(
        self,
        c2_values: List[float],
        c4_values: List[float],
        c6_values: List[float],
    ) -> Dict[str, Any]:
        require(len(c2_values) >= 2 and len(c4_values) >= 2 and len(c6_values) >= 2,
                "Need grid samples for c2,c4,c6.")

        sample_points: List[Dict[str, Any]] = []

        n_total = 0
        n_allowed = 0
        n_strict = 0
        n_boundary = 0

        for c2 in c2_values:
            for c4 in c4_values:
                for c6 in c6_values:
                    n_total += 1
                    cls = self.classification(c2, c4, c6)
                    if cls in ("strictly_inside_cone", "boundary_saturated"):
                        n_allowed += 1
                    if cls == "strictly_inside_cone":
                        n_strict += 1
                    if cls == "boundary_saturated":
                        n_boundary += 1

                    sample_points.append({
                        "coordinates": {"c2": float(c2), "c4": float(c4), "c6": float(c6)},
                        "curvature_invariants": {
                            "ricci_scalar": None,
                            "kretschmann": None,
                            "note": "Wilson-coefficient space; no spacetime curvature.",
                        },
                        "local_observables": {
                            "classification": cls,
                            "positivity_basic": (c2 >= 0 and c4 >= 0 and c6 >= 0),
                            "dispersion_lhs": finite_or_none(c4 * c4),
                            "dispersion_rhs": finite_or_none(self.beta * c2 * c6),
                        },
                        "causal_structure": {
                            "note": (
                                "Positivity/analyticity restrict EFT coefficients to a narrow cone. "
                                "Most naive choices violate UV-completability."
                            ),
                        },
                    })

        frac = lambda k: None if n_total == 0 else k / n_total

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): positivity bounds / analyticity bootstrap",
            "spacetime": "EFT coefficient space (forward scattering)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "beta_dispersion_strength": self.beta,
                "c2_samples": c2_values,
                "c4_samples": c4_values,
                "c6_samples": c6_values,
            },
            "notes": {
                "pressure_point": (
                    "Analyticity, causality, and unitarity impose positivity bounds that sharply "
                    "restrict EFT parameter space. UV-completable theories form a narrow cone."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_total": n_total,
                    "n_allowed": n_allowed,
                    "n_strictly_inside": n_strict,
                    "n_boundary_saturated": n_boundary,
                    "fractions": {
                        "allowed": finite_or_none(frac(n_allowed)),
                        "strictly_inside": finite_or_none(frac(n_strict)),
                        "boundary": finite_or_none(frac(n_boundary)),
                    },
                }
            },
        }

    def export_json(self, payload: Dict[str, Any], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 096: positivity bounds / analyticity bootstrap.")
    ap.add_argument("--beta", type=float, default=4.0, help="Dispersion bound strength beta")
    ap.add_argument("--c2", type=str, default="0,0.25,0.5,0.75,1.0", help="Comma-separated c2 samples")
    ap.add_argument("--c4", type=str, default="0,0.25,0.5,0.75,1.0", help="Comma-separated c4 samples")
    ap.add_argument("--c6", type=str, default="0,0.25,0.5,0.75,1.0", help="Comma-separated c6 samples")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy096PositivityBoundsAnalyticityBootstrap(beta=float(args.beta))

    c2_vals = parse_csv_floats(args.c2)
    c4_vals = parse_csv_floats(args.c4)
    c6_vals = parse_csv_floats(args.c6)

    payload = toy.build_payload(c2_vals, c4_vals, c6_vals)
    out_path = args.out.strip() or None
    json_path = toy.export_json(payload, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
