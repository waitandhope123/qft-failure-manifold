#!/usr/bin/env python3
"""
Toy 056 — Gauge fixing affects observables (gauge dependence proxy)

Pressure point:
- In gauge theories, intermediate and even seemingly “physical” quantities
  can depend on the gauge choice.
- Without careful construction, observables inherit gauge artifacts.
- Gauge fixing is not an innocent technical step.

Model:
- Simple U(1)-like gauge proxy with a constrained system.
- Compute a would-be observable under two different gauge fixings.
- Show numerical disagreement despite identical underlying states.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import os
import numpy as np
from typing import Any, Dict


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy056GaugeFixingDependence:
    toy_id = "056"

    def __init__(self) -> None:
        # Two gauge-related representations of the same physical state
        self.state = np.array([1.0, 0.0], dtype=complex)

        # Two "gauges" implemented as unitary rotations
        theta = 0.7
        self.U_gauge_A = np.eye(2)
        self.U_gauge_B = np.array(
            [[np.cos(theta), np.sin(theta)],
             [-np.sin(theta), np.cos(theta)]],
            dtype=complex
        )

        # Naively defined observable (not gauge-invariant)
        self.O = np.array([[1.0, 0.0], [0.0, -1.0]])

    def expectation(self, psi: np.ndarray) -> float:
        return float(np.real(np.vdot(psi, self.O @ psi)))

    def build_payload(self) -> Dict[str, Any]:
        psi_A = self.U_gauge_A @ self.state
        psi_B = self.U_gauge_B @ self.state

        exp_A = self.expectation(psi_A)
        exp_B = self.expectation(psi_B)

        sample_points = [{
            "coordinates": {"gauge": "comparison"},
            "curvature_invariants": {
                "analogy": None
            },
            "local_observables": {
                "expectation_gauge_A": exp_A,
                "expectation_gauge_B": exp_B,
                "difference": exp_A - exp_B,
            },
            "causal_structure": {
                "note": "Observable is gauge-dependent"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (gauge dependence proxy)",
            "spacetime": "Two-level constrained system",
            "units": {"hbar": 1},
            "parameters": {},
            "notes": {
                "pressure_point": (
                    "Gauge fixing choices can contaminate observables unless "
                    "gauge invariance is enforced explicitly."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "gauge_dependence_gap": sample_points[0]["local_observables"]["difference"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy056GaugeFixingDependence()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
