#!/usr/bin/env python3
"""
Toy 004 — Vacuum entanglement entropy of a free scalar field (UV dominance)

Pressure point:
- Entanglement entropy of the vacuum diverges with UV cutoff.
- Area-law behavior is regulator-dominated, not a dynamical observable.
- Entropy is not intrinsic to a region without specifying a cutoff.

Model:
- Free real scalar field in 1+1D
- Lattice discretization with spacing a
- Ground-state covariance matrix
- Entanglement entropy of an interval

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 004
# ----------------------------

class Toy004VacuumEntanglement:
    toy_id = "004"

    def __init__(
        self,
        *,
        N: int = 40,
        mass: float = 1.0,
        lattice_spacings: List[float] = [0.5, 0.25, 0.125],
        region_size: int = 10,
    ) -> None:
        require(N > 2, "N must be > 2")
        require(region_size < N, "region must be smaller than system")

        self.N = int(N)
        self.m = float(mass)
        self.a_values = [float(a) for a in lattice_spacings]
        self.region = int(region_size)

    def build_covariances(self, a: float) -> np.ndarray:
        """
        Lattice Hamiltonian:
        H = 1/2 Σ [π^2 + (φ_{i+1}-φ_i)^2/a^2 + m^2 φ_i^2]
        """
        N = self.N
        K = np.zeros((N, N))
        for i in range(N):
            K[i, i] = (2.0 / a**2) + self.m**2
            if i > 0:
                K[i, i-1] = -1.0 / a**2
            if i < N - 1:
                K[i, i+1] = -1.0 / a**2

        eigvals, eigvecs = np.linalg.eigh(K)
        sqrtK = eigvecs @ np.diag(np.sqrt(eigvals)) @ eigvecs.T
        invsqrtK = eigvecs @ np.diag(1.0 / np.sqrt(eigvals)) @ eigvecs.T

        Cx = 0.5 * invsqrtK
        Cp = 0.5 * sqrtK
        return Cx, Cp

    def entropy(self, Cx: np.ndarray, Cp: np.ndarray) -> float:
        A = slice(0, self.region)
        CxA = Cx[A, A]
        CpA = Cp[A, A]
        M = np.dot(CxA, CpA)

        eigs = np.linalg.eigvalsh(M)
        S = 0.0
        for nu in eigs:
            if nu <= 0.25:
                continue
            x = math.sqrt(nu) + 0.5
            y = math.sqrt(nu) - 0.5
            S += x * math.log(x) - y * math.log(y)
        return S

    def build_payload(self) -> Dict[str, Any]:
        sample_points = []

        for a in self.a_values:
            Cx, Cp = self.build_covariances(a)
            S = self.entropy(Cx, Cp)

            sample_points.append({
                "coordinates": {
                    "lattice_spacing_a": a,
                    "region_size_sites": self.region,
                },
                "curvature_invariants": {
                    "uv_cutoff_1_over_a": 1.0 / a,
                },
                "local_observables": {
                    "entanglement_entropy": S,
                    "entropy_per_site": S / self.region,
                },
                "causal_structure": {
                    "region_boundary_count": 2,
                    "note": "Entropy dominated by short-distance correlations at boundary.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat lattice (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "total_sites": self.N,
                "region_size": self.region,
                "lattice_spacings": self.a_values,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Ground state",
                    "Sharp spatial bipartition",
                ],
                "pressure_point": (
                    "Vacuum entanglement entropy diverges as lattice spacing → 0. "
                    "Area-law behavior reflects UV structure, not dynamical degrees of freedom."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "trend": "Entropy increases monotonically as UV cutoff increases (a → 0)."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy004VacuumEntanglement()
    toy.export_json()


if __name__ == "__main__":
    main()
