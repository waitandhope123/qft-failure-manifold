#!/usr/bin/env python3
"""
Toy 089 — de Sitter construction control diagnostics (Casimir/uplift + stability + EFT control)

What it probes (pressure point):
- Existence vs control: positive vacuum energy can be engineered, but may rely on
  (i) regulator-sensitive vacuum terms, (ii) fine-tuned cancellations, (iii) weak control
  (large curvature vs cutoff), and/or (iv) metastability with short lifetime.
- Provides a compact “audit” of a de Sitter–like construction using only EFT-level ingredients:
  Casimir-like vacuum term + uplift term + stabilizing term over a modulus L.

Model (controlled, deterministic):
- One modulus L > 0 (think compactification scale).
- Vacuum energy density proxy:
    V(L) = V_cas(L) + V_uplift(L) + V_stab(L) + V_ct(L)
  where:
    V_cas(L)  ~ sgn(bc) * A / L^4               (Casimir-like)
    V_uplift  ~ + U0 / L^p                       (uplift-like positive term)
    V_stab    ~ - S0 / L^q                       (stabilizing negative term)
    V_ct      ~ + c0 + c1/L^2                    (counterterms / scheme dependence proxy)
- Control diagnostics:
  * curvature proxy: H^2 ~ V/3  (in units where M_pl=1)
  * cutoff proxy:    Lambda_uv ~ 1/a_uv (user parameter)
  * EFT control:     epsilon = H / Lambda_uv  (should be small)
  * tuning proxy:    T = |V| / (|V_cas|+|V_uplift|+|V_stab|+|V_ct|)
- Stability diagnostics:
  * local minimum: V'(L*)=0 with V''(L*)>0 (numerically via scanning)
  * barrier proxy: if a nearby turning point exists with higher V, define ΔV barrier height
  * lifetime proxy: B ~ (Δphi)^4 / ΔV   (dimensionless heuristic; larger is longer-lived)

Diagnostics:
- Scan L across range; for each parameter set, find:
  * best local minimum candidate (lowest |V'|) and record V(L*), V''(L*), barrier proxy, B
  * whether V(L*)>0 (dS-like), stable, and controlled (epsilon < eps_max, tuning < t_max)
- Produces “good region” stats across a grid of construction parameters.

Determinism:
- No randomness; pure grid scan.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file (toy_089_de_sitter_construction_control_diagnostics.json).
- JSON follows the canonical lab schema with required keys and required subkeys.
- Undefined quantities are exported as null (JSON null).
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_csv_ints(s: str) -> List[int]:
    return [int(x.strip()) for x in s.split(",") if x.strip()]


def safe_div(a: float, b: float) -> Optional[float]:
    if b == 0.0:
        return None
    return a / b


# ----------------------------
# Toy 089
# ----------------------------

class Toy089DeSitterConstructionControlDiagnostics:
    toy_id = "089"

    def __init__(
        self,
        *,
        A: float = 1.0,
        p: float = 2.0,
        q: float = 6.0,
        a_uv: float = 0.05,
        eps_max: float = 0.1,
        tuning_max: float = 0.05,
        deriv_dx_frac: float = 1e-3,
    ) -> None:
        require(A > 0.0, "A must be > 0.")
        require(p > 0.0 and q > 0.0 and q > p, "Require q>p>0 for a typical stabilized shape.")
        require(a_uv > 0.0, "a_uv must be > 0.")
        require(eps_max > 0.0, "eps_max must be > 0.")
        require(tuning_max > 0.0, "tuning_max must be > 0.")
        require(deriv_dx_frac > 0.0, "deriv_dx_frac must be > 0.")
        self.A = float(A)
        self.p = float(p)
        self.q = float(q)
        self.a_uv = float(a_uv)
        self.eps_max = float(eps_max)
        self.tuning_max = float(tuning_max)
        self.deriv_dx_frac = float(deriv_dx_frac)

    # --- Potential pieces ---
    def V_cas(self, L: float, bc_sign: int) -> float:
        # Casimir-like term ~ ±A/L^4
        return float(bc_sign) * self.A / (L ** 4)

    def V_uplift(self, L: float, U0: float) -> float:
        # uplift-like positive term ~ U0 / L^p
        return float(U0) / (L ** self.p)

    def V_stab(self, L: float, S0: float) -> float:
        # stabilizing negative term ~ -S0 / L^q
        return -float(S0) / (L ** self.q)

    def V_ct(self, L: float, c0: float, c1: float) -> float:
        # counterterms / scheme dependence proxy: constant + 1/L^2 term
        return float(c0) + float(c1) / (L ** 2)

    def V_total(self, L: float, bc_sign: int, U0: float, S0: float, c0: float, c1: float) -> float:
        return self.V_cas(L, bc_sign) + self.V_uplift(L, U0) + self.V_stab(L, S0) + self.V_ct(L, c0, c1)

    # --- Numeric derivatives ---
    def dV(self, L: float, bc_sign: int, U0: float, S0: float, c0: float, c1: float) -> Optional[float]:
        if L <= 0.0:
            return None
        h = max(self.deriv_dx_frac * L, 1e-8)
        Lm = max(L - h, 1e-12)
        Lp = L + h
        Vm = self.V_total(Lm, bc_sign, U0, S0, c0, c1)
        Vp = self.V_total(Lp, bc_sign, U0, S0, c0, c1)
        return (Vp - Vm) / (Lp - Lm)

    def d2V(self, L: float, bc_sign: int, U0: float, S0: float, c0: float, c1: float) -> Optional[float]:
        if L <= 0.0:
            return None
        h = max(self.deriv_dx_frac * L, 1e-8)
        Lm = max(L - h, 1e-12)
        Lp = L + h
        V0 = self.V_total(L,  bc_sign, U0, S0, c0, c1)
        Vm = self.V_total(Lm, bc_sign, U0, S0, c0, c1)
        Vp = self.V_total(Lp, bc_sign, U0, S0, c0, c1)
        denom = (0.5 * (Lp - Lm)) ** 2
        if denom == 0.0:
            return None
        return (Vp - 2.0 * V0 + Vm) / denom

    # --- Control metrics ---
    def H(self, V: float) -> Optional[float]:
        # crude 4D relation: H^2 = V/3 for V>0
        if V <= 0.0:
            return None
        return math.sqrt(V / 3.0)

    def Lambda_uv(self) -> float:
        # UV scale proxy
        return 1.0 / self.a_uv

    def epsilon_control(self, V: float) -> Optional[float]:
        H = self.H(V)
        if H is None:
            return None
        return safe_div(H, self.Lambda_uv())

    def tuning_proxy(self, V: float, pieces: List[float]) -> Optional[float]:
        denom = sum(abs(x) for x in pieces)
        if denom == 0.0:
            return None
        return abs(V) / denom

    # --- Barrier and lifetime proxy ---
    def barrier_and_lifetime_proxy(
        self,
        L_star: float,
        L_values: List[float],
        bc_sign: int,
        U0: float,
        S0: float,
        c0: float,
        c1: float,
    ) -> Tuple[Optional[float], Optional[float]]:
        """
        Look for the nearest higher-V turning region around L_star:
        - Find local max candidate by scanning outward and taking the maximum V encountered
          before V drops below V(L_star) by a margin.
        - Return barrier height ΔV and a heuristic bounce action proxy B ~ (Δphi)^4/ΔV.
        """
        V_star = self.V_total(L_star, bc_sign, U0, S0, c0, c1)
        if V_star is None:
            return None, None

        # scan neighbors to find a local "barrier" peak
        idx = min(range(len(L_values)), key=lambda i: abs(L_values[i] - L_star))
        best_peak = None
        best_Lpeak = None

        # search window: a fixed fraction of the grid
        w = max(5, len(L_values) // 10)

        for j in range(max(0, idx - w), min(len(L_values), idx + w + 1)):
            Lj = L_values[j]
            Vj = self.V_total(Lj, bc_sign, U0, S0, c0, c1)
            if Vj > V_star:
                if best_peak is None or Vj > best_peak:
                    best_peak = Vj
                    best_Lpeak = Lj

        if best_peak is None or best_Lpeak is None:
            return None, None

        dV = best_peak - V_star
        if dV <= 0.0:
            return None, None

        # field-distance proxy: treat phi ~ ln L
        dphi = abs(math.log(best_Lpeak) - math.log(L_star)) if (L_star > 0 and best_Lpeak > 0) else None
        if dphi is None or dphi == 0.0:
            return finite_or_none(dV), None

        B = (dphi ** 4) / dV
        return finite_or_none(dV), finite_or_none(B)

    def find_best_minimum_candidate(
        self,
        L_values: List[float],
        bc_sign: int,
        U0: float,
        S0: float,
        c0: float,
        c1: float,
    ) -> Dict[str, Any]:
        """
        Picks the point with minimal |V'| as a candidate extremum,
        then checks stability via V''>0.
        """
        best = None
        for L in L_values:
            dv = self.dV(L, bc_sign, U0, S0, c0, c1)
            if dv is None:
                continue
            score = abs(dv)
            if best is None or score < best["score"]:
                best = {"L": L, "dv": dv, "score": score}

        if best is None:
            return {
                "L_star": None,
                "V_star": None,
                "dV_star": None,
                "d2V_star": None,
                "stable_local_minimum": None,
                "barrier_height": None,
                "lifetime_proxy_B": None,
            }

        Ls = float(best["L"])
        V = self.V_total(Ls, bc_sign, U0, S0, c0, c1)
        d2 = self.d2V(Ls, bc_sign, U0, S0, c0, c1)
        stable = None if d2 is None else (d2 > 0.0)

        barrier, B = self.barrier_and_lifetime_proxy(Ls, L_values, bc_sign, U0, S0, c0, c1)

        return {
            "L_star": finite_or_none(Ls),
            "V_star": finite_or_none(V),
            "dV_star": finite_or_none(best["dv"]),
            "d2V_star": finite_or_none(d2),
            "stable_local_minimum": stable,
            "barrier_height": barrier,
            "lifetime_proxy_B": B,
        }

    def build_payload(
        self,
        L_values: List[float],
        bc_signs: List[int],
        U0_values: List[float],
        S0_values: List[float],
        c0_values: List[float],
        c1_values: List[float],
    ) -> Dict[str, Any]:
        require(len(L_values) >= 20, "Need enough L samples for stability scan.")
        require(all(L > 0.0 for L in L_values), "All L must be > 0.")
        require(all(s in (-1, +1) for s in bc_signs), "bc_signs must be ±1.")
        require(all(u >= 0.0 for u in U0_values), "U0 must be >= 0.")
        require(all(s >= 0.0 for s in S0_values), "S0 must be >= 0.")

        sample_points: List[Dict[str, Any]] = []

        n_total = 0
        n_has_min = 0
        n_positive = 0
        n_stable = 0
        n_controlled = 0
        n_good = 0

        for bc in bc_signs:
            for U0 in U0_values:
                for S0 in S0_values:
                    for c0 in c0_values:
                        for c1 in c1_values:
                            n_total += 1

                            cand = self.find_best_minimum_candidate(L_values, bc, U0, S0, c0, c1)
                            L_star = cand["L_star"]
                            V_star = cand["V_star"]

                            # pieces at L_star for tuning proxy
                            pieces = None
                            if L_star is not None:
                                Ls = float(L_star)
                                pieces = [
                                    self.V_cas(Ls, bc),
                                    self.V_uplift(Ls, U0),
                                    self.V_stab(Ls, S0),
                                    self.V_ct(Ls, c0, c1),
                                ]

                            eps = None if V_star is None else self.epsilon_control(float(V_star))
                            tuning = None
                            if V_star is not None and pieces is not None:
                                tuning = self.tuning_proxy(float(V_star), pieces)

                            has_min = (L_star is not None)
                            positive = (V_star is not None and float(V_star) > 0.0)
                            stable = (cand["stable_local_minimum"] is True)
                            controlled = (
                                positive
                                and eps is not None
                                and tuning is not None
                                and (eps < self.eps_max)
                                and (tuning < self.tuning_max)
                            )
                            good = (positive and stable and controlled)

                            if has_min:
                                n_has_min += 1
                            if positive:
                                n_positive += 1
                            if stable:
                                n_stable += 1
                            if controlled:
                                n_controlled += 1
                            if good:
                                n_good += 1

                            sample_points.append({
                                "coordinates": {
                                    "bc_sign": int(bc),
                                    "U0": float(U0),
                                    "S0": float(S0),
                                    "c0": float(c0),
                                    "c1": float(c1),
                                },
                                "curvature_invariants": {
                                    "ricci_scalar": None,
                                    "kretschmann": None,
                                    "note": "EFT/compactification proxy; no explicit spacetime curvature tensor.",
                                },
                                "local_observables": {
                                    "candidate_minimum": cand,
                                    "epsilon_control_H_over_LambdaUV": finite_or_none(eps),
                                    "tuning_proxy_absV_over_sum_abs_pieces": finite_or_none(tuning),
                                    "cutoff_LambdaUV": finite_or_none(self.Lambda_uv()),
                                    "flags": {
                                        "has_candidate_extremum": has_min,
                                        "positive_vacuum_energy": positive,
                                        "stable_local_minimum": stable,
                                        "controlled_positive_state": controlled,
                                        "good_state_positive_stable_controlled": good,
                                    },
                                },
                                "causal_structure": {
                                    "note": (
                                        "Positive vacuum energy is easy to arrange; the hard part is a controlled, "
                                        "stable positive minimum with small curvature relative to UV scale and "
                                        "without extreme cancellations."
                                    ),
                                },
                            })

        frac = lambda k: None if n_total == 0 else (k / n_total)

        return {
            "toy_id": self.toy_id,
            "theory": "QFT/EFT toy: de Sitter construction control diagnostics",
            "spacetime": "Compactification modulus EFT (proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "A_casimir_scale": self.A,
                "uplift_power_p": self.p,
                "stabilization_power_q": self.q,
                "a_uv_cutoff_length": self.a_uv,
                "Lambda_uv": self.Lambda_uv(),
                "eps_max": self.eps_max,
                "tuning_max": self.tuning_max,
                "L_samples": L_values,
                "bc_signs": bc_signs,
                "U0_samples": U0_values,
                "S0_samples": S0_values,
                "c0_samples": c0_values,
                "c1_samples": c1_values,
            },
            "notes": {
                "pressure_point": (
                    "A claimed positive-vacuum solution should be audited for: (i) scheme-sensitive vacuum terms, "
                    "(ii) fine-tuned cancellations, (iii) EFT control (curvature vs cutoff), and (iv) metastability."
                ),
                "model_summary": (
                    "V(L)= sgn(bc)*A/L^4 + U0/L^p - S0/L^q + (c0 + c1/L^2). "
                    "Scan for candidate extremum L* (min |V'|) and evaluate V(L*), V''(L*), barrier and lifetime proxy."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_parameter_sets": n_total,
                    "n_with_candidate_extremum": n_has_min,
                    "n_positive_vacuum_candidates": n_positive,
                    "n_stable_local_minima": n_stable,
                    "n_controlled_positive_candidates": n_controlled,
                    "n_good_positive_stable_controlled": n_good,
                    "fractions": {
                        "with_candidate_extremum": finite_or_none(frac(n_has_min)),
                        "positive": finite_or_none(frac(n_positive)),
                        "stable": finite_or_none(frac(n_stable)),
                        "controlled_positive": finite_or_none(frac(n_controlled)),
                        "good": finite_or_none(frac(n_good)),
                    },
                    "interpretation": (
                        "Good states require simultaneous positivity + stability + control (small H/Lambda_uv and low tuning)."
                    ),
                }
            },
        }

    def export_json(self, payload: Dict[str, Any], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 089: de Sitter construction control diagnostics (proxy).")
    ap.add_argument("--A", type=float, default=1.0, help="Casimir scale A (>0)")
    ap.add_argument("--p", type=float, default=2.0, help="uplift power p")
    ap.add_argument("--q", type=float, default=6.0, help="stabilization power q (q>p)")
    ap.add_argument("--a_uv", type=float, default=0.05, help="UV length cutoff a_uv (Lambda_uv=1/a_uv)")
    ap.add_argument("--eps_max", type=float, default=0.1, help="control threshold on epsilon=H/Lambda_uv")
    ap.add_argument("--tuning_max", type=float, default=0.05, help="max tuning proxy")
    ap.add_argument("--L", type=str, default="0.4,0.5,0.6,0.7,0.8,0.9,1.0,1.1,1.2,1.3,1.4,1.5,1.6,1.7,1.8,2.0,2.2,2.5,2.8,3.2,3.6,4.0",
                    help="Comma-separated L samples (>0)")
    ap.add_argument("--bc", type=str, default="-1,1", help="Comma-separated bc_signs (±1)")
    ap.add_argument("--U0", type=str, default="0.0,0.05,0.1,0.2,0.4", help="Comma-separated U0 samples (>=0)")
    ap.add_argument("--S0", type=str, default="0.0,0.05,0.1,0.2,0.4,0.8", help="Comma-separated S0 samples (>=0)")
    ap.add_argument("--c0", type=str, default="-0.05,0.0,0.05", help="Comma-separated c0 samples")
    ap.add_argument("--c1", type=str, default="-0.05,0.0,0.05", help="Comma-separated c1 samples")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy089DeSitterConstructionControlDiagnostics(
        A=float(args.A),
        p=float(args.p),
        q=float(args.q),
        a_uv=float(args.a_uv),
        eps_max=float(args.eps_max),
        tuning_max=float(args.tuning_max),
    )

    L_vals = parse_csv_floats(args.L)
    bc_vals = parse_csv_ints(args.bc)
    U0_vals = parse_csv_floats(args.U0)
    S0_vals = parse_csv_floats(args.S0)
    c0_vals = parse_csv_floats(args.c0)
    c1_vals = parse_csv_floats(args.c1)

    payload = toy.build_payload(
        L_values=L_vals,
        bc_signs=bc_vals,
        U0_values=U0_vals,
        S0_values=S0_vals,
        c0_values=c0_vals,
        c1_values=c1_vals,
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(payload, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
