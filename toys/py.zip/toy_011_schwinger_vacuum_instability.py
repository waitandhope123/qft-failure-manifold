#!/usr/bin/env python3
"""
Toy 011 — Schwinger pair production: vacuum instability in external fields

Pressure point:
- The QFT vacuum is not stable in strong classical backgrounds.
- Particle production occurs without interactions between quanta.
- “Vacuum” is a state-dependent, environment-dependent concept.

Model:
- Free charged scalar field (1+1D proxy)
- Constant external electric field E (treated as classical background)
- Schwinger pair production rate per unit volume (semiclassical formula)

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


# ----------------------------
# Toy 011
# ----------------------------

class Toy011SchwingerEffect:
    toy_id = "011"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        charge: float = 1.0,
        fields: List[float] = [0.1, 0.2, 0.5, 1.0, 2.0],
    ) -> None:
        self.m = float(mass)
        self.q = float(charge)
        self.fields = [float(E) for E in fields]

    def pair_production_rate(self, E: float) -> Optional[float]:
        """
        Γ ~ (qE / 2π) exp(-π m^2 / (qE))
        Valid as a semiclassical proxy.
        """
        if E <= 0.0:
            return None
        return (self.q * E / (2.0 * math.pi)) * math.exp(
            -math.pi * self.m * self.m / (self.q * E)
        )

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for E in self.fields:
            rate = self.pair_production_rate(E)

            sample_points.append({
                "coordinates": {
                    "electric_field_E": E,
                },
                "curvature_invariants": {
                    "external_field_strength": E,
                },
                "local_observables": {
                    "pair_production_rate_density": rate,
                    "vacuum_stable": (rate == 0.0 or rate is None),
                },
                "causal_structure": {
                    "unitarity_violation": False,
                    "vacuum_decay": rate is not None and rate > 0.0,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D, external field background)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "charge": self.q,
                "electric_fields": self.fields,
            },
            "notes": {
                "assumptions": [
                    "Free charged scalar field",
                    "Classical, constant external electric field",
                    "Semiclassical Schwinger formula used as proxy",
                ],
                "pressure_point": (
                    "The QFT vacuum is unstable in sufficiently strong classical backgrounds. "
                    "Particle production occurs without particle–particle interactions."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "trend": "Pair production rate increases rapidly once qE ≳ m^2."
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy011SchwingerEffect()
    toy.export_json()


if __name__ == "__main__":
    main()
