#!/usr/bin/env python3
"""
Toy 049 — Infrared dressing vs Fock particle number (infraparticle proxy)

Pressure point:
- In QFT with long-range interactions, sharp particle number eigenstates
  do not exist.
- Infrared dressing changes overlap structure; Fock-space particle number
  is not an invariant observable.

Model:
- Single charged particle coupled to soft modes (Bloch–Nordsieck-style proxy).
- Compare overlaps between:
    (A) bare Fock state
    (B) IR-dressed state with different dressing scales
- Show vanishing overlap as IR cutoff is removed.

Units: ℏ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


class Toy049InfraparticleAmbiguity:
    toy_id = "049"

    def __init__(
        self,
        *,
        alpha: float = 0.1,
        ir_cutoffs: List[float] | None = None,
    ) -> None:
        require(alpha > 0.0, "alpha > 0")
        self.alpha = float(alpha)
        self.ir_cutoffs = ir_cutoffs or [1.0, 0.5, 0.2, 0.1, 0.05]

    def overlap(self, lambda_ir: float) -> float:
        """
        Overlap between bare Fock state and IR-dressed state.
        In Bloch–Nordsieck-type models:
            |<bare|dressed>| ~ exp(-alpha * ln(1/lambda))
        → 0 as lambda → 0
        """
        require(lambda_ir > 0.0, "IR cutoff > 0")
        return math.exp(-self.alpha * math.log(1.0 / lambda_ir))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for lam in self.ir_cutoffs:
            ov = self.overlap(lam)
            sample_points.append({
                "coordinates": {"ir_cutoff": lam},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "bare_vs_dressed_overlap": ov,
                },
                "causal_structure": {
                    "note": "Sharp particle number fails in IR"
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (infrared structure proxy)",
            "spacetime": "Long-range interacting field (IR limit)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "alpha": self.alpha,
                "ir_cutoffs": self.ir_cutoffs,
            },
            "notes": {
                "pressure_point": (
                    "In the presence of long-range interactions, asymptotic states "
                    "are infraparticles. Bare Fock particle number is not a physical observable."
                ),
                "model": "Bloch–Nordsieck infrared dressing proxy",
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "min_overlap": min(
                        sp["local_observables"]["bare_vs_dressed_overlap"]
                        for sp in sample_points
                    ),
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy049InfraparticleAmbiguity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
