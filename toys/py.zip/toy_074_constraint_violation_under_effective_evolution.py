#!/usr/bin/env python3
"""
Toy 074 — Constraint violation under effective QFT evolution (Gauss-law / truncation proxy)

What it probes (pressure point):
- In exact gauge theories, physical states satisfy constraints (e.g. Gauss law).
- Effective descriptions (mode truncation, projection, coarse-graining) may preserve
  constraints at t=0 but violate them dynamically.
- This mirrors GR constraint propagation failure: initially valid data leaves the
  physical subspace under approximate evolution.

Model (minimal, deterministic):
- Two coupled harmonic oscillators representing longitudinal (constraint) and transverse modes.
- Exact Hamiltonian preserves a linear constraint C = q_L + α q_T = 0.
- Effective evolution drops a coupling term (or projects dynamics), breaking constraint preservation.
- Track constraint norm ||C(t)|| over time.

Diagnostics:
- Constraint norm vs time under:
  * exact evolution (constraint preserved)
  * effective evolution (constraint growth)
- Energy drift under effective evolution.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 074
# ----------------------------

class Toy074ConstraintViolationEffectiveEvolution:
    toy_id = "074"

    def __init__(self, *, omega: float = 1.0, g: float = 0.3, alpha: float = 1.0) -> None:
        require(omega > 0.0, "omega must be > 0.")
        self.omega = float(omega)
        self.g = float(g)
        self.alpha = float(alpha)

    def exact_step(self, x: np.ndarray, dt: float) -> np.ndarray:
        """
        Exact linear evolution preserving constraint.
        x = (qL, pL, qT, pT)
        """
        qL, pL, qT, pT = x
        dqL = pL
        dpL = -self.omega**2 * qL - self.g * qT
        dqT = pT
        dpT = -self.omega**2 * qT - self.g * qL
        return x + dt * np.array([dqL, dpL, dqT, dpT])

    def effective_step(self, x: np.ndarray, dt: float) -> np.ndarray:
        """
        Approximate evolution: drops coupling term g*qL in dpT
        (constraint no longer propagated)
        """
        qL, pL, qT, pT = x
        dqL = pL
        dpL = -self.omega**2 * qL - self.g * qT
        dqT = pT
        dpT = -self.omega**2 * qT   # dropped coupling
        return x + dt * np.array([dqL, dpL, dqT, dpT])

    def constraint(self, x: np.ndarray) -> float:
        qL, _, qT, _ = x
        return qL + self.alpha * qT

    def energy(self, x: np.ndarray) -> float:
        qL, pL, qT, pT = x
        return 0.5 * (pL**2 + pT**2 + self.omega**2 * (qL**2 + qT**2) + 2*self.g*qL*qT)

    def build_payload(self, t_max: float, dt: float) -> Dict[str, Any]:
        require(t_max > 0.0, "t_max must be > 0.")
        require(dt > 0.0, "dt must be > 0.")

        n = int(round(t_max / dt))
        times = [i * dt for i in range(n + 1)]

        # Initial state satisfying constraint exactly
        qT0 = 1.0
        qL0 = -self.alpha * qT0
        x0 = np.array([qL0, 0.0, qT0, 0.0])

        x_exact = x0.copy()
        x_eff = x0.copy()

        sample_points: List[Dict[str, Any]] = []

        for t in times:
            Ce = self.constraint(x_exact)
            Ceff = self.constraint(x_eff)

            Ee = self.energy(x_exact)
            Eeff = self.energy(x_eff)

            sample_points.append({
                "coordinates": {"t": float(t)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "constraint_exact": finite_or_none(Ce),
                    "constraint_effective": finite_or_none(Ceff),
                    "energy_exact": finite_or_none(Ee),
                    "energy_effective": finite_or_none(Eeff),
                },
                "causal_structure": {
                    "note": (
                        "Exact evolution preserves constraint; "
                        "effective evolution violates it despite valid initial data."
                    ),
                },
            })

            x_exact = self.exact_step(x_exact, dt)
            x_eff = self.effective_step(x_eff, dt)

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): constraint propagation failure under effective evolution",
            "spacetime": "Finite-dimensional proxy",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "omega": self.omega,
                "g": self.g,
                "alpha_constraint": self.alpha,
                "t_max": t_max,
                "dt": dt,
            },
            "notes": {
                "pressure_point": (
                    "Physical constraints (Gauss-law–like) are preserved by exact dynamics "
                    "but generically violated by effective or truncated evolution, even when "
                    "initial data is constraint-satisfying. This mirrors GR constraint propagation failure."
                ),
                "constraint": "C = q_L + α q_T = 0",
            },
            "sample_points": sample_points,
        }

    def export_json(self, t_max: float, dt: float, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_max=t_max, dt=dt)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 074: constraint violation under effective QFT evolution.")
    ap.add_argument("--omega", type=float, default=1.0, help="Oscillator frequency")
    ap.add_argument("--g", type=float, default=0.3, help="Coupling strength")
    ap.add_argument("--alpha", type=float, default=1.0, help="Constraint coefficient")
    ap.add_argument("--t_max", type=float, default=10.0, help="Max time")
    ap.add_argument("--dt", type=float, default=0.01, help="Time step")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy074ConstraintViolationEffectiveEvolution(
        omega=float(args.omega),
        g=float(args.g),
        alpha=float(args.alpha),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_max=float(args.t_max), dt=float(args.dt), out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
