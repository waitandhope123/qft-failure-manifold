#!/usr/bin/env python3
"""
Toy 095 — Microcausality leakage vs UV softening (locality boundary proxy)

What it probes (pressure point):
- UV modifications that “soften” short-distance behavior (lattice, higher-derivative, form factors)
  can induce microcausality leakage: commutators become nonzero outside the light cone.
- Attempts to cure UV pathologies can trade them for locality/causality violations.
- Quantifies leakage as a function of UV scale and modification strength.

Model (deterministic, 1+1D proxy):
- Use a scalar field commutator kernel built from a modified dispersion relation:
    ω(k) = sqrt(k^2 + m^2) * (1 + α * (k^2 / Λ^2))
  (higher-derivative-like). For α>0, UV phase/group velocities change.

- Equal-time commutator of field with itself is zero; we probe the Pauli–Jordan function proxy:
    Δ(t, x) = ∫_{-K}^{K} (dk/2π) (1/ω(k)) sin(ω(k) t) sin(k x)
  (odd in x; this proxy captures support spreading.)

- In a strictly local relativistic theory, Δ(t,x) has support inside the light cone (|x|<=t in c=1 units),
  up to discretization. With UV modification + finite cutoff K, we see leakage for |x|>t.

Diagnostics:
- For each (α, Λ, K, t):
  * leakage_max = max_{|x|>t} |Δ(t,x)|
  * inside_max  = max_{|x|<=t} |Δ(t,x)|
  * leakage_ratio = leakage_max / inside_max
- We scan x on a deterministic grid.

Determinism:
- No randomness; fixed grids.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def linspace(a: float, b: float, n: int) -> List[float]:
    require(n >= 2, "linspace requires n>=2")
    step = (b - a) / (n - 1)
    return [a + i * step for i in range(n)]


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


# ----------------------------
# Toy 095
# ----------------------------

class Toy095MicrocausalityLeakageVsUVSoftening:
    toy_id = "095"

    def __init__(
        self,
        *,
        m: float = 1.0,
        n_k: int = 6000,
        n_x: int = 801,
    ) -> None:
        require(m > 0.0, "m must be > 0.")
        require(n_k >= 1000, "n_k must be >= 1000.")
        require(n_x >= 201, "n_x must be >= 201.")
        self.m = float(m)
        self.n_k = int(n_k)
        self.n_x = int(n_x)

    def omega(self, k: float, alpha: float, Lam: float) -> float:
        base = math.sqrt(k * k + self.m * self.m)
        return base * (1.0 + alpha * (k * k) / (Lam * Lam))

    def delta(self, t: float, x: float, alpha: float, Lam: float, K: float) -> float:
        """
        Δ(t,x) proxy integral with symmetric cutoff [-K,K], using sin(kx) to keep oddness.
        Deterministic trapezoid.
        """
        if t <= 0.0:
            return 0.0
        dk = (2.0 * K) / self.n_k
        s = 0.0
        for i in range(self.n_k + 1):
            k = -K + i * dk
            w = 0.5 if (i == 0 or i == self.n_k) else 1.0
            om = self.omega(k, alpha, Lam)
            if om == 0.0:
                continue
            integrand = (1.0 / om) * math.sin(om * t) * math.sin(k * x)
            s += w * integrand
        return (s * dk) / (2.0 * math.pi)

    def leakage_metrics(
        self,
        *,
        t: float,
        alpha: float,
        Lam: float,
        K: float,
        x_max: float,
    ) -> Dict[str, Any]:
        xs = linspace(-x_max, x_max, self.n_x)
        inside_max = 0.0
        leakage_max = 0.0

        for x in xs:
            val = abs(self.delta(t, x, alpha, Lam, K))
            if abs(x) <= t:
                inside_max = max(inside_max, val)
            else:
                leakage_max = max(leakage_max, val)

        ratio = None
        if inside_max > 0.0:
            ratio = leakage_max / inside_max

        return {
            "inside_max": finite_or_none(inside_max),
            "leakage_max": finite_or_none(leakage_max),
            "leakage_ratio": finite_or_none(ratio) if ratio is not None else None,
        }

    def build_payload(
        self,
        t_values: List[float],
        alpha_values: List[float],
        Lam_values: List[float],
        K_values: List[float],
        x_max_factor: float,
    ) -> Dict[str, Any]:
        require(len(t_values) >= 2, "Need multiple t samples.")
        require(len(alpha_values) >= 2, "Need multiple alpha samples.")
        require(len(Lam_values) >= 2, "Need multiple Lambda samples.")
        require(len(K_values) >= 1, "Need at least one K sample.")
        require(x_max_factor > 1.0, "x_max_factor should exceed 1 to include outside-lightcone region.")
        require(all(t > 0.0 for t in t_values), "t must be > 0.")
        require(all(L > 0.0 for L in Lam_values), "Lambda must be > 0.")
        require(all(K > 0.0 for K in K_values), "K must be > 0.")

        sample_points: List[Dict[str, Any]] = []

        max_ratio = 0.0
        worst_case = None

        for t in t_values:
            x_max = x_max_factor * t
            for alpha in alpha_values:
                for Lam in Lam_values:
                    for K in K_values:
                        mets = self.leakage_metrics(t=t, alpha=alpha, Lam=Lam, K=K, x_max=x_max)
                        ratio = mets["leakage_ratio"]
                        if ratio is not None and ratio > max_ratio:
                            max_ratio = float(ratio)
                            worst_case = {"t": t, "alpha": alpha, "Lambda": Lam, "K": K}

                        sample_points.append({
                            "coordinates": {
                                "t": float(t),
                                "alpha": float(alpha),
                                "Lambda_uv_scale": float(Lam),
                                "K_momentum_cutoff": float(K),
                            },
                            "curvature_invariants": {
                                "ricci_scalar": None,
                                "kretschmann": None,
                                "note": "Microcausality/commutator support proxy; no curvature.",
                            },
                            "local_observables": {
                                "inside_lightcone_max_abs": mets["inside_max"],
                                "outside_lightcone_leakage_max_abs": mets["leakage_max"],
                                "leakage_ratio": mets["leakage_ratio"],
                                "x_max_used": float(x_max),
                            },
                            "causal_structure": {
                                "note": (
                                    "UV-modified dispersion plus cutoff induces nonzero commutator support outside the lightcone "
                                    "(microcausality leakage), quantifiable by leakage_ratio."
                                ),
                            },
                        })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): microcausality leakage under UV softening",
            "spacetime": "1+1D commutator kernel proxy with modified dispersion",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "mass_m": self.m,
                "n_k": self.n_k,
                "n_x": self.n_x,
                "t_samples": t_values,
                "alpha_samples": alpha_values,
                "Lambda_samples": Lam_values,
                "K_samples": K_values,
                "x_max_factor_times_t": x_max_factor,
                "dispersion": "omega(k)=sqrt(k^2+m^2)*(1 + alpha*(k^2/Lambda^2))",
                "delta_proxy": "Δ(t,x)=∫_{-K}^{K} (dk/2π) (1/ω(k)) sin(ω(k)t) sin(kx)",
            },
            "notes": {
                "pressure_point": (
                    "UV modifications that soften short-distance behavior can violate microcausality: "
                    "commutators leak outside the light cone. Locality/causality is a boundary condition on UV completion."
                ),
                "warning": "Finite cutoff K already induces artifacts; the toy tracks how UV softening changes leakage scaling.",
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_leakage_ratio_observed": finite_or_none(max_ratio),
                    "worst_case_parameters": worst_case,
                }
            },
        }

    def export_json(self, payload: Dict[str, Any], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 095: microcausality leakage vs UV softening (deterministic).")
    ap.add_argument("--m", type=float, default=1.0, help="Mass m>0")
    ap.add_argument("--n_k", type=int, default=6000, help="k quadrature steps")
    ap.add_argument("--n_x", type=int, default=801, help="x grid points")
    ap.add_argument("--t", type=str, default="0.8,1.2,1.6", help="Comma-separated t samples (>0)")
    ap.add_argument("--alpha", type=str, default="0.0,0.1,0.3,0.6", help="Comma-separated alpha samples")
    ap.add_argument("--Lambda", type=str, default="3,6,12", help="Comma-separated Lambda UV scales (>0)")
    ap.add_argument("--K", type=str, default="30", help="Comma-separated momentum cutoffs K (>0)")
    ap.add_argument("--x_max_factor", type=float, default=2.5, help="x_max = factor * t")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    t_values = parse_csv_floats(args.t)
    alpha_values = parse_csv_floats(args.alpha)
    Lam_values = parse_csv_floats(args.Lambda)
    K_values = parse_csv_floats(args.K)

    toy = Toy095MicrocausalityLeakageVsUVSoftening(
        m=float(args.m),
        n_k=int(args.n_k),
        n_x=int(args.n_x),
    )

    payload = toy.build_payload(
        t_values=t_values,
        alpha_values=alpha_values,
        Lam_values=Lam_values,
        K_values=K_values,
        x_max_factor=float(args.x_max_factor),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(payload, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
