#!/usr/bin/env python3
"""
Toy 018 — Measurement-induced disturbance: non-commuting local probes

Pressure point:
- Local measurements in QFT do not commute at spacelike-separated smearings
  once finite resolution and backreaction are included.
- “Measurement locality” is weaker than microcausality.
- Operational probes disturb the state in resolution-dependent ways.

GR-style heavy:
- two independent diagnostics
- explicit regime classification
- failure flags

Model:
- Free real scalar field in 1+1D
- Two Gaussian-smeared field probes at spacelike separation
- Compare operator commutator vs state disturbance proxy

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy018MeasurementDisturbance:
    toy_id = "018"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        separation_x: float = 3.0,
        smearings: List[float] = [0.2, 0.5, 1.0],
        cutoff: float = 30.0,
        dk: float = 0.02,
    ) -> None:
        self.m = float(mass)
        self.x = float(separation_x)
        self.sigmas = [float(s) for s in smearings]
        self.Lambda = float(cutoff)
        self.dk = float(dk)

    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def smeared_commutator(self, sigma: float) -> float:
        """
        Proxy for smeared commutator magnitude at spacelike separation.
        Vanishes only in sharp continuum limit.
        """
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega(k)
            weight = math.exp(-sigma * sigma * k * k)
            s += math.sin(k * self.x) * weight / (2.0 * math.pi * w)
            k += self.dk
        return abs(s * self.dk)

    def state_disturbance_proxy(self, sigma: float) -> float:
        """
        Independent diagnostic:
        measurement backreaction grows as resolution improves.
        """
        return 1.0 / (sigma * sigma)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for sigma in self.sigmas:
            comm = self.smeared_commutator(sigma)
            disturb = self.state_disturbance_proxy(sigma)

            sample_points.append({
                "coordinates": {
                    "separation_x": self.x,
                    "smearing_width_sigma": sigma,
                },
                "curvature_invariants": {
                    "uv_cutoff_Lambda": self.Lambda,
                },
                "local_observables": {
                    "smeared_commutator_magnitude": comm,
                    "state_disturbance_proxy": disturb,
                },
                "causal_structure": {
                    "spacelike_separation": True,
                    "operator_microcausality_exact": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "separation_x": self.x,
                "smearings": self.sigmas,
                "cutoff_Lambda": self.Lambda,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Gaussian-smeared local probes",
                    "Operational measurement modeled via disturbance proxy",
                ],
                "pressure_point": (
                    "Operational locality is weaker than microcausality. "
                    "Finite-resolution measurements introduce nonlocal disturbance "
                    "even at spacelike separation."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "strict_local_measurement": False,
                    "measurement_backreaction_unavoidable": True,
                    "resolution_dependence": True,
                },
                "regime_classification": {
                    "sharp_limit_sigma_to_0": "ill_defined",
                    "finite_resolution": "approximately_local",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy018MeasurementDisturbance().export_json()


if __name__ == "__main__":
    main()
