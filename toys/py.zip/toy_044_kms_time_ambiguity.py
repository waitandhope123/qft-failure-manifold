#!/usr/bin/env python3
"""
Toy 044 — KMS condition and thermal time ambiguity

Pressure point:
- Thermal behavior in QFT is not an intrinsic property of a state alone,
  but of a state *plus a choice of time evolution*.
- The KMS condition depends on the Hamiltonian used to define time.
- There is no invariant notion of temperature without a preferred time flow.

Model:
- Finite-dimensional system with two different Hamiltonians.
- Same density matrix tested against two time evolutions.
- Check KMS condition via two-point correlators.

Units: ℏ = k_B = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def expm_hermitian_2x2(H: np.ndarray, t: complex) -> np.ndarray:
    """
    Matrix exponential exp(-i H t) specialized for 2x2 Hermitian matrices.

    Avoids scipy dependency (numpy has no expm) and supports complex t (KMS shift).
    """
    H = np.asarray(H, dtype=complex)
    if H.shape != (2, 2):
        raise ValueError("expm_hermitian_2x2 expects a 2x2 matrix.")
    # Spectral decomposition is stable for Hermitian H
    evals, evecs = np.linalg.eigh(H)
    phases = np.exp(-1j * evals * t)
    return evecs @ np.diag(phases) @ evecs.conj().T


class Toy044KMSTimeAmbiguity:
    toy_id = "044"

    def __init__(
        self,
        *,
        beta: float = 1.0,
        omega: float = 1.0,
        epsilon: float = 0.3,
        dt: float = 0.05,
        steps: int = 200,
    ) -> None:
        require(beta > 0.0, "beta>0")
        require(omega > 0.0, "omega>0")
        require(dt > 0.0 and steps >= 1, "dt>0, steps>=1")

        self.beta = float(beta)
        self.omega = float(omega)
        self.epsilon = float(epsilon)
        self.dt = float(dt)
        self.steps = int(steps)

        sx = np.array([[0, 1], [1, 0]], dtype=complex)
        sz = np.array([[1, 0], [0, -1]], dtype=complex)

        self.H1 = self.omega * sz
        self.H2 = self.omega * sz + self.epsilon * sx

        # thermal state with respect to H1
        evals, evecs = np.linalg.eigh(self.H1)
        Z = sum(math.exp(-self.beta * float(e)) for e in evals)
        self.rho = sum(
            math.exp(-self.beta * float(evals[i])) / Z
            * np.outer(evecs[:, i], evecs[:, i].conj())
            for i in range(2)
        )

        self.A = sx  # probe operator

    def correlator(self, H: np.ndarray, t: complex) -> complex:
        U = expm_hermitian_2x2(H, t)
        A_t = U.conj().T @ self.A @ U
        return np.trace(self.rho @ A_t @ self.A)

    def evolve(self) -> List[Dict[str, Any]]:
        sample_points: List[Dict[str, Any]] = []

        for step in range(self.steps + 1):
            t = step * self.dt

            C1 = self.correlator(self.H1, t)
            C1_shift = self.correlator(self.H1, t + 1j * self.beta)

            C2 = self.correlator(self.H2, t)
            C2_shift = self.correlator(self.H2, t + 1j * self.beta)

            sample_points.append({
                "coordinates": {"t": t},
                "curvature_invariants": {
                    "analogy": None
                },
                "local_observables": {
                    "KMS_violation_H1": float(abs(C1 - C1_shift)),
                    "KMS_violation_H2": float(abs(C2 - C2_shift)),
                },
                "causal_structure": {
                    "note": "Thermality depends on choice of time generator"
                },
            })

        return sample_points

    def build_payload(self) -> Dict[str, Any]:
        sps = self.evolve()
        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (thermal time proxy)",
            "spacetime": "Two-level system",
            "units": {"hbar": 1, "kB": 1},
            "parameters": {
                "beta": self.beta,
                "omega": self.omega,
                "epsilon": self.epsilon,
                "dt": self.dt,
                "steps": self.steps,
            },
            "notes": {
                "pressure_point": (
                    "The KMS condition, and hence temperature, is defined "
                    "relative to a choice of Hamiltonian (time flow). "
                    "Thermality is not invariant."
                ),
                "diagnostic": "KMS condition via two-point correlators",
            },
            "sample_points": sps,
            "observables": {
                "summary": {
                    "final_KMS_violation_H1": sps[-1]["local_observables"]["KMS_violation_H1"],
                    "final_KMS_violation_H2": sps[-1]["local_observables"]["KMS_violation_H2"],
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy044KMSTimeAmbiguity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
