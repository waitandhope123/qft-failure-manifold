#!/usr/bin/env python3
"""
Toy 029 — Vacuum ambiguity in curved time (Bogoliubov inequivalence)

Pressure point:
- Different time slicings define inequivalent vacua.
- Particle content is observer- and history-dependent.
- “The vacuum” is not unique even in free QFT.

GR parallel:
- Different foliations → different notions of time
- Same spacetime, different physics for different observers

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free scalar field (mode space proxy)
- Two time choices related by Bogoliubov transformation
- Track particle number and vacuum overlap

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy029BogoliubovVacuumAmbiguity:
    toy_id = "029"

    def __init__(
        self,
        *,
        squeeze_params: List[float] = [0.2, 0.5, 1.0, 1.5],
    ) -> None:
        self.rs = [float(r) for r in squeeze_params]

    def particle_number(self, r: float) -> float:
        """
        n_k = sinh^2(r)
        """
        return math.sinh(r) ** 2

    def vacuum_overlap(self, r: float) -> float:
        """
        |⟨0|0_r⟩| = 1 / cosh(r)
        """
        return 1.0 / math.cosh(r)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for r in self.rs:
            n = self.particle_number(r)
            overlap = self.vacuum_overlap(r)

            sample_points.append({
                "coordinates": {
                    "bogoliubov_parameter_r": r,
                },
                "curvature_invariants": {
                    "time_slicing": "inequivalent",
                },
                "local_observables": {
                    "particle_number_expectation": n,
                    "vacuum_overlap": overlap,
                },
                "causal_structure": {
                    "unique_vacuum": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Same spacetime, different time slicings",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "squeeze_params": self.rs,
            },
            "notes": {
                "assumptions": [
                    "Free scalar field",
                    "Bogoliubov-related mode bases",
                ],
                "pressure_point": (
                    "Vacuum states depend on time slicing. "
                    "Particle content is observer- and history-dependent."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "unique_vacuum_state": False,
                    "observer_independent_particles": False,
                },
                "regime_classification": {
                    "small_r": "nearly_equivalent_vacua",
                    "large_r": "inequivalent_fock_spaces",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy029BogoliubovVacuumAmbiguity().export_json()


if __name__ == "__main__":
    main()
