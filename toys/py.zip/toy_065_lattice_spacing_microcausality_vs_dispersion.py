#!/usr/bin/env python3
"""
Toy 065 — Lattice spacing: microcausality vs dispersion (Lieb–Robinson style proxy)

What it probes (pressure point):
- Exact relativistic QFT has sharp light-cone microcausality: commutators vanish at spacelike separation.
- Any UV regulator / discretization (lattice spacing a, finite difference time stepping) breaks exact Lorentz invariance
  and deforms the light cone into a dispersive "causal cone" with leakage outside the continuum cone.
- This toy quantifies leakage for a free scalar on a 1D lattice by computing the commutator kernel.

Model (controlled, analytic):
- Free scalar field on 1D periodic lattice with N sites, spacing a, mass m.
- Normal mode frequencies:
    ω_k = sqrt( m^2 + (2/a)^2 sin^2(π k / N) ),  k=0..N-1
- Equal-time canonical commutator is enforced, but unequal-time commutator is lattice-dispersive.
- Lattice commutator kernel (discrete Pauli–Jordan function):
    Δ(n,t) = (1/N) Σ_k [ sin(ω_k t)/ω_k ] * exp(i 2π k n / N )
  (real-valued; take real part)

Diagnostics:
- Compare |Δ(n,t)| to a continuum light-cone proxy: |x| > t (with c=1, x = n a).
- Define leakage fraction at time t:
    leakage(t) = (Σ_{|x|>t} |Δ|) / (Σ_all |Δ|)
- Also report max |Δ| outside cone.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


# ----------------------------
# Toy 065
# ----------------------------

class Toy065LatticeSpacingMicrocausalityVsDispersion:
    toy_id = "065"

    def __init__(self, *, N: int = 256, a: float = 0.25, m: float = 1.0) -> None:
        require(N >= 8 and (N % 2 == 0), "N must be even and >= 8.")
        require(a > 0.0, "a must be > 0.")
        require(m >= 0.0, "m must be >= 0.")
        self.N = int(N)
        self.a = float(a)
        self.m = float(m)

        # Precompute mode frequencies ω_k
        self.omega = [self._omega_k(k) for k in range(self.N)]

    def _omega_k(self, k: int) -> float:
        # ω_k = sqrt(m^2 + (2/a)^2 sin^2(pi k / N))
        s = math.sin(math.pi * k / self.N)
        return math.sqrt(self.m * self.m + (2.0 / self.a) ** 2 * (s * s))

    def delta_commutator(self, n: int, t: float) -> float:
        """
        Δ(n,t) = (1/N) Σ_k [ sin(ω_k t)/ω_k ] * cos(2π k n / N)
        (real part; sine term gives oddness in t automatically)
        """
        N = self.N
        acc = 0.0
        for k in range(N):
            wk = self.omega[k]
            if wk == 0.0:
                continue
            phase = 2.0 * math.pi * k * n / N
            acc += (math.sin(wk * t) / wk) * math.cos(phase)
        return acc / N

    def leakage_metrics(self, t: float, n_max: int) -> Dict[str, Any]:
        """
        Compute leakage outside continuum cone |x|>t (c=1) using x = n a.
        Evaluate n in [-n_max..n_max], with periodic identification implicitly ignored
        (assume n_max << N/2).
        """
        require(t >= 0.0, "t must be >= 0.")
        require(1 <= n_max < self.N // 2, "n_max must be in [1, N/2).")

        sum_all = 0.0
        sum_out = 0.0
        max_out = 0.0

        for n in range(-n_max, n_max + 1):
            x = abs(n) * self.a
            val = abs(self.delta_commutator(n, t))
            sum_all += val
            if x > t:
                sum_out += val
                if val > max_out:
                    max_out = val

        leakage = None if sum_all == 0.0 else (sum_out / sum_all)
        return {
            "n_max": n_max,
            "sum_abs_delta_all": finite_or_none(sum_all),
            "sum_abs_delta_outside_cone": finite_or_none(sum_out),
            "leakage_fraction_outside_cone": finite_or_none(leakage) if leakage is not None else None,
            "max_abs_delta_outside_cone": finite_or_none(max_out),
            "cone_definition": "|x| > t with x = n*a, c=1",
        }

    def build_payload(self, t_values: List[float], n_max: int) -> Dict[str, Any]:
        require(len(t_values) >= 1, "Need at least one t sample.")
        require(all(t >= 0.0 for t in t_values), "All t must be >= 0.")

        sample_points: List[Dict[str, Any]] = []

        for t in t_values:
            metrics = self.leakage_metrics(t=float(t), n_max=int(n_max))

            # also include a representative Δ at n=0 and at edge
            d0 = self.delta_commutator(0, float(t))
            d_edge = self.delta_commutator(int(n_max), float(t))

            sample_points.append({
                "coordinates": {
                    "t": float(t),
                    "n_max": int(n_max),
                    "a_lattice_spacing": self.a,
                },
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "QFT toy; no spacetime curvature.",
                },
                "local_observables": {
                    "model": {
                        "type": "free_scalar_1d_lattice",
                        "N_sites": self.N,
                        "a": self.a,
                        "mass_m": self.m,
                    },
                    "commutator_kernel": {
                        "Delta_n0_t": finite_or_none(d0),
                        "Delta_nmax_t": finite_or_none(d_edge),
                        "metrics": metrics,
                        "interpretation": (
                            "In continuum relativistic QFT, commutator support is confined to the light cone. "
                            "On a lattice, dispersion produces leakage outside the continuum cone."
                        ),
                    },
                },
                "causal_structure": {
                    "microcausality_exact": False,
                    "note": "Leakage fraction quantifies regulator-induced microcausality violation (proxy).",
                },
            })

        max_leak = 0.0
        for sp in sample_points:
            lf = sp["local_observables"]["commutator_kernel"]["metrics"]["leakage_fraction_outside_cone"]
            if lf is not None:
                max_leak = max(max_leak, float(lf))

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): lattice regulator vs microcausality",
            "spacetime": "1D lattice (periodic) as UV regulator",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "N": self.N,
                "a": self.a,
                "m": self.m,
                "t_samples": t_values,
                "n_max_window": n_max,
            },
            "notes": {
                "pressure_point": (
                    "UV regulation via lattice spacing breaks Lorentz invariance and deforms causal structure. "
                    "Microcausality becomes approximate, with dispersive leakage outside the continuum cone."
                ),
                "key_formulas": {
                    "omega_k": "ω_k = sqrt(m^2 + (2/a)^2 sin^2(π k / N))",
                    "Delta(n,t)": "Δ(n,t)=(1/N) Σ_k [sin(ω_k t)/ω_k] cos(2π k n / N)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_leakage_fraction_over_t_samples": finite_or_none(max_leak),
                }
            },
        }

    def export_json(self, t_values: List[float], n_max: int, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(t_values=t_values, n_max=n_max)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 065: lattice regulator induces dispersive microcausality leakage.")
    ap.add_argument("--N", type=int, default=256, help="Number of lattice sites (even)")
    ap.add_argument("--a", type=float, default=0.25, help="Lattice spacing a")
    ap.add_argument("--m", type=float, default=1.0, help="Mass m")
    ap.add_argument("--t", type=str, default="0.0,0.25,0.5,0.75,1.0,1.5,2.0,3.0",
                    help="Comma-separated times t>=0")
    ap.add_argument("--n_max", type=int, default=80, help="Window in sites for leakage scan (must be < N/2)")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy065LatticeSpacingMicrocausalityVsDispersion(N=int(args.N), a=float(args.a), m=float(args.m))
    t_values = parse_csv_floats(args.t)

    out_path = args.out.strip() or None
    json_path = toy.export_json(t_values=t_values, n_max=int(args.n_max), out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
