#!/usr/bin/env python3
"""
Toy 001 — Free real scalar QFT (1+1D): vacuum two-point function & microcausality

Pressure point:
- Even free QFT requires a UV regulator.
- Coincident-point correlators diverge as cutoff → ∞.
- Microcausality holds only in the regulated limit (numerically approximate).

Model:
- Real scalar field φ in flat 1+1D Minkowski spacetime
- Mass m
- Momentum cutoff Λ
- Vacuum state

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 001
# ----------------------------

class Toy001FreeScalarQFT:
    toy_id = "001"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        cutoff: float = 20.0,
        dk: float = 0.02,
    ) -> None:
        require(mass >= 0.0, "mass must be >= 0")
        require(cutoff > 0.0, "cutoff must be > 0")
        require(dk > 0.0, "dk must be > 0")

        self.m = float(mass)
        self.Lambda = float(cutoff)
        self.dk = float(dk)

    # Dispersion relation
    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    # Vacuum Wightman function (mode sum, regulated)
    def wightman(self, t: float, x: float) -> float:
        """
        G(t,x) = ∫_{-Λ}^{Λ} dk / (4π ω_k) * exp[-i(ω_k t - k x)]
        We return the real part (cosine), imaginary part cancels by symmetry.
        """
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega(k)
            s += math.cos(w * t - k * x) / (4.0 * math.pi * w)
            k += self.dk
        return s * self.dk

    # Pauli–Jordan commutator function Δ(t,x)
    def commutator(self, t: float, x: float) -> float:
        """
        Δ(t,x) = ∫ dk / (2π ω_k) * sin(ω_k t) sin(k x)
        Vanishes for spacelike separation in continuum theory.
        """
        s = 0.0
        k = -self.Lambda
        while k <= self.Lambda:
            w = self.omega(k)
            s += math.sin(w * t) * math.sin(k * x) / (2.0 * math.pi * w)
            k += self.dk
        return s * self.dk

    def build_payload(self, sample_points_tx: List[Dict[str, float]]) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for pt in sample_points_tx:
            t = float(pt["t"])
            x = float(pt["x"])
            interval = t * t - x * x

            G = self.wightman(t, x)
            Delta = self.commutator(t, x)

            sample_points.append({
                "coordinates": {
                    "t": t,
                    "x": x,
                    "momentum": None,
                },
                "curvature_invariants": {
                    # QFT analog: regulator diagnostics
                    "cutoff_Lambda": self.Lambda,
                    "dk": self.dk,
                },
                "local_observables": {
                    "wightman_function_G": G,
                    "coincident_limit_defined": False if (t == 0.0 and x == 0.0) else True,
                },
                "causal_structure": {
                    "interval_t2_minus_x2": interval,
                    "commutator_Delta": Delta,
                    "spacelike": (interval < 0.0),
                },
            })

        payload: Dict[str, Any] = {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "cutoff_Lambda": self.Lambda,
                "dk": self.dk,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Vacuum state",
                    "Momentum cutoff regulator",
                    "No interactions, no renormalization",
                ],
                "pressure_point": (
                    "Vacuum correlators require a UV regulator; "
                    "local quantities diverge as cutoff increases. "
                    "Microcausality is only recovered in the continuum limit."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "microcausality_test": "Commutator should vanish for spacelike separation as cutoff → ∞",
                "uv_sensitivity": "Coincident-point correlator diverges with cutoff",
            },
        }

        return payload

    def export_json(
        self,
        sample_points_tx: List[Dict[str, float]],
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(sample_points_tx)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy001FreeScalarQFT(
        mass=1.0,
        cutoff=20.0,
        dk=0.02,
    )

    # Fixed deterministic sample points
    sample_points_tx = [
        {"t": 0.0, "x": 0.0},    # coincident (UV pathology)
        {"t": 0.0, "x": 1.0},    # spacelike
        {"t": 1.0, "x": 0.0},    # timelike
        {"t": 1.0, "x": 1.5},    # spacelike
        {"t": 2.0, "x": 1.0},    # timelike
    ]

    toy.export_json(sample_points_tx)


if __name__ == "__main__":
    main()
