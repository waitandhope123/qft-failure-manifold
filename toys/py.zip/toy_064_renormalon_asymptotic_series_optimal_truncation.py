#!/usr/bin/env python3
"""
Toy 064 — Asymptotic perturbation series & optimal truncation (renormalon proxy)

What it probes (pressure point):
- Many QFT perturbation expansions are asymptotic: coefficients grow ~ n! (renormalons/instantons).
- Partial sums initially improve then worsen; predictivity requires an *optimal truncation* n*.
- Different prescriptions (truncation, Borel sum / PV) differ by nonperturbative ambiguities ~ exp(-const/g).

Model (controlled proxy):
- Define a formal series with factorial growth:
    S(g) = Σ_{n>=0} a_n g^n,  with a_n = n!
  This diverges for any g != 0 but is Borel summable in a principal-value sense.

Borel transform:
    B(t) = Σ (a_n / n!) t^n = Σ t^n = 1/(1 - t)  (pole at t=1)
Borel sum (PV):
    S_Borel(g) = PV ∫_0^∞ e^{-t} / (1 - g t) dt
Pole at t=1/g on integration contour => prescription ambiguity for g>0.

Diagnostics:
- For each g, compute:
  * partial sums up to N
  * N* where term magnitude |a_N g^N| is minimal (optimal truncation)
  * error of partial sums relative to PV Borel integral
  * difference between left/right deformations around the pole (imaginary ambiguity proxy)

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness. Numerical integration is deterministic.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    if x is None:
        return None
    if isinstance(x, (int, float)) and math.isfinite(float(x)):
        return float(x)
    return None


def simpson_integrate(f, a: float, b: float, n: int) -> float:
    """
    Composite Simpson's rule with n even.
    Deterministic and sufficient for this toy.
    """
    require(n >= 2 and n % 2 == 0, "n must be even and >=2")
    h = (b - a) / n
    s = f(a) + f(b)
    for i in range(1, n):
        x = a + i * h
        s += (4.0 if i % 2 == 1 else 2.0) * f(x)
    return s * (h / 3.0)


# ----------------------------
# Toy 064
# ----------------------------

class Toy064RenormalonAsymptoticSeriesOptimalTruncation:
    toy_id = "064"

    def __init__(self, *, t_max: float = 200.0, n_int: int = 20000, eps_pv: float = 1e-3) -> None:
        require(t_max > 0.0, "t_max must be > 0.")
        require(n_int >= 200 and n_int % 2 == 0, "n_int must be even and reasonably large.")
        require(eps_pv > 0.0, "eps_pv must be > 0.")
        self.t_max = float(t_max)
        self.n_int = int(n_int)
        self.eps_pv = float(eps_pv)

    # a_n = n!
    def a_n(self, n: int) -> float:
        return math.factorial(n)

    def partial_sum(self, g: float, N: int) -> float:
        s = 0.0
        for n in range(0, N + 1):
            s += self.a_n(n) * (g ** n)
        return s

    def term_mag(self, g: float, n: int) -> float:
        return abs(self.a_n(n) * (g ** n))

    def optimal_truncation(self, g: float, Nmax: int) -> int:
        """
        Choose n in [0..Nmax] that minimizes |a_n g^n|.
        For factorial growth, n* ~ 1/g.
        """
        best_n = 0
        best = self.term_mag(g, 0)
        for n in range(1, Nmax + 1):
            tm = self.term_mag(g, n)
            if tm < best:
                best = tm
                best_n = n
        return best_n

    def borel_integrand(self, g: float, t: float) -> float:
        # PV integrand for B(t)=1/(1-t) translated to 1/(1 - g t) with e^{-t} weight
        denom = (1.0 - g * t)
        return math.exp(-t) / denom

    def borel_pv(self, g: float) -> Tuple[Optional[float], Optional[float]]:
        """
        Principal value integral for g>0 has a pole at t=1/g.
        Return (PV_real, ambiguity_proxy_imag)
        We compute:
          PV ≈ ∫_0^{t0-eps} + ∫_{t0+eps}^{t_max}
        and estimate a prescription "imaginary ambiguity" proxy using residue size:
          Im ~ ±π e^{-t0}/g   (since pole in 1/(1-g t) at t0=1/g)
        This is the standard Borel ambiguity for a simple pole on the contour.
        """
        require(g > 0.0, "g must be > 0 for this toy.")
        t0 = 1.0 / g
        if t0 >= self.t_max:
            # pole beyond cutoff; PV reduces to ordinary integral on [0,t_max]
            f = lambda tt: self.borel_integrand(g, tt)
            val = simpson_integrate(f, 0.0, self.t_max, self.n_int)
            return val, 0.0

        eps = self.eps_pv
        a1, b1 = 0.0, max(0.0, t0 - eps)
        a2, b2 = min(self.t_max, t0 + eps), self.t_max

        # allocate integration points proportionally for stability
        n1 = max(200, int(self.n_int * (b1 - a1) / self.t_max))
        if n1 % 2 == 1:
            n1 += 1
        n2 = self.n_int - n1
        if n2 < 200:
            n2 = 200
        if n2 % 2 == 1:
            n2 += 1

        f = lambda tt: self.borel_integrand(g, tt)
        I1 = simpson_integrate(f, a1, b1, n1) if b1 > a1 else 0.0
        I2 = simpson_integrate(f, a2, b2, n2) if b2 > a2 else 0.0
        pv = I1 + I2

        # Ambiguity magnitude from residue:
        # resid of 1/(1-g t) at t0 is -1/g
        # Imag ambiguity magnitude = π e^{-t0} / g
        amb = math.pi * math.exp(-t0) / g
        return pv, amb

    def sample_point(self, g: float, Nmax: int) -> Dict[str, Any]:
        require(g > 0.0, "g must be > 0.")
        require(Nmax >= 0, "Nmax must be >= 0.")

        pv, amb = self.borel_pv(g)
        n_star = self.optimal_truncation(g, Nmax)

        # compute partial sums up to Nmax, and errors vs PV
        # store only a few representative sums to keep JSON moderate:
        # N=0, N=n*, Nmax
        def safe_ps(N: int) -> Optional[float]:
            try:
                return self.partial_sum(g, N)
            except OverflowError:
                return None

        S0 = safe_ps(0)
        Sstar = safe_ps(n_star)
        Smax = safe_ps(Nmax)

        err0 = None if (pv is None or S0 is None) else (S0 - pv)
        errS = None if (pv is None or Sstar is None) else (Sstar - pv)
        errM = None if (pv is None or Smax is None) else (Smax - pv)

        # also record minimal term magnitude at n*
        min_term = self.term_mag(g, n_star)

        return {
            "coordinates": {
                "g_coupling": float(g),
                "Nmax": int(Nmax),
            },
            "curvature_invariants": {
                "ricci_scalar": None,
                "kretschmann": None,
                "note": "QFT toy; no spacetime curvature.",
            },
            "local_observables": {
                "asymptotic_series": {
                    "coefficients": "a_n = n!",
                    "partial_sum_N0": finite_or_none(S0) if S0 is not None else None,
                    "partial_sum_Nstar": finite_or_none(Sstar) if Sstar is not None else None,
                    "partial_sum_Nmax": finite_or_none(Smax) if Smax is not None else None,
                    "optimal_truncation_n_star": n_star,
                    "min_term_magnitude_at_n_star": finite_or_none(min_term),
                },
                "borel_resummation": {
                    "PV_borel_sum_real": finite_or_none(pv) if pv is not None else None,
                    "ambiguity_magnitude_proxy": finite_or_none(amb) if amb is not None else None,
                    "note": (
                        "For g>0 the Borel transform has a pole on the integration contour (t=1/g). "
                        "PV defines a real value but leaves a nonperturbative ambiguity ~ ±i*ambiguity."
                    ),
                },
                "errors_vs_PV": {
                    "error_N0_minus_PV": finite_or_none(err0) if err0 is not None else None,
                    "error_Nstar_minus_PV": finite_or_none(errS) if errS is not None else None,
                    "error_Nmax_minus_PV": finite_or_none(errM) if errM is not None else None,
                },
            },
            "causal_structure": {
                "note": "Failure is predictive (asymptotic series) not causal.",
            },
        }

    def build_payload(self, g_values: List[float], Nmax: int) -> Dict[str, Any]:
        require(len(g_values) >= 1, "Need g samples.")
        require(Nmax >= 0, "Nmax must be >= 0.")
        require(all(g > 0.0 for g in g_values), "All g must be > 0.")

        sample_points = [self.sample_point(g=float(g), Nmax=int(Nmax)) for g in g_values]

        # Summary: worst absolute error at N* over the grid, and typical n* scale
        max_abs_err_star = 0.0
        avg_n_star = 0.0
        count = 0

        for sp in sample_points:
            e = sp["local_observables"]["errors_vs_PV"]["error_Nstar_minus_PV"]
            if e is not None:
                max_abs_err_star = max(max_abs_err_star, abs(float(e)))
            avg_n_star += sp["local_observables"]["asymptotic_series"]["optimal_truncation_n_star"]
            count += 1

        avg_n_star = (avg_n_star / count) if count else None

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): asymptotic perturbation series & renormalon ambiguity proxy",
            "spacetime": "N/A",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "g_samples": g_values,
                "Nmax": Nmax,
                "borel_integration": {
                    "t_max": self.t_max,
                    "n_int": self.n_int,
                    "pv_excision_eps": self.eps_pv,
                },
            },
            "notes": {
                "pressure_point": (
                    "Perturbation theory can be asymptotic: beyond an optimal truncation, adding more terms "
                    "reduces accuracy. Borel resummation introduces nonperturbative ambiguities when singularities "
                    "lie on the contour (renormalon proxy)."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "max_abs_error_at_optimal_truncation_over_grid": finite_or_none(max_abs_err_star),
                    "average_optimal_truncation_n_star_over_grid": finite_or_none(avg_n_star),
                }
            },
        }

    def export_json(self, g_values: List[float], Nmax: int, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(g_values=g_values, Nmax=Nmax)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 064: asymptotic series optimal truncation + Borel ambiguity proxy.")
    ap.add_argument("--g", type=str, default="0.05,0.08,0.1,0.12,0.15,0.2,0.25",
                    help="Comma-separated couplings g>0")
    ap.add_argument("--Nmax", type=int, default=80, help="Maximum perturbative order to consider")
    ap.add_argument("--t_max", type=float, default=200.0, help="Upper limit for Borel t integration")
    ap.add_argument("--n_int", type=int, default=20000, help="Even number of Simpson panels for integration")
    ap.add_argument("--eps_pv", type=float, default=1e-3, help="PV excision half-width around pole")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy064RenormalonAsymptoticSeriesOptimalTruncation(
        t_max=float(args.t_max),
        n_int=int(args.n_int),
        eps_pv=float(args.eps_pv),
    )
    g_values = parse_csv_floats(args.g)

    out_path = args.out.strip() or None
    json_path = toy.export_json(g_values=g_values, Nmax=int(args.Nmax), out_path=out_path)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
