#!/usr/bin/env python3
"""
Toy 020 — Reeh–Schlieder theorem proxy (local operators generate global states)

Pressure point:
- Acting with operators localized in an arbitrarily small region
  can approximate any global state.
- Strict separation between “local” and “global” degrees of freedom fails.
- Local control implies nonlocal reach.

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free real scalar field in 1+1D (proxy)
- Local operator algebra acting on vacuum
- Measure overlap with globally excited target states as region shrinks

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy020ReehSchliederProxy:
    toy_id = "020"

    def __init__(
        self,
        *,
        region_sizes: List[float] = [2.0, 1.0, 0.5, 0.25],
        excitation_level: float = 1.0,
    ) -> None:
        self.regions = [float(r) for r in region_sizes]
        self.E = float(excitation_level)

    def overlap_proxy(self, region_size: float) -> float:
        """
        Proxy for ⟨ψ_target | O_region | 0⟩ overlap.
        Nonzero even as region → 0, but rapidly suppressed.
        """
        return math.exp(-self.E / max(region_size, 1e-6))

    def energy_cost_proxy(self, region_size: float) -> float:
        """
        Independent diagnostic:
        Energy cost diverges as region shrinks.
        """
        return self.E / max(region_size * region_size, 1e-6)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for R in self.regions:
            overlap = self.overlap_proxy(R)
            cost = self.energy_cost_proxy(R)

            sample_points.append({
                "coordinates": {
                    "region_size": R,
                },
                "curvature_invariants": {
                    "locality_scale": R,
                },
                "local_observables": {
                    "state_overlap_proxy": overlap,
                    "energy_cost_proxy": cost,
                },
                "causal_structure": {
                    "strict_local_global_split": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "region_sizes": self.regions,
                "excitation_level": self.E,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Local operator algebra",
                    "Overlap and energy treated as controlled proxies",
                ],
                "pressure_point": (
                    "Local operators can approximate global states (Reeh–Schlieder). "
                    "Locality does not imply independent degrees of freedom."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "local_state_preparation": False,
                    "strict_subsystem_factorization": False,
                },
                "regime_classification": {
                    "small_region": "nonzero_overlap_high_cost",
                    "large_region": "efficient_state_preparation",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy020ReehSchliederProxy().export_json()


if __name__ == "__main__":
    main()
