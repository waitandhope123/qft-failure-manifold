#!/usr/bin/env python3
"""
Toy 081 — Cross-toy failure-mode classifier (meta-comparator)

What it probes (pressure point):
- Not a new physics pathology, but a closure tool: takes multiple toy JSON outputs and
  classifies them into a shared set of failure modes, producing a summary report.
- Mirrors your GR "comparator" phase: turns a pile of boundary demonstrations into a map.

Inputs:
- One or more JSON files produced by other toys (your existing schema).

Outputs:
- A single JSON report containing:
  * per-file inferred tags
  * counts by tag
  * basic health checks (missing fields, empty sample_points, etc.)

Determinism:
- Deterministic heuristic rules; no randomness.

Usage:
  python toy_081_cross_toy_failure_mode_classifier.py --inputs toy_074_*.json,toy_075_*.json --out report.json
"""

from __future__ import annotations

import argparse
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)

def read_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def write_json(path: str, payload: Dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, sort_keys=True)

def as_str(x: Any) -> str:
    return "" if x is None else str(x)

def lower(s: Any) -> str:
    return as_str(s).lower()

def safe_list(x: Any) -> List[Any]:
    return x if isinstance(x, list) else []

def safe_dict(x: Any) -> Dict[str, Any]:
    return x if isinstance(x, dict) else {}

def parse_inputs(s: str) -> List[str]:
    # Accept comma-separated and/or repeated --inputs
    items: List[str] = []
    for part in s.split(","):
        p = part.strip()
        if p:
            items.append(p)
    return items


# ----------------------------
# Failure mode taxonomy (shared across GR/QFT)
# ----------------------------

FAILURE_TAGS = [
    "vacuum_or_state_ambiguity",
    "time_or_foliation_ambiguity",
    "observer_dependence_thermality",
    "regulator_or_scheme_dependence",
    "locality_or_factorization_failure",
    "constraint_propagation_failure",
    "linearization_instability",
    "unitarity_or_positivity_violation",
    "analytic_continuation_ill_posed",
    "ir_asymptotic_pathology",
    "asymptotic_series_nonconvergence",
    "measurement_or_operational_limit",
    "backreaction_or_mean_field_breakdown",
    "contour_choice_stokes",
    "noncommuting_limits",
    "other",
]

@dataclass
class Inference:
    tags: List[str]
    evidence: Dict[str, List[str]]  # tag -> list of strings


# ----------------------------
# Heuristic inference rules
# ----------------------------

def infer_tags(doc: Dict[str, Any]) -> Inference:
    toy_id = lower(doc.get("toy_id"))
    theory = lower(doc.get("theory"))
    notes = safe_dict(doc.get("notes"))
    pressure = lower(notes.get("pressure_point"))
    title_blob = " ".join([toy_id, theory, pressure])

    tags: List[str] = []
    evidence: Dict[str, List[str]] = {}

    def add(tag: str, why: str) -> None:
        if tag not in tags:
            tags.append(tag)
        evidence.setdefault(tag, []).append(why)

    # Core keyword buckets
    if any(k in title_blob for k in ["vacuum", "bogoliubov", "haag", "no instantaneous vacuum", "inequivalent vacua"]):
        add("vacuum_or_state_ambiguity", "keyword: vacuum/bogoliubov/haag")

    if any(k in title_blob for k in ["time ordering", "no preferred hamiltonian", "foliation", "kms time", "modular time"]):
        add("time_or_foliation_ambiguity", "keyword: time ordering/hamiltonian/foliation/kms/modular")

    if any(k in title_blob for k in ["unruh", "thermal", "kms", "observer", "horizon"]):
        add("observer_dependence_thermality", "keyword: unruh/thermal/kms/observer/horizon")

    if any(k in title_blob for k in ["renormal", "scheme", "cutoff", "regulator", "lattice", "scale dependence"]):
        add("regulator_or_scheme_dependence", "keyword: renormal/scheme/cutoff/regulator/lattice/scale")

    if any(k in title_blob for k in ["type iii", "factorization", "reeh", "locality failure", "edge mode", "gauge locality", "no local energy"]):
        add("locality_or_factorization_failure", "keyword: type III/factorization/reeh/edge/gauge/no local energy")

    if any(k in title_blob for k in ["constraint", "gauss", "constraint propagation"]):
        add("constraint_propagation_failure", "keyword: constraint/gauss")

    if any(k in title_blob for k in ["linearization instability", "second-order obstruction", "integrability", "jacobi"]):
        add("linearization_instability", "keyword: linearization/integrability/jacobi/obstruction")

    if any(k in title_blob for k in ["unitarity", "positivity", "kallen", "spectral positivity", "optical theorem"]):
        add("unitarity_or_positivity_violation", "keyword: unitarity/positivity/kallen/optical theorem")

    if any(k in title_blob for k in ["analytic continuation", "ill-posed", "spectral inversion", "laplace inversion"]):
        add("analytic_continuation_ill_posed", "keyword: analytic continuation/ill-posed/spectral inversion")

    if any(k in title_blob for k in ["ir ", "infraparticle", "soft", "dressing", "memory effects", "superselection"]):
        add("ir_asymptotic_pathology", "keyword: IR/infraparticle/soft/dressing/memory/superselection")

    if any(k in title_blob for k in ["ope", "asymptotic", "borel", "nonconvergent", "diverges"]):
        add("asymptotic_series_nonconvergence", "keyword: OPE/asymptotic/borel/nonconvergent")

    if any(k in title_blob for k in ["measurement", "smearing", "detector", "operational", "disturbance", "open system"]):
        add("measurement_or_operational_limit", "keyword: measurement/smearing/detector/operational/open system")

    if any(k in title_blob for k in ["backreaction", "semiclassical", "mean-field", "stochastic", "noise"]):
        add("backreaction_or_mean_field_breakdown", "keyword: backreaction/semiclassical/mean-field/stochastic/noise")

    if any(k in title_blob for k in ["contour", "stokes", "lefschetz", "thimble"]):
        add("contour_choice_stokes", "keyword: contour/stokes/lefschetz/thimble")

    if any(k in title_blob for k in ["non-commuting", "non commuting limits", "order of limits"]):
        add("noncommuting_limits", "keyword: non-commuting limits")

    # Fall back
    if not tags:
        add("other", "no matching keywords")

    # Keep stable ordering
    tags_sorted = [t for t in FAILURE_TAGS if t in tags]
    return Inference(tags=tags_sorted, evidence=evidence)


def health_checks(doc: Dict[str, Any]) -> Dict[str, Any]:
    issues: List[str] = []
    if "toy_id" not in doc:
        issues.append("missing toy_id")
    if "theory" not in doc:
        issues.append("missing theory")
    sp = safe_list(doc.get("sample_points"))
    if not sp:
        issues.append("empty_or_missing sample_points")
    # Check that sample_points entries have required keys
    if sp:
        first = sp[0]
        if not isinstance(first, dict):
            issues.append("sample_points not objects")
        else:
            for k in ["coordinates", "curvature_invariants", "local_observables", "causal_structure"]:
                if k not in first:
                    issues.append(f"sample_point_missing_key:{k}")
    return {
        "issues": issues,
        "ok": (len(issues) == 0),
        "n_sample_points": len(sp),
    }


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 081: Cross-toy failure-mode classifier (meta-comparator).")
    ap.add_argument("--inputs", type=str, required=True,
                    help="Comma-separated list of toy JSON files to classify")
    ap.add_argument("--out", type=str, default="toy_081_report.json", help="Output report JSON path")
    args = ap.parse_args()

    input_paths = parse_inputs(args.inputs)
    require(len(input_paths) >= 1, "Provide at least one input JSON file.")

    per_file: List[Dict[str, Any]] = []
    counts: Dict[str, int] = {t: 0 for t in FAILURE_TAGS}

    for path in input_paths:
        doc = read_json(path)
        inf = infer_tags(doc)
        hc = health_checks(doc)

        for t in inf.tags:
            counts[t] = counts.get(t, 0) + 1

        per_file.append({
            "file": path,
            "toy_id": doc.get("toy_id"),
            "theory": doc.get("theory"),
            "tags": inf.tags,
            "evidence": inf.evidence,
            "health": hc,
        })

    # Compact counts: only nonzero
    counts_nonzero = {k: v for k, v in counts.items() if v > 0}

    payload = {
        "toy_id": "081",
        "theory": "Meta: cross-toy failure-mode classifier",
        "parameters": {
            "n_inputs": len(input_paths),
            "inputs": input_paths,
            "taxonomy": FAILURE_TAGS,
        },
        "observables": {
            "counts_by_tag": counts_nonzero,
            "per_file": per_file,
        },
        "notes": {
            "pressure_point": (
                "Closure tool: converts a collection of toy outputs into a shared failure-mode map. "
                "Heuristic keyword rules; intended for stable, reproducible categorization."
            ),
        },
    }

    write_json(args.out, payload)
    print(f"Wrote {args.out}")


if __name__ == "__main__":
    main()
