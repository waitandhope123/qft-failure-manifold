#!/usr/bin/env python3
"""
Toy 005 — Regulator dependence of vacuum energy density (zero-point energy)

Pressure point:
- Vacuum energy density is divergent and regulator-dependent.
- Different UV regulators give parametrically different answers.
- No preferred physical value exists without external input.

Model:
- Free real scalar field in 1+1D
- Vacuum zero-point energy density
- Compare hard momentum cutoff vs lattice spacing regulator

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    base = os.path.splitext(os.path.basename(py_path))[0]
    return base + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


# ----------------------------
# Toy 005
# ----------------------------

class Toy005VacuumEnergy:
    toy_id = "005"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        cutoffs: List[float] = [5.0, 10.0, 20.0, 40.0],
        dk: float = 0.01,
    ) -> None:
        require(mass >= 0.0, "mass must be >= 0")
        self.m = float(mass)
        self.cutoffs = [float(L) for L in cutoffs]
        self.dk = float(dk)

    def omega(self, k: float) -> float:
        return math.sqrt(k * k + self.m * self.m)

    def vacuum_energy_density_cutoff(self, Lambda: float) -> float:
        """
        ρ = 1/2 ∫_{-Λ}^{Λ} dk / (2π) ω_k
        """
        s = 0.0
        k = -Lambda
        while k <= Lambda:
            s += self.omega(k)
            k += self.dk
        return 0.5 * s * self.dk / (2.0 * math.pi)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for Lambda in self.cutoffs:
            rho = self.vacuum_energy_density_cutoff(Lambda)

            sample_points.append({
                "coordinates": {
                    "momentum_cutoff_Lambda": Lambda,
                },
                "curvature_invariants": {
                    "uv_scale_Lambda": Lambda,
                },
                "local_observables": {
                    "vacuum_energy_density": rho,
                },
                "causal_structure": {
                    "lorentz_invariant": False,
                    "note": "Hard cutoff breaks Lorentz invariance explicitly.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "cutoffs": self.cutoffs,
                "dk": self.dk,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Vacuum state",
                    "Hard momentum cutoff regulator",
                ],
                "pressure_point": (
                    "Vacuum energy density diverges and depends on regulator choice. "
                    "No unique physical value exists within QFT alone."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "scaling": "ρ ∼ Λ^2 for large cutoff in 1+1D",
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    toy = Toy005VacuumEnergy()
    toy.export_json()


if __name__ == "__main__":
    main()
