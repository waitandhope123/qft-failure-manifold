#!/usr/bin/env python3
"""
Toy 030 — No local particle number operator (particles as asymptotic concepts)

Pressure point:
- There is no well-defined local particle number operator in QFT.
- “Particles” emerge only asymptotically (in time, or in special states).
- Local measurements access fields, not particles.

GR parallel:
- Local observers cannot define global horizons
- Global notions emerge only asymptotically

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free scalar field in 1+1D
- Compare local field observables vs asymptotic particle number
- Diagnose incompatibility via commutator and variance behavior

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy030NoLocalParticleNumber:
    toy_id = "030"

    def __init__(
        self,
        *,
        smearing_widths: List[float] = [0.2, 0.5, 1.0, 2.0],
        asymptotic_particle_number: float = 1.0,
    ) -> None:
        self.sigmas = [float(s) for s in smearing_widths]
        self.N_inf = float(asymptotic_particle_number)

    def local_particle_number_proxy(self, sigma: float) -> Optional[float]:
        """
        Attempted local particle number diverges or is ill-defined
        as localization improves.
        """
        if sigma < 0.3:
            return None
        return self.N_inf / sigma

    def local_variance_proxy(self, sigma: float) -> float:
        """
        Independent diagnostic:
        fluctuations grow as localization sharpens.
        """
        return 1.0 / (sigma * sigma)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for sigma in self.sigmas:
            N_loc = self.local_particle_number_proxy(sigma)
            var = self.local_variance_proxy(sigma)

            sample_points.append({
                "coordinates": {
                    "smearing_width_sigma": sigma,
                },
                "curvature_invariants": {
                    "asymptotic_particle_number": self.N_inf,
                },
                "local_observables": {
                    "local_particle_number_attempt": N_loc,
                    "local_fluctuation_variance": var,
                },
                "causal_structure": {
                    "local_particle_concept_valid": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "smearing_widths": self.sigmas,
                "asymptotic_particle_number": self.N_inf,
            },
            "notes": {
                "assumptions": [
                    "Free scalar field",
                    "Attempted localization of particle concept",
                ],
                "pressure_point": (
                    "Particles are not local observables in QFT. "
                    "They emerge only asymptotically or in special states."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "local_particle_operator": False,
                    "particles_fundamental": False,
                },
                "regime_classification": {
                    "sharp_localization": "ill_defined",
                    "asymptotic_limit": "particle_interpretation_valid",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy030NoLocalParticleNumber().export_json()


if __name__ == "__main__":
    main()
