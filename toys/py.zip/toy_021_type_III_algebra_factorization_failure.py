#!/usr/bin/env python3
"""
Toy 021 — Failure of sharp subsystem factorization (Type III algebra proxy)

Pressure point:
- Local operator algebras in QFT are Type III: no density matrix, no tensor factorization.
- “The state of a spatial subregion” is not well-defined without extra structure.
- Entropy, energy, and particle number rely on regulator-dependent splits.

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Free real scalar field in 1+1D (proxy)
- Compare sharp vs smeared spatial bipartitions
- Diagnose divergence of energy and entropy in sharp limit

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy021TypeIIIAlgebraProxy:
    toy_id = "021"

    def __init__(
        self,
        *,
        boundary_smearings: List[float] = [1.0, 0.5, 0.25, 0.125],
        cutoff: float = 30.0,
    ) -> None:
        self.sigmas = [float(s) for s in boundary_smearings]
        self.Lambda = float(cutoff)

    def energy_divergence_proxy(self, sigma: float) -> float:
        """
        Energy localized near boundary diverges as smearing → 0.
        """
        return self.Lambda / max(sigma, 1e-6)

    def entropy_divergence_proxy(self, sigma: float) -> float:
        """
        Entanglement entropy diverges logarithmically as boundary sharpens.
        """
        return math.log(self.Lambda / max(sigma, 1e-6))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for sigma in self.sigmas:
            E = self.energy_divergence_proxy(sigma)
            S = self.entropy_divergence_proxy(sigma)

            sample_points.append({
                "coordinates": {
                    "boundary_smearing_sigma": sigma,
                },
                "curvature_invariants": {
                    "uv_cutoff_Lambda": self.Lambda,
                },
                "local_observables": {
                    "boundary_energy_proxy": E,
                    "boundary_entropy_proxy": S,
                },
                "causal_structure": {
                    "sharp_factorization_possible": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "boundary_smearings": self.sigmas,
                "cutoff_Lambda": self.Lambda,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Spatial bipartition",
                    "Boundary smearing treated explicitly",
                ],
                "pressure_point": (
                    "Local operator algebras are Type III. "
                    "Sharp subsystem factorization fails; divergences appear at boundaries."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "density_matrix_for_region": False,
                    "sharp_tensor_factorization": False,
                },
                "regime_classification": {
                    "sharp_boundary": "divergent",
                    "smeared_boundary": "regulated",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy021TypeIIIAlgebraProxy().export_json()


if __name__ == "__main__":
    main()
