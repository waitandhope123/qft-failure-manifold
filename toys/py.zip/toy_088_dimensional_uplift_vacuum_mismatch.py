#!/usr/bin/env python3
"""
Toy 088 — Dimensional uplift vs observable vacuum energy (non-4D proxy)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
"""

from __future__ import annotations

import json, math, os
from typing import Any, Dict, List, Optional

def py_to_json_name(p: str) -> str:
    return os.path.splitext(os.path.basename(p))[0] + ".json"

def finite_or_none(x: Any) -> Optional[float]:
    try:
        x = float(x)
        return x if math.isfinite(x) else None
    except Exception:
        return None

class Toy088DimensionalUpliftVacuumMismatch:
    toy_id = "088"

    def effective_energy(self, Lambda_D: float, D: int) -> float:
        return Lambda_D * (4.0 / D)

    def build_payload(self, lambdas: List[float], dims: List[int]) -> Dict[str, Any]:
        sample_points = []

        for L in lambdas:
            for D in dims:
                eff = self.effective_energy(L, D)

                sample_points.append({
                    "coordinates": {
                        "Lambda_higherD": L,
                        "dimension": D,
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "Dimensional reduction proxy.",
                    },
                    "local_observables": {
                        "effective_4D_energy": finite_or_none(eff),
                    },
                    "causal_structure": {
                        "note": "Positive energy in higher D does not map cleanly to 4D.",
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "QFT/EFT: dimensional uplift mismatch",
            "spacetime": "Effective dimensional reduction",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "Lambda_samples": lambdas,
                "dimensions": dims,
            },
            "notes": {
                "pressure_point": "Higher-dimensional positive energy does not uniquely define 4D dark energy.",
            },
            "sample_points": sample_points,
        }

    def export_json(self, lambdas: List[float], dims: List[int]) -> str:
        out = py_to_json_name(__file__)
        with open(out, "w") as f:
            json.dump(self.build_payload(lambdas, dims), f, indent=2, sort_keys=True)
        return out

def main() -> None:
    Lambdas = [0.1*i for i in range(1, 21)]
    Ds = [4, 5, 6, 10]
    Toy088DimensionalUpliftVacuumMismatch().export_json(Lambdas, Ds)
    print("Wrote", py_to_json_name(__file__))

if __name__ == "__main__":
    main()
