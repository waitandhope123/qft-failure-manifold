#!/usr/bin/env python3
"""
Toy 032 — Anomaly: classical symmetry vs quantum violation (non-commuting limits)

Pressure point:
- A symmetry of the classical action need not survive quantization.
- Regularization + renormalization can break symmetries (anomalies).
- Taking limits (cutoff → ∞) does not commute with symmetry enforcement.

GR parallel:
- Classical constraints vs quantum backreaction
- Conservation laws fail once regulators are removed

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- Chiral (axial) current anomaly proxy in 1+1D
- Compare classical current conservation vs regulated quantum divergence
- Track regulator dependence and invariant anomaly coefficient

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy032QuantumAnomaly:
    toy_id = "032"

    def __init__(
        self,
        *,
        coupling: float = 1.0,
        regulators: List[float] = [5.0, 10.0, 20.0, 40.0],
    ) -> None:
        self.g = float(coupling)
        self.Ls = [float(L) for L in regulators]

    # --- Classical diagnostic ---

    def classical_current_divergence(self) -> float:
        """
        ∂_μ j^μ = 0 (classically)
        """
        return 0.0

    # --- Quantum diagnostics ---

    def regulated_anomaly(self, Lambda: float) -> float:
        """
        Regulated divergence of axial current (proxy):
        ∂_μ j^μ ~ g / π (1 - exp(-Λ))
        Approaches finite, nonzero value as Λ → ∞.
        """
        return (self.g / math.pi) * (1.0 - math.exp(-Lambda))

    def anomaly_invariant(self) -> float:
        """
        Scheme-independent anomaly coefficient.
        """
        return self.g / math.pi

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        classical = self.classical_current_divergence()
        invariant = self.anomaly_invariant()

        for L in self.Ls:
            qdiv = self.regulated_anomaly(L)

            sample_points.append({
                "coordinates": {
                    "regulator_cutoff_Lambda": L,
                },
                "curvature_invariants": {
                    "classical_divergence": classical,
                },
                "local_observables": {
                    "regulated_quantum_divergence": qdiv,
                    "anomaly_coefficient_invariant": invariant,
                },
                "causal_structure": {
                    "classical_symmetry_preserved": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "coupling": self.g,
                "regulators": self.Ls,
            },
            "notes": {
                "assumptions": [
                    "Chiral current with classical conservation",
                    "Regulator required for quantum calculation",
                ],
                "pressure_point": (
                    "Classical symmetries can be broken by quantization. "
                    "The anomaly survives regulator removal as a finite, invariant remnant."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "classical_symmetry_quantum_exact": False,
                    "limit_commutativity": False,
                },
                "regime_classification": {
                    "finite_regulator": "symmetry_softly_broken",
                    "regulator_removed": "anomalous_conservation",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy032QuantumAnomaly().export_json()


if __name__ == "__main__":
    main()
