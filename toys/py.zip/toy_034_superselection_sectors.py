#!/usr/bin/env python3
"""
Toy 034 — Superselection sectors (global charges block superposition)

Pressure point:
- Not all mathematically allowed superpositions are physically realizable.
- Global charges and superselection rules partition Hilbert space.
- Certain transitions are forbidden, not dynamically suppressed.

GR parallel:
- Topological sectors in spacetime
- Global constraints not visible in local equations

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- U(1) charge superselection (proxy)
- Compare states with different total charge
- Diagnose vanishing interference vs allowed mixtures

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy034SuperselectionSectors:
    toy_id = "034"

    def __init__(
        self,
        *,
        charges: List[int] = [-1, 0, 1],
    ) -> None:
        self.charges = [int(q) for q in charges]

    def interference_term(self, q1: int, q2: int) -> float:
        """
        Proxy for ⟨q1|O|q2⟩.
        Vanishes if q1 != q2 due to superselection.
        """
        if q1 != q2:
            return 0.0
        return 1.0

    def mixture_allowed(self, q1: int, q2: int) -> bool:
        """
        Classical mixtures allowed across sectors.
        """
        return True

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for q1 in self.charges:
            for q2 in self.charges:
                interference = self.interference_term(q1, q2)

                sample_points.append({
                    "coordinates": {
                        "charge_1": q1,
                        "charge_2": q2,
                    },
                    "curvature_invariants": {
                        "global_charge_conserved": True,
                    },
                    "local_observables": {
                        "interference_amplitude": interference,
                        "classical_mixture_allowed": self.mixture_allowed(q1, q2),
                    },
                    "causal_structure": {
                        "quantum_superposition_allowed": interference != 0.0,
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (global charge sectors)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "charges": self.charges,
            },
            "notes": {
                "assumptions": [
                    "Exact global U(1) symmetry",
                    "Charge superselection enforced",
                ],
                "pressure_point": (
                    "Superselection rules forbid certain superpositions even though "
                    "they are mathematically definable. The Hilbert space is partitioned "
                    "by global charges."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "arbitrary_superposition": False,
                    "hilbert_space_fully_connected": False,
                },
                "regime_classification": {
                    "same_charge": "quantum_interference_allowed",
                    "different_charge": "superselection_blocked",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy034SuperselectionSectors().export_json()


if __name__ == "__main__":
    main()
