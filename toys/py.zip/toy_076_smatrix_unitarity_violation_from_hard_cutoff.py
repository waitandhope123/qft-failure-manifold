#!/usr/bin/env python3
"""
Toy 076 — S-matrix unitarity violation from a hard cutoff (partial-wave bound proxy)

What it probes (pressure point):
- In QFT/EFT, naive regulators or truncations can violate unitarity.
- A classic diagnostic: partial-wave unitarity bound for 2->2 scattering:
    |Re a_l(s)| <= 1/2   (elastic unitarity)
- If you impose a hard momentum cutoff or truncate loop effects inconsistently,
  the resulting amplitude can violate the bound above some energy.

Model (controlled proxy):
- Use a simple EFT-like amplitude with growing energy dependence:
    A(s) = (s / Λ^2) * (1 + c * s/Λ^2)
  Then define s-wave partial amplitude proxy:
    a0(s) = A(s) / (16π)
- Hard cutoff: forbid s > Λ_cut^2 by "clipping" internal states, but keep external energy growing:
  implement as an effective amplitude:
    A_cut(s) = A(s) * (1 + δ * Θ(s - Λ_cut^2))
  where δ>0 mimics mismatch introduced by inconsistent cutoff (proxy for broken optical theorem).

Diagnostics:
- Scan s, compute Re a0(s) and check |Re a0| <= 1/2.
- Report first s where bound is violated and max violation.

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 076
# ----------------------------

class Toy076SMatrixUnitarityViolationHardCutoff:
    toy_id = "076"

    def __init__(self, *, Lambda: float = 10.0, c: float = 0.25, Lambda_cut: float = 8.0, delta: float = 0.5) -> None:
        require(Lambda > 0.0, "Lambda must be > 0.")
        require(Lambda_cut > 0.0, "Lambda_cut must be > 0.")
        require(delta >= 0.0, "delta must be >= 0.")
        self.Lambda = float(Lambda)
        self.c = float(c)
        self.Lambda_cut = float(Lambda_cut)
        self.delta = float(delta)

    def A(self, s: float) -> float:
        x = s / (self.Lambda ** 2)
        return x * (1.0 + self.c * x)

    def A_cut(self, s: float) -> float:
        base = self.A(s)
        if s > (self.Lambda_cut ** 2):
            return base * (1.0 + self.delta)
        return base

    def a0(self, s: float, cut: bool) -> float:
        A = self.A_cut(s) if cut else self.A(s)
        return A / (16.0 * math.pi)

    def build_payload(self, s_values: List[float]) -> Dict[str, Any]:
        require(len(s_values) >= 3, "Need s samples.")
        require(all(s > 0.0 for s in s_values), "All s must be > 0.")

        sample_points: List[Dict[str, Any]] = []

        first_violation_uncut = None
        first_violation_cut = None
        max_violation_cut = 0.0

        for s in s_values:
            a_uncut = self.a0(s, cut=False)
            a_cut = self.a0(s, cut=True)

            viol_uncut = max(0.0, abs(a_uncut) - 0.5)
            viol_cut = max(0.0, abs(a_cut) - 0.5)

            if first_violation_uncut is None and viol_uncut > 0.0:
                first_violation_uncut = float(s)
            if first_violation_cut is None and viol_cut > 0.0:
                first_violation_cut = float(s)

            max_violation_cut = max(max_violation_cut, viol_cut)

            sample_points.append({
                "coordinates": {"s": float(s)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "Scattering proxy (no spacetime curvature).",
                },
                "local_observables": {
                    "a0_uncut": finite_or_none(a_uncut),
                    "a0_cut": finite_or_none(a_cut),
                    "unitarity_bound": 0.5,
                    "violation_uncut": finite_or_none(viol_uncut),
                    "violation_cut": finite_or_none(viol_cut),
                },
                "causal_structure": {
                    "note": "Hard cutoffs/truncations can violate optical theorem/unitarity bounds at high energy.",
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): S-matrix unitarity bound vs hard cutoff",
            "spacetime": "Minkowski scattering (partial-wave proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "Lambda": self.Lambda,
                "c": self.c,
                "Lambda_cut": self.Lambda_cut,
                "delta_cutoff_mismatch": self.delta,
                "unitarity_bound": "|a0| <= 1/2 (elastic proxy)",
                "s_samples": s_values,
            },
            "notes": {
                "pressure_point": (
                    "Unitarity can be violated by inconsistent regulation/truncation. "
                    "Partial-wave bounds give a sharp diagnostic for when an effective amplitude stops being physical."
                ),
                "amplitude": "A(s)=(s/Λ^2)(1+c s/Λ^2),  a0=A/(16π),  A_cut=A*(1+δ Θ(s-Λ_cut^2))",
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "first_s_violation_uncut": finite_or_none(first_violation_uncut) if first_violation_uncut is not None else None,
                    "first_s_violation_cut": finite_or_none(first_violation_cut) if first_violation_cut is not None else None,
                    "max_violation_cut_over_samples": finite_or_none(max_violation_cut),
                }
            },
        }

    def export_json(self, s_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(s_values=s_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 076: partial-wave unitarity violation from hard cutoff proxy.")
    ap.add_argument("--Lambda", type=float, default=10.0, help="EFT scale Λ")
    ap.add_argument("--c", type=float, default=0.25, help="Higher-order growth coefficient")
    ap.add_argument("--Lambda_cut", type=float, default=8.0, help="Hard cutoff scale Λ_cut")
    ap.add_argument("--delta", type=float, default=0.5, help="Cutoff mismatch strength δ")
    ap.add_argument("--s", type=str, default="1,4,9,16,25,36,49,64,81,100,121,144,169,196",
                    help="Comma-separated s values to scan")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    s_vals = parse_csv_floats(args.s)
    toy = Toy076SMatrixUnitarityViolationHardCutoff(
        Lambda=float(args.Lambda),
        c=float(args.c),
        Lambda_cut=float(args.Lambda_cut),
        delta=float(args.delta),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(s_values=s_vals, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
