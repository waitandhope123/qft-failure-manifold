#!/usr/bin/env python3
"""
Toy 094 — RG scheme dependence: fixed point vs limit cycle (universality boundary proxy)

What it probes (pressure point):
- RG flow features (fixed points, cycles) can be scheme-dependent when non-universal terms matter.
- "Universality" emerges only in restricted observables/limits; outside those, qualitative behavior can change.
- Demonstrates how two legitimate reparameterizations/schemes can disagree on the global phase portrait.

Model (deterministic):
- 2-coupling flow (g, h) with a "universal core" plus scheme term:
    dg/dl = -g^3 + b g h
    dh/dl = -h^3 - b g h

  This core has flows toward the origin for small couplings.

- Add scheme-dependent rotational term S * ( -h, +g ) which preserves radius but changes angles:
    (dg/dl, dh/dl) += S * ( -h, +g )

  This term can induce apparent limit-cycle-like behavior in (g,h) trajectories in one scheme.

- Compare two schemes:
  * scheme_A: S = 0          (no rotational term)
  * scheme_B: S = S0 * f(r)  (rotation present at moderate r), with f(r)=r^2/(1+r^2)

Diagnostics:
- Integrate ODE deterministically from identical initial conditions and compare:
  * convergence to fixed point (r -> 0)
  * angular winding number over finite RG time
  * "cycle proxy": large winding with slowly changing radius

Outputs:
- For each initial condition:
  * final radius, final angle
  * total winding in scheme_A and scheme_B
  * qualitative classification per scheme: fixed_point_like vs cycle_like

Determinism:
- Fixed-step RK4; no randomness.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def parse_pairs(s: str) -> List[Tuple[float, float]]:
    """
    Parse "g:h,g:h,..." into list of (g,h)
    """
    out: List[Tuple[float, float]] = []
    for part in s.split(","):
        part = part.strip()
        if not part:
            continue
        if ":" not in part:
            raise ValueError("Initial conditions must be g:h pairs.")
        g, h = part.split(":")
        out.append((float(g), float(h)))
    return out


# ----------------------------
# Toy 094
# ----------------------------

class Toy094RGSchemeDependenceFixedPointVsCycle:
    toy_id = "094"

    def __init__(
        self,
        *,
        b: float = 0.8,
        S0: float = 1.6,
        dl: float = 1e-3,
        l_max: float = 8.0,
        cycle_winding_min: float = 1.0,
        cycle_radius_drift_max: float = 0.15,
    ) -> None:
        require(dl > 0.0, "dl must be > 0.")
        require(l_max > 0.0, "l_max must be > 0.")
        require(cycle_winding_min >= 0.0, "cycle_winding_min must be >= 0.")
        require(cycle_radius_drift_max > 0.0, "cycle_radius_drift_max must be > 0.")
        self.b = float(b)
        self.S0 = float(S0)
        self.dl = float(dl)
        self.l_max = float(l_max)
        self.cycle_winding_min = float(cycle_winding_min)
        self.cycle_radius_drift_max = float(cycle_radius_drift_max)

    def _core_flow(self, g: float, h: float) -> Tuple[float, float]:
        dg = -(g ** 3) + self.b * g * h
        dh = -(h ** 3) - self.b * g * h
        return dg, dh

    def _scheme_rotation(self, g: float, h: float, scheme: str) -> Tuple[float, float]:
        if scheme == "scheme_A":
            return 0.0, 0.0
        # scheme_B: rotation active at moderate r
        r2 = g * g + h * h
        f = r2 / (1.0 + r2)
        S = self.S0 * f
        # rotational field: (-h, +g)
        return -S * h, S * g

    def flow(self, g: float, h: float, scheme: str) -> Tuple[float, float]:
        dg, dh = self._core_flow(g, h)
        rg, rh = self._scheme_rotation(g, h, scheme)
        return dg + rg, dh + rh

    def rk4_step(self, g: float, h: float, scheme: str) -> Tuple[float, float]:
        dl = self.dl

        k1g, k1h = self.flow(g, h, scheme)
        k2g, k2h = self.flow(g + 0.5 * dl * k1g, h + 0.5 * dl * k1h, scheme)
        k3g, k3h = self.flow(g + 0.5 * dl * k2g, h + 0.5 * dl * k2h, scheme)
        k4g, k4h = self.flow(g + dl * k3g, h + dl * k3h, scheme)

        g2 = g + (dl / 6.0) * (k1g + 2.0 * k2g + 2.0 * k3g + k4g)
        h2 = h + (dl / 6.0) * (k1h + 2.0 * k2h + 2.0 * k3h + k4h)
        return g2, h2

    def integrate(self, g0: float, h0: float, scheme: str) -> Dict[str, Any]:
        steps = int(self.l_max / self.dl)
        g, h = float(g0), float(h0)

        r0 = math.sqrt(g * g + h * h)
        theta_prev = math.atan2(h, g)
        winding = 0.0

        r_min = r0
        r_max = r0

        for _ in range(steps):
            g, h = self.rk4_step(g, h, scheme)

            r = math.sqrt(g * g + h * h)
            r_min = min(r_min, r)
            r_max = max(r_max, r)

            theta = math.atan2(h, g)
            dtheta = theta - theta_prev
            # unwrap
            while dtheta > math.pi:
                dtheta -= 2.0 * math.pi
            while dtheta < -math.pi:
                dtheta += 2.0 * math.pi
            winding += dtheta / (2.0 * math.pi)
            theta_prev = theta

        r_final = math.sqrt(g * g + h * h)
        theta_final = math.atan2(h, g)

        radius_drift = None
        if r0 > 0.0:
            radius_drift = abs(r_final - r0) / r0

        # classification
        # cycle-like if significant winding and radius does not drift much
        cycle_like = (
            abs(winding) >= self.cycle_winding_min
            and (radius_drift is not None)
            and (radius_drift <= self.cycle_radius_drift_max)
        )
        fixed_point_like = (r_final < 0.05)

        return {
            "g_final": finite_or_none(g),
            "h_final": finite_or_none(h),
            "r_initial": finite_or_none(r0),
            "r_final": finite_or_none(r_final),
            "r_min": finite_or_none(r_min),
            "r_max": finite_or_none(r_max),
            "theta_final": finite_or_none(theta_final),
            "winding_number": finite_or_none(winding),
            "radius_drift_fraction": finite_or_none(radius_drift) if radius_drift is not None else None,
            "classification": "cycle_like" if cycle_like else ("fixed_point_like" if fixed_point_like else "flow_like"),
        }

    def build_payload(self, initials: List[Tuple[float, float]]) -> Dict[str, Any]:
        require(len(initials) >= 2, "Provide at least two initial conditions.")
        sample_points: List[Dict[str, Any]] = []

        disagreements = 0

        for (g0, h0) in initials:
            resA = self.integrate(g0, h0, "scheme_A")
            resB = self.integrate(g0, h0, "scheme_B")

            if resA["classification"] != resB["classification"]:
                disagreements += 1

            sample_points.append({
                "coordinates": {"g0": float(g0), "h0": float(h0)},
                "curvature_invariants": {
                    "ricci_scalar": None,
                    "kretschmann": None,
                    "note": "RG flow portrait proxy; no spacetime curvature.",
                },
                "local_observables": {
                    "scheme_A": resA,
                    "scheme_B": resB,
                    "classification_disagrees": (resA["classification"] != resB["classification"]),
                },
                "causal_structure": {
                    "note": (
                        "Qualitative RG behavior (fixed point vs cycle-like winding) can depend on scheme/reparameterization "
                        "when non-universal terms are relevant."
                    ),
                },
            })

        frac = None if len(initials) == 0 else disagreements / len(initials)

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): RG scheme dependence (fixed point vs limit-cycle proxy)",
            "spacetime": "Coupling space (g,h) with RG time l",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "b_core_coupling": self.b,
                "S0_scheme_rotation_strength": self.S0,
                "dl_step": self.dl,
                "l_max": self.l_max,
                "cycle_winding_min": self.cycle_winding_min,
                "cycle_radius_drift_max": self.cycle_radius_drift_max,
                "initial_conditions": [{"g0": g0, "h0": h0} for (g0, h0) in initials],
                "schemes": ["scheme_A", "scheme_B"],
            },
            "notes": {
                "pressure_point": (
                    "RG universality is limited: global flow features can be scheme-dependent. "
                    "Two legitimate schemes can disagree on qualitative portraits (cycle-like vs fixed-point-like) "
                    "outside the universal regime."
                ),
                "schemes": {
                    "scheme_A": "core flow only",
                    "scheme_B": "core flow + rotational (scheme) term S(r)(-h,+g), S(r)=S0*r^2/(1+r^2)",
                },
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "n_initial_conditions": len(initials),
                    "n_classification_disagreements": disagreements,
                    "fraction_disagree": finite_or_none(frac),
                }
            },
        }

    def export_json(self, initials: List[Tuple[float, float]], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(initials=initials)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 094: RG scheme dependence (fixed point vs cycle proxy).")
    ap.add_argument("--b", type=float, default=0.8, help="Core coupling parameter b")
    ap.add_argument("--S0", type=float, default=1.6, help="Scheme rotation strength S0")
    ap.add_argument("--dl", type=float, default=1e-3, help="RG time step")
    ap.add_argument("--l_max", type=float, default=8.0, help="RG time extent")
    ap.add_argument("--cycle_winding_min", type=float, default=1.0, help="Min winding for cycle_like")
    ap.add_argument("--cycle_radius_drift_max", type=float, default=0.15, help="Max radius drift for cycle_like")
    ap.add_argument("--initials", type=str, default="0.6:0.2,0.4:0.7,0.8:0.6,0.3:0.3,1.0:0.1",
                    help="Comma-separated initial g:h pairs, e.g. '0.6:0.2,0.4:0.7'")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    initials = parse_pairs(args.initials)

    toy = Toy094RGSchemeDependenceFixedPointVsCycle(
        b=float(args.b),
        S0=float(args.S0),
        dl=float(args.dl),
        l_max=float(args.l_max),
        cycle_winding_min=float(args.cycle_winding_min),
        cycle_radius_drift_max=float(args.cycle_radius_drift_max),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(initials=initials, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
