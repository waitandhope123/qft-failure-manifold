#!/usr/bin/env python3
"""
Toy 017 — Locality vs energy positivity (quantum energy inequality stress test)

Pressure point:
- Local energy density can be negative in QFT.
- Negativity is constrained but not forbidden (quantum inequalities).
- Classical energy conditions fail even in flat spacetime.

This toy is intentionally GR-style heavy:
- two independent diagnostics
- explicit regime classification
- clear failure flags

Model:
- Free real scalar field in 1+1D
- Gaussian-smeared energy density operator
- Compare instantaneous energy density vs averaged (QI-respecting) bound

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


# ----------------------------
# Toy 017
# ----------------------------

class Toy017QuantumEnergyInequality:
    toy_id = "017"

    def __init__(
        self,
        *,
        mass: float = 1.0,
        smearing_times: List[float] = [0.2, 0.5, 1.0, 2.0],
        negative_pulse_strength: float = 1.0,
    ) -> None:
        self.m = float(mass)
        self.taus = [float(t) for t in smearing_times]
        self.A = float(negative_pulse_strength)

    def instantaneous_energy_density(self) -> float:
        """
        Proxy for a localized negative-energy pulse.
        """
        return -self.A

    def averaged_energy_density(self, tau: float) -> float:
        """
        Quantum inequality proxy:
        ⟨ρ⟩_τ ≥ -C / τ^2
        """
        C = 0.25
        return max(self.instantaneous_energy_density(), -C / (tau * tau))

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        inst = self.instantaneous_energy_density()

        for tau in self.taus:
            avg = self.averaged_energy_density(tau)

            sample_points.append({
                "coordinates": {
                    "smearing_time_tau": tau,
                },
                "curvature_invariants": {
                    "energy_condition": "classical_violation",
                },
                "local_observables": {
                    "instantaneous_energy_density": inst,
                    "averaged_energy_density": avg,
                },
                "causal_structure": {
                    "local_negative_energy": inst < 0.0,
                    "qi_respected": avg >= -0.25 / (tau * tau),
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "mass": self.m,
                "negative_pulse_strength": self.A,
                "smearing_times": self.taus,
            },
            "notes": {
                "assumptions": [
                    "Free real scalar field",
                    "Gaussian time smearing",
                    "Energy density treated as operator-valued distribution",
                ],
                "pressure_point": (
                    "Classical energy conditions fail in QFT. "
                    "Negative energy exists but is constrained by quantum inequalities."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "classical_energy_condition_violated": True,
                    "arbitrary_negative_energy_forbidden": True,
                    "locality_requires_smearing": True,
                },
                "regime_classification": {
                    "pointlike_measurement": "ill_defined",
                    "smeared_measurement": "bounded_negative_energy",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# Main
# ----------------------------

def main() -> None:
    Toy017QuantumEnergyInequality().export_json()


if __name__ == "__main__":
    main()
