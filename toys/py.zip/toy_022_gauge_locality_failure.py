#!/usr/bin/env python3
"""
Toy 022 — Gauge redundancy vs local observables (Gauss-law obstruction)

Pressure point:
- In gauge theories, strictly local gauge-invariant operators do not exist.
- Physical observables are inherently nonlocal (Gauss law constraints).
- Subregion physics depends on boundary data and dressing choices.

GR-style heavy:
- dual diagnostics
- explicit failure flags
- regime classification

Model:
- U(1) gauge field in 1+1D (toy / proxy)
- Compare bare charged field vs gauge-invariant dressed operator
- Diagnose nonlocality length scale and boundary dependence

Units: ħ = c = 1
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


class Toy022GaugeLocalityFailure:
    toy_id = "022"

    def __init__(
        self,
        *,
        separation_x: float = 1.0,
        dressing_lengths: List[float] = [0.5, 1.0, 2.0, 5.0],
        charge: float = 1.0,
    ) -> None:
        self.x = float(separation_x)
        self.ds = [float(d) for d in dressing_lengths]
        self.q = float(charge)

    def bare_operator_gauge_invariant(self) -> bool:
        # Charged local field is not gauge invariant
        return False

    def dressing_nonlocal_extent(self, dressing_length: float) -> float:
        """
        Proxy: physical operator extends over dressing length.
        """
        return dressing_length

    def boundary_flux_proxy(self, dressing_length: float) -> float:
        """
        Independent diagnostic:
        Gauss-law flux through boundary scales with charge.
        """
        return self.q / max(dressing_length, 1e-6)

    def build_payload(self) -> Dict[str, Any]:
        sample_points: List[Dict[str, Any]] = []

        for d in self.ds:
            extent = self.dressing_nonlocal_extent(d)
            flux = self.boundary_flux_proxy(d)

            sample_points.append({
                "coordinates": {
                    "dressing_length": d,
                    "separation_x": self.x,
                },
                "curvature_invariants": {
                    "gauss_law_constraint": True,
                },
                "local_observables": {
                    "bare_operator_gauge_invariant": self.bare_operator_gauge_invariant(),
                    "dressed_operator_extent": extent,
                    "boundary_flux_proxy": flux,
                },
                "causal_structure": {
                    "strict_local_operator_exists": False,
                },
            })

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (Gauge)",
            "spacetime": "Flat Minkowski (1+1D)",
            "units": {"hbar": 1, "c": 1},
            "parameters": {
                "charge": self.q,
                "dressing_lengths": self.ds,
                "separation_x": self.x,
            },
            "notes": {
                "assumptions": [
                    "U(1) gauge theory",
                    "Gauss-law constraint enforced",
                    "Gauge-invariant operators require dressing",
                ],
                "pressure_point": (
                    "Gauge redundancy forbids strictly local charged observables. "
                    "Physical operators are necessarily nonlocal and boundary-sensitive."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "failure_flags": {
                    "strict_local_gauge_observable": False,
                    "subsystem_independence": False,
                },
                "regime_classification": {
                    "short_dressing": "large_boundary_flux",
                    "long_dressing": "delocalized_operator",
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    Toy022GaugeLocalityFailure().export_json()


if __name__ == "__main__":
    main()
