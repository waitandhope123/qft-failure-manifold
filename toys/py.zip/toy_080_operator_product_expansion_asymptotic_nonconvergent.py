#!/usr/bin/env python3
"""
Toy 080 — OPE is asymptotic/nonconvergent (noncommuting limits / locality expansion boundary)

What it probes (pressure point):
- The operator product expansion (OPE) is often treated like a convergent expansion, but in many
  settings it is only asymptotic: truncation error initially decreases with more terms, then grows.
- This mirrors GR "series solutions" / near-horizon expansions that are locally valid but globally
  misleading, and it gives a QFT-native noncommuting-limits boundary.

Model (controlled, deterministic, Borel-type):
- Use a known asymptotic series with factorial growth:
    F(x) ~ Σ_{n=0}^∞ (-1)^n n! x^n   (diverges for any x != 0)
- Interpret as an OPE-like local expansion parameter x ~ (|x12|/L)^Δ.
- Define "exact" function by Borel summation:
    F_exact(x) = ∫_0^∞ dt e^{-t} / (1 + x t)
  (for x>0, this equals the Borel sum of the series above)
- Compare truncated partial sums S_N(x) to F_exact(x) as N varies.
- Show optimal truncation N* ~ 1/x and nonmonotonic error vs N.

Diagnostics:
- For each x:
  * compute errors |S_N - F_exact| for N in [0..Nmax]
  * report N_opt that minimizes error and the minimal error
  * show that adding more terms past N_opt worsens prediction

Export:
- Strict lab JSON schema.
- Writes <script_name>.json

Determinism:
- No randomness.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def parse_csv_floats(s: str) -> List[float]:
    return [float(x.strip()) for x in s.split(",") if x.strip()]


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


def borel_sum_exact(x: float) -> float:
    """
    F_exact(x) = ∫_0^∞ dt e^{-t} / (1 + x t)
    Evaluate by numerical quadrature on [0, T] with tail bound.
    Deterministic composite Simpson.
    """
    require(x > 0.0, "x must be > 0.")
    # choose cutoff where e^{-t} is tiny
    T = 40.0
    n = 20000
    if n % 2 == 1:
        n += 1
    a = 0.0
    b = T
    h = (b - a) / n

    def f(t: float) -> float:
        return math.exp(-t) / (1.0 + x * t)

    s = f(a) + f(b)
    for i in range(1, n):
        t = a + i * h
        s += (4.0 if i % 2 == 1 else 2.0) * f(t)
    val = s * (h / 3.0)

    # tail estimate <= ∫_T^∞ e^{-t} dt = e^{-T}
    return val  # e^{-40} is negligible


def partial_sum(x: float, N: int) -> float:
    """
    S_N(x) = Σ_{n=0}^N (-1)^n n! x^n
    """
    require(N >= 0, "N must be >= 0.")
    term = 1.0  # n=0: 0! x^0
    s = term
    for n in range(1, N + 1):
        term *= -n * x  # from (n-1)! x^(n-1) to (-1)^n n! x^n
        s += term
    return s


# ----------------------------
# Toy 080
# ----------------------------

class Toy080OPEAsymptoticNonconvergent:
    toy_id = "080"

    def __init__(self, *, Nmax: int = 40) -> None:
        require(Nmax >= 10, "Nmax must be >= 10.")
        self.Nmax = int(Nmax)

    def build_payload(self, x_values: List[float]) -> Dict[str, Any]:
        require(len(x_values) >= 1, "Need x samples.")
        require(all(x > 0.0 for x in x_values), "All x must be > 0.")

        sample_points: List[Dict[str, Any]] = []
        summaries: Dict[str, Any] = {}

        for x in x_values:
            F = borel_sum_exact(float(x))

            errors = []
            for N in range(self.Nmax + 1):
                SN = partial_sum(float(x), N)
                err = abs(SN - F)
                errors.append(err)

                sample_points.append({
                    "coordinates": {"x": float(x), "N_trunc": int(N)},
                    "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Series/OPE toy; no curvature."},
                    "local_observables": {
                        "S_N": finite_or_none(SN),
                        "F_exact_borel": finite_or_none(F),
                        "abs_error": finite_or_none(err),
                    },
                    "causal_structure": {"note": "OPE-like series is asymptotic: optimal truncation exists; more terms can worsen."},
                })

            Nopt = int(np.argmin(np.array(errors)))
            emin = float(errors[Nopt])
            summaries[str(x)] = {
                "F_exact": finite_or_none(F),
                "N_opt": Nopt,
                "min_error": finite_or_none(emin),
                "error_at_Nmax": finite_or_none(float(errors[self.Nmax])),
                "nonmonotonic": bool(any(errors[i+1] > errors[i] for i in range(len(errors)-1))),
                "rule_of_thumb_Nstar_approx": finite_or_none(1.0 / float(x)),
            }

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): OPE as asymptotic expansion (factorial divergence)",
            "spacetime": "Local operator expansion parameter x>0 (dimensionless)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "x_samples": x_values,
                "Nmax": self.Nmax,
                "series": "F ~ Σ (-1)^n n! x^n",
                "borel_sum_exact": "F_exact=∫_0^∞ dt e^{-t}/(1+x t)",
            },
            "notes": {
                "pressure_point": (
                    "Truncated local expansions (OPE-like) can be asymptotic: adding more terms past an optimal truncation "
                    "worsens accuracy. This is a clean noncommuting-limits boundary between 'local series control' and "
                    "'global predictivity'."
                ),
            },
            "sample_points": sample_points,
            "observables": {"summary": summaries},
        }

    def export_json(self, x_values: List[float], out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(x_values=x_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 080: OPE asymptotic/nonconvergent truncation boundary.")
    ap.add_argument("--x", type=str, default="0.02,0.05,0.1,0.2,0.3",
                    help="Comma-separated x values (>0)")
    ap.add_argument("--Nmax", type=int, default=40, help="Max truncation order")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    x_values = parse_csv_floats(args.x)
    toy = Toy080OPEAsymptoticNonconvergent(Nmax=int(args.Nmax))

    out_path = args.out.strip() or None
    json_path = toy.export_json(x_values=x_values, out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
