#!/usr/bin/env python3
"""
Toy 052 — Non-additivity of entanglement under naive region splitting

Pressure point:
- Entanglement is not additive under naive spatial decomposition.
- Subsystem “factorization” assumptions fail (proxy for Type III / boundary terms).
- Even in finite systems, entanglement bookkeeping depends on how you define subsystems.

Model:
- Four-qubit system split into regions:
    Region R = {A,B}, Complement = {C,D}
- Compare:
    S(R) vs S(A)+S(B) (generally not equal)
- Uses von Neumann entropy.

Units: ℏ = 1
"""

from __future__ import annotations

import json
import math
import os
import numpy as np
from typing import Any, Dict, List


def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def von_neumann_entropy(rho: np.ndarray) -> float:
    vals = np.linalg.eigvalsh(rho)
    vals = vals[vals > 1e-12]
    return float(-np.sum(vals * np.log(vals)))


def partial_trace(rho: np.ndarray, keep: List[int], n_qubits: int) -> np.ndarray:
    dims = [2] * n_qubits
    rho = rho.reshape(dims + dims)

    trace_out = sorted(
        [i for i in range(n_qubits) if i not in keep],
        reverse=True
    )

    current_n = n_qubits
    for i in trace_out:
        rho = np.trace(rho, axis1=i, axis2=i + current_n)
        current_n -= 1

    dim = 2 ** len(keep)
    return rho.reshape((dim, dim))


class Toy052EntanglementNonAdditivity:
    toy_id = "052"

    def build_payload(self) -> Dict[str, Any]:
        zero = np.array([1, 0], dtype=complex)
        one = np.array([0, 1], dtype=complex)

        ab00 = np.kron(zero, zero)
        ab11 = np.kron(one, one)
        cd00 = np.kron(zero, zero)
        cd11 = np.kron(one, one)

        psi = (np.kron(ab00, cd00) + np.kron(ab11, cd11)) / math.sqrt(2.0)
        rho = np.outer(psi, psi.conj())

        rho_ab = partial_trace(rho, keep=[0, 1], n_qubits=4)
        rho_a = partial_trace(rho, keep=[0], n_qubits=4)
        rho_b = partial_trace(rho, keep=[1], n_qubits=4)

        S_ab = von_neumann_entropy(rho_ab)
        S_a = von_neumann_entropy(rho_a)
        S_b = von_neumann_entropy(rho_b)

        sample_points = [{
            "coordinates": {"region": "AB"},
            "curvature_invariants": {"analogy": None},
            "local_observables": {
                "S(AB)": S_ab,
                "S(A)": S_a,
                "S(B)": S_b,
                "S(A)+S(B)-S(AB)": (S_a + S_b - S_ab),
            },
            "causal_structure": {
                "note": "Entanglement not additive under naive splitting"
            },
        }]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (factorization failure proxy)",
            "spacetime": "Four-qubit system",
            "units": {"hbar": 1},
            "parameters": {},
            "notes": {},
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "non_additivity_gap":
                        sample_points[0]["local_observables"]["S(A)+S(B)-S(AB)"]
                }
            },
        }

    def export_json(self, out_path: str | None = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(self.build_payload(), f, indent=2, sort_keys=True)
        return out_path


def main() -> None:
    toy = Toy052EntanglementNonAdditivity()
    path = toy.export_json()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
