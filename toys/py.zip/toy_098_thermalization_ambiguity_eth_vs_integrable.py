#!/usr/bin/env python3
"""
Toy 098 — Thermalization ambiguity boundary: ETH-like vs integrable dynamics (Loschmidt + entropy)

What it probes (pressure point):
- "Thermalization" in QFT-like many-body systems depends on dynamics class (chaotic vs integrable),
  coarse-graining choice, and finite-size / cutoff effects.
- Even with identical initial energies, observables can:
  * relax (ETH-like) or fail to relax (integrable)
  * exhibit recurrences / large Loschmidt echoes
- Quantifies boundaries using deterministic spin-chain models.

Model (deterministic, small system):
- Two 1D spin-1/2 chains of length L (default 8):
  * Chaotic: transverse+longitudinal fields (nonintegrable):
      H_ch = Σ J σ^z_i σ^z_{i+1} + hx σ^x_i + hz σ^z_i
      with hx,hz both nonzero.
  * Integrable: transverse-field Ising (integrable):
      H_int = Σ J σ^z_i σ^z_{i+1} + hx σ^x_i
      with hz=0.

- Start from a product state |ψ0> (Neel-like).
- Time evolve exactly by diagonalization:
    |ψ(t)> = exp(-i H t) |ψ0>

Diagnostics (per model):
- Loschmidt echo: L(t) = |<ψ0|ψ(t)>|^2
- Single-site magnetization average: m_z(t) = (1/L) Σ <σ^z_i>
- Half-chain entanglement entropy S_half(t) (von Neumann entropy of reduced density on first L/2 spins)
- "Thermalization proxy" over a late-time window:
    variance of m_z(t) and S_half(t)  (smaller variance = more equilibration)

Determinism:
- No randomness; exact diagonalization.

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows canonical lab schema. Undefined quantities are null.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"

def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)

def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None

def dagger(M: np.ndarray) -> np.ndarray:
    return np.conjugate(M.T)

def kronN(ops: List[np.ndarray]) -> np.ndarray:
    out = ops[0]
    for o in ops[1:]:
        out = np.kron(out, o)
    return out

def von_neumann_entropy(rho: np.ndarray, eps: float = 1e-15) -> float:
    rhoH = 0.5 * (rho + dagger(rho))
    vals = np.linalg.eigvalsh(rhoH).real
    vals = np.maximum(vals, 0.0)
    vals = vals / (np.sum(vals) + eps)
    s = 0.0
    for lam in vals:
        if lam > eps:
            s -= float(lam) * math.log(float(lam))
    return s

def partial_trace_pure_state(psi: np.ndarray, keep: List[int], dims: List[int]) -> np.ndarray:
    """
    Reduced density matrix from a pure state vector psi on tensor dims.
    keep: subsystem indices to keep.
    """
    n = len(dims)
    keep = sorted(keep)
    trace_out = [i for i in range(n) if i not in keep]

    psi_t = psi.reshape(dims)
    # move kept indices to front
    perm = keep + trace_out
    psi_perm = np.transpose(psi_t, axes=perm)
    d_keep = int(np.prod([dims[i] for i in keep]))
    d_out = int(np.prod([dims[i] for i in trace_out]))
    psi_mat = psi_perm.reshape(d_keep, d_out)
    rho = psi_mat @ dagger(psi_mat)
    return rho


# ----------------------------
# Pauli matrices
# ----------------------------

I2 = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Z = np.array([[1, 0], [0, -1]], dtype=complex)


def op_on_site(op: np.ndarray, site: int, L: int) -> np.ndarray:
    ops = [I2] * L
    ops[site] = op
    return kronN(ops)

def op_on_bond(op1: np.ndarray, i: int, op2: np.ndarray, j: int, L: int) -> np.ndarray:
    ops = [I2] * L
    ops[i] = op1
    ops[j] = op2
    return kronN(ops)


# ----------------------------
# Toy 098
# ----------------------------

class Toy098ThermalizationAmbiguityETHvsIntegrable:
    toy_id = "098"

    def __init__(
        self,
        *,
        L: int = 8,
        J: float = 1.0,
        hx: float = 1.05,
        hz_chaotic: float = 0.5,
        t_max: float = 8.0,
        n_t: int = 161,
        late_frac: float = 0.35,
    ) -> None:
        require(L >= 4 and L <= 10, "Keep L between 4 and 10 for exact diagonalization sanity.")
        require(n_t >= 41, "n_t should be >= 41.")
        require(t_max > 0.0, "t_max must be > 0.")
        require(0.1 <= late_frac <= 0.9, "late_frac should be a sensible fraction.")
        self.L = int(L)
        self.J = float(J)
        self.hx = float(hx)
        self.hz_chaotic = float(hz_chaotic)
        self.t_max = float(t_max)
        self.n_t = int(n_t)
        self.late_frac = float(late_frac)

        self.dims = [2] * self.L
        self.times = np.linspace(0.0, self.t_max, self.n_t)

        self.H_int = self.build_hamiltonian(hz=0.0)
        self.H_ch = self.build_hamiltonian(hz=self.hz_chaotic)

        # initial state: Neel |0101...>
        self.psi0 = self.neel_state()

        # diagonalize once
        self.eval_int, self.evec_int = np.linalg.eigh(self.H_int)
        self.eval_ch, self.evec_ch = np.linalg.eigh(self.H_ch)

        # precompute operators for m_z
        self.Z_ops = [op_on_site(Z, i, self.L) for i in range(self.L)]
        self.Z_avg = sum(self.Z_ops) / float(self.L)

    def build_hamiltonian(self, hz: float) -> np.ndarray:
        H = np.zeros((2 ** self.L, 2 ** self.L), dtype=complex)
        # periodic boundary
        for i in range(self.L):
            j = (i + 1) % self.L
            H += self.J * op_on_bond(Z, i, Z, j, self.L)
        for i in range(self.L):
            H += self.hx * op_on_site(X, i, self.L)
            if hz != 0.0:
                H += float(hz) * op_on_site(Z, i, self.L)
        return H

    def neel_state(self) -> np.ndarray:
        # |0101...> in computational basis where |0> is up (+1 eigen of Z), |1> is down (-1)
        idx = 0
        for i in range(self.L):
            bit = (i % 2)  # 0,1,0,1...
            idx = (idx << 1) | bit
        psi = np.zeros((2 ** self.L,), dtype=complex)
        psi[idx] = 1.0 + 0.0j
        return psi

    def evolve(self, evals: np.ndarray, evecs: np.ndarray, t: float) -> np.ndarray:
        # psi(t) = V exp(-i E t) V^† psi0
        coeff = dagger(evecs) @ self.psi0
        phase = np.exp(-1j * evals * t)
        return evecs @ (phase * coeff)

    def loschmidt(self, psi_t: np.ndarray) -> float:
        amp = np.vdot(self.psi0, psi_t)
        return float((abs(amp) ** 2).real)

    def mz(self, psi_t: np.ndarray) -> float:
        val = np.vdot(psi_t, self.Z_avg @ psi_t)
        return float(val.real)

    def half_entropy(self, psi_t: np.ndarray) -> float:
        Lh = self.L // 2
        rho_half = partial_trace_pure_state(psi_t, keep=list(range(Lh)), dims=self.dims)
        return float(von_neumann_entropy(rho_half))

    def run_model(self, name: str, evals: np.ndarray, evecs: np.ndarray) -> Dict[str, Any]:
        Ls: List[float] = []
        mzs: List[float] = []
        Ss: List[float] = []

        for t in self.times:
            psi_t = self.evolve(evals, evecs, float(t))
            Ls.append(self.loschmidt(psi_t))
            mzs.append(self.mz(psi_t))
            Ss.append(self.half_entropy(psi_t))

        # late-time window statistics
        i0 = int((1.0 - self.late_frac) * (self.n_t - 1))
        mz_late = np.array(mzs[i0:], dtype=float)
        S_late = np.array(Ss[i0:], dtype=float)

        return {
            "name": name,
            "times": [float(t) for t in self.times],
            "loschmidt_echo": [finite_or_none(x) for x in Ls],
            "mz": [finite_or_none(x) for x in mzs],
            "S_half": [finite_or_none(x) for x in Ss],
            "late_time_stats": {
                "late_start_time": float(self.times[i0]),
                "mz_mean": finite_or_none(float(np.mean(mz_late))),
                "mz_var": finite_or_none(float(np.var(mz_late))),
                "S_half_mean": finite_or_none(float(np.mean(S_late))),
                "S_half_var": finite_or_none(float(np.var(S_late))),
                "loschmidt_min": finite_or_none(float(np.min(Ls[i0:]))),
                "loschmidt_max": finite_or_none(float(np.max(Ls[i0:]))),
            },
        }

    def build_payload(self) -> Dict[str, Any]:
        res_int = self.run_model("integrable_TFIM", self.eval_int, self.evec_int)
        res_ch = self.run_model("chaotic_nonintegrable", self.eval_ch, self.evec_ch)

        # thermalization proxy: lower late-time variance in chaotic vs integrable
        mz_var_int = res_int["late_time_stats"]["mz_var"]
        mz_var_ch = res_ch["late_time_stats"]["mz_var"]
        S_var_int = res_int["late_time_stats"]["S_half_var"]
        S_var_ch = res_ch["late_time_stats"]["S_half_var"]

        sample_points = [
            {
                "coordinates": {"model": "integrable_TFIM"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Finite spin chain toy."},
                "local_observables": res_int["late_time_stats"],
                "causal_structure": {"note": "Integrable dynamics: recurrences and non-thermal relaxation are common."},
            },
            {
                "coordinates": {"model": "chaotic_nonintegrable"},
                "curvature_invariants": {"ricci_scalar": None, "kretschmann": None, "note": "Finite spin chain toy."},
                "local_observables": res_ch["late_time_stats"],
                "causal_structure": {"note": "Chaotic dynamics: ETH-like equilibration with suppressed fluctuations."},
            },
        ]

        return {
            "toy_id": self.toy_id,
            "theory": "Quantum Field Theory (toy): thermalization ambiguity boundary (ETH vs integrable)",
            "spacetime": "1D spin chain (finite-size QFT proxy)",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "L": self.L,
                "J": self.J,
                "hx": self.hx,
                "hz_chaotic": self.hz_chaotic,
                "t_max": self.t_max,
                "n_t": self.n_t,
                "late_frac": self.late_frac,
                "initial_state": "Neel |0101...>",
                "models": {
                    "integrable_TFIM": "hz=0",
                    "chaotic_nonintegrable": "hz!=0",
                },
            },
            "notes": {
                "pressure_point": (
                    "Thermalization is not guaranteed: integrable and chaotic dynamics differ sharply. "
                    "Boundaries are operational and depend on coarse-graining, finite size, and time window."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "time_series": {
                    "integrable_TFIM": {
                        "times": res_int["times"],
                        "loschmidt_echo": res_int["loschmidt_echo"],
                        "mz": res_int["mz"],
                        "S_half": res_int["S_half"],
                    },
                    "chaotic_nonintegrable": {
                        "times": res_ch["times"],
                        "loschmidt_echo": res_ch["loschmidt_echo"],
                        "mz": res_ch["mz"],
                        "S_half": res_ch["S_half"],
                    },
                },
                "summary": {
                    "mz_var_integrable": mz_var_int,
                    "mz_var_chaotic": mz_var_ch,
                    "S_half_var_integrable": S_var_int,
                    "S_half_var_chaotic": S_var_ch,
                    "thermalization_proxy_supports_ETH": (
                        (mz_var_int is not None and mz_var_ch is not None and mz_var_ch < mz_var_int)
                        and (S_var_int is not None and S_var_ch is not None and S_var_ch < S_var_int)
                    ),
                },
            },
        }

    def export_json(self, out_path: Optional[str] = None) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload()
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    ap = argparse.ArgumentParser(description="Toy 098: ETH vs integrable thermalization boundary (deterministic).")
    ap.add_argument("--L", type=int, default=8, help="Chain length (4-10 recommended)")
    ap.add_argument("--J", type=float, default=1.0, help="Ising coupling J")
    ap.add_argument("--hx", type=float, default=1.05, help="Transverse field hx")
    ap.add_argument("--hz_chaotic", type=float, default=0.5, help="Longitudinal field for chaotic model")
    ap.add_argument("--t_max", type=float, default=8.0, help="Max time")
    ap.add_argument("--n_t", type=int, default=161, help="Number of time samples")
    ap.add_argument("--late_frac", type=float, default=0.35, help="Fraction of late-time window")
    ap.add_argument("--out", type=str, default="", help="Optional output path")
    args = ap.parse_args()

    toy = Toy098ThermalizationAmbiguityETHvsIntegrable(
        L=int(args.L),
        J=float(args.J),
        hx=float(args.hx),
        hz_chaotic=float(args.hz_chaotic),
        t_max=float(args.t_max),
        n_t=int(args.n_t),
        late_frac=float(args.late_frac),
    )

    out_path = args.out.strip() or None
    json_path = toy.export_json(out_path=out_path)
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
