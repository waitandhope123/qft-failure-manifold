#!/usr/bin/env python3
"""
Toy 083 — Failure-mode phase diagram (multi-axis comparator)

STRICT EXPORT RULE:
- Writes JSON named exactly like this .py file.
- JSON follows the canonical lab schema.
- Undefined quantities are exported as null.
"""

from __future__ import annotations

import json
import math
import os
from typing import Any, Dict, List, Optional


# ----------------------------
# Helpers
# ----------------------------

def py_to_json_name(py_path: str) -> str:
    return os.path.splitext(os.path.basename(py_path))[0] + ".json"


def require(cond: bool, msg: str) -> None:
    if not cond:
        raise ValueError(msg)


def finite_or_none(x: Any) -> Optional[float]:
    try:
        xf = float(x)
    except Exception:
        return None
    return xf if math.isfinite(xf) else None


# ----------------------------
# Toy 083
# ----------------------------

class Toy083FailureModePhaseDiagram:
    toy_id = "083"

    def __init__(
        self,
        *,
        cutoff_threshold: float = 0.3,
        coupling_threshold: float = 0.4,
        mixed_threshold: float = 0.55,
    ) -> None:
        require(cutoff_threshold > 0.0, "cutoff_threshold must be > 0.")
        require(coupling_threshold > 0.0, "coupling_threshold must be > 0.")
        require(mixed_threshold > 0.0, "mixed_threshold must be > 0.")

        self.cutoff_threshold = float(cutoff_threshold)
        self.coupling_threshold = float(coupling_threshold)
        self.mixed_threshold = float(mixed_threshold)

    # diagnostics
    def cutoff_metric(self, a: float) -> float:
        return a ** 2

    def coupling_metric(self, g: float) -> float:
        return g ** 1.5

    def mixed_metric(self, a: float, g: float) -> float:
        return math.sqrt(a * g)

    def build_payload(self, a_values: List[float], g_values: List[float]) -> Dict[str, Any]:
        require(len(a_values) >= 3, "Need multiple a samples.")
        require(len(g_values) >= 3, "Need multiple g samples.")
        require(all(a >= 0.0 for a in a_values), "a must be >= 0.")
        require(all(g >= 0.0 for g in g_values), "g must be >= 0.")

        sample_points: List[Dict[str, Any]] = []

        for a in a_values:
            for g in g_values:
                cm = self.cutoff_metric(a)
                gm = self.coupling_metric(g)
                mm = self.mixed_metric(a, g)

                cutoff_fail = cm >= self.cutoff_threshold
                coupling_fail = gm >= self.coupling_threshold
                mixed_fail = mm >= self.mixed_threshold

                sample_points.append({
                    "coordinates": {
                        "cutoff_strength": a,
                        "coupling_strength": g,
                    },
                    "curvature_invariants": {
                        "ricci_scalar": None,
                        "kretschmann": None,
                        "note": "Abstract phase diagram; no spacetime curvature.",
                    },
                    "local_observables": {
                        "cutoff_metric": finite_or_none(cm),
                        "coupling_metric": finite_or_none(gm),
                        "mixed_metric": finite_or_none(mm),
                        "cutoff_failure": cutoff_fail,
                        "coupling_failure": coupling_fail,
                        "mixed_failure": mixed_fail,
                    },
                    "causal_structure": {
                        "note": (
                            "Distinct approximation axes generate different failure regions; "
                            "mixed regimes exhibit new breakdown behavior."
                        ),
                    },
                })

        return {
            "toy_id": self.toy_id,
            "theory": "Meta: failure-mode phase diagram",
            "spacetime": "Abstract two-parameter space",
            "units": {"G": 1, "c": 1},
            "parameters": {
                "cutoff_threshold": self.cutoff_threshold,
                "coupling_threshold": self.coupling_threshold,
                "mixed_threshold": self.mixed_threshold,
                "cutoff_samples": a_values,
                "coupling_samples": g_values,
            },
            "notes": {
                "pressure_point": (
                    "Failure modes organize into phase regions when multiple approximation "
                    "controls are varied simultaneously; mixed regimes are not reducible "
                    "to single-axis limits."
                ),
            },
            "sample_points": sample_points,
            "observables": {
                "summary": {
                    "comment": "Use projections to visualize single-axis vs mixed failure regions."
                }
            },
        }

    def export_json(
        self,
        a_values: List[float],
        g_values: List[float],
        out_path: Optional[str] = None,
    ) -> str:
        if out_path is None:
            out_path = py_to_json_name(__file__)
        payload = self.build_payload(a_values=a_values, g_values=g_values)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
        return out_path


# ----------------------------
# CLI
# ----------------------------

def main() -> None:
    a_values = [i / 20.0 for i in range(0, 21)]
    g_values = [i / 20.0 for i in range(0, 21)]

    toy = Toy083FailureModePhaseDiagram()
    json_path = toy.export_json(a_values=a_values, g_values=g_values)

    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
